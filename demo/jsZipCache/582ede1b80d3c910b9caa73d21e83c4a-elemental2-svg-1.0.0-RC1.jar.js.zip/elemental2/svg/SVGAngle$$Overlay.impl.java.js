/**
 * @fileoverview transpiled from elemental2.svg.SVGAngle$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGAngle.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_ANGLETYPE_DEG__elemental2_svg_SVGAngle_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_DEG__elemental2_svg_SVGAngle_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_ANGLETYPE_DEG__elemental2_svg_SVGAngle_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_DEG__elemental2_svg_SVGAngle_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_ANGLETYPE_GRAD__elemental2_svg_SVGAngle_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_GRAD__elemental2_svg_SVGAngle_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_ANGLETYPE_GRAD__elemental2_svg_SVGAngle_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_GRAD__elemental2_svg_SVGAngle_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_ANGLETYPE_RAD__elemental2_svg_SVGAngle_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_RAD__elemental2_svg_SVGAngle_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_ANGLETYPE_RAD__elemental2_svg_SVGAngle_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_RAD__elemental2_svg_SVGAngle_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_ANGLETYPE_UNKNOWN__elemental2_svg_SVGAngle_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_UNKNOWN__elemental2_svg_SVGAngle_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_ANGLETYPE_UNKNOWN__elemental2_svg_SVGAngle_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_UNKNOWN__elemental2_svg_SVGAngle_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_ANGLETYPE_UNSPECIFIED__elemental2_svg_SVGAngle_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_UNSPECIFIED__elemental2_svg_SVGAngle_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_ANGLETYPE_UNSPECIFIED__elemental2_svg_SVGAngle_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_ANGLETYPE_UNSPECIFIED__elemental2_svg_SVGAngle_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_ANGLETYPE_DEG__elemental2_svg_SVGAngle_$Overlay = SVGAngle.SVG_ANGLETYPE_DEG;
    $Overlay.$f_SVG_ANGLETYPE_GRAD__elemental2_svg_SVGAngle_$Overlay = SVGAngle.SVG_ANGLETYPE_GRAD;
    $Overlay.$f_SVG_ANGLETYPE_RAD__elemental2_svg_SVGAngle_$Overlay = SVGAngle.SVG_ANGLETYPE_RAD;
    $Overlay.$f_SVG_ANGLETYPE_UNKNOWN__elemental2_svg_SVGAngle_$Overlay = SVGAngle.SVG_ANGLETYPE_UNKNOWN;
    $Overlay.$f_SVG_ANGLETYPE_UNSPECIFIED__elemental2_svg_SVGAngle_$Overlay = SVGAngle.SVG_ANGLETYPE_UNSPECIFIED;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGAngle;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGAngle'));


/** @private {number} */
$Overlay.$f_SVG_ANGLETYPE_DEG__elemental2_svg_SVGAngle_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_ANGLETYPE_GRAD__elemental2_svg_SVGAngle_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_ANGLETYPE_RAD__elemental2_svg_SVGAngle_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_ANGLETYPE_UNKNOWN__elemental2_svg_SVGAngle_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_ANGLETYPE_UNSPECIFIED__elemental2_svg_SVGAngle_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGAngle$$Overlay.js.map