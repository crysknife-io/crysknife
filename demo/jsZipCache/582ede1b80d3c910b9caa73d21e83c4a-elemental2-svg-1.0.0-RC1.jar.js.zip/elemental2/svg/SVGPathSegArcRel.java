package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGPathSegArcRel extends SVGPathSeg {
  public double angle;
  public boolean largeArcFlag;
  public double r1;
  public double r2;
  public boolean sweepFlag;
  public double x;
  public double y;
}
