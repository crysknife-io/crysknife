package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGPoint {
  public double x;
  public double y;

  public native SVGPoint matrixTransform(SVGMatrix matrix);
}
