package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsProperty;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public interface SVGFitToViewBox {
  @JsProperty
  SVGAnimatedPreserveAspectRatio getPreserveAspectRatio();

  @JsProperty
  SVGAnimatedRect getViewBox();

  @JsProperty
  void setPreserveAspectRatio(SVGAnimatedPreserveAspectRatio preserveAspectRatio);

  @JsProperty
  void setViewBox(SVGAnimatedRect viewBox);
}
