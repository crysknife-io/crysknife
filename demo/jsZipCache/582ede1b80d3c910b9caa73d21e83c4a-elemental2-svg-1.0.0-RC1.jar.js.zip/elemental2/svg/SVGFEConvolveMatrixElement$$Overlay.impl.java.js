/**
 * @fileoverview transpiled from elemental2.svg.SVGFEConvolveMatrixElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFEConvolveMatrixElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_EDGEMODE_DUPLICATE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_DUPLICATE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_EDGEMODE_DUPLICATE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_DUPLICATE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_EDGEMODE_NONE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_NONE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_EDGEMODE_NONE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_NONE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_EDGEMODE_UNKNOWN__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_UNKNOWN__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_EDGEMODE_UNKNOWN__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_UNKNOWN__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_EDGEMODE_WRAP__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_WRAP__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_EDGEMODE_WRAP__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_EDGEMODE_WRAP__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_EDGEMODE_DUPLICATE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = SVGFEConvolveMatrixElement.SVG_EDGEMODE_DUPLICATE;
    $Overlay.$f_SVG_EDGEMODE_NONE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = SVGFEConvolveMatrixElement.SVG_EDGEMODE_NONE;
    $Overlay.$f_SVG_EDGEMODE_UNKNOWN__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = SVGFEConvolveMatrixElement.SVG_EDGEMODE_UNKNOWN;
    $Overlay.$f_SVG_EDGEMODE_WRAP__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = SVGFEConvolveMatrixElement.SVG_EDGEMODE_WRAP;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFEConvolveMatrixElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFEConvolveMatrixElement'));


/** @private {number} */
$Overlay.$f_SVG_EDGEMODE_DUPLICATE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_EDGEMODE_NONE__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_EDGEMODE_UNKNOWN__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_EDGEMODE_WRAP__elemental2_svg_SVGFEConvolveMatrixElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFEConvolveMatrixElement$$Overlay.js.map