package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsProperty;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGAltGlyphElement extends SVGTextPositioningElement implements SVGURIReference {
  public String format;
  public String glyphRef;
  public SVGAnimatedString href;

  @JsProperty
  public native SVGAnimatedString getHref();

  @JsProperty
  public native void setHref(SVGAnimatedString href);
}
