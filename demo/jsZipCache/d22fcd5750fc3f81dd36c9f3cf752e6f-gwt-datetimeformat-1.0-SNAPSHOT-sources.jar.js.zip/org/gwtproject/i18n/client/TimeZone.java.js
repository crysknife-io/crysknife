/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.TimeZone.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.TimeZone');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _TimeZone = goog.require('org.gwtproject.i18n.shared.TimeZone');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _Date = goog.require('java.util.Date');
const _$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Equality = goog.require('nativebootstrap.Equality');
const _TimeZoneInfo = goog.require('org.gwtproject.i18n.client.TimeZoneInfo');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$LongUtils = goog.require('vmbootstrap.LongUtils');
const _$Primitives = goog.require('vmbootstrap.Primitives');
const _$char = goog.require('vmbootstrap.primitives.$char');
const _$int = goog.require('vmbootstrap.primitives.$int');


// Re-exports the implementation.
var org_gwtproject_i18n_client_TimeZone = goog.require('org.gwtproject.i18n.client.TimeZone$impl');
exports = org_gwtproject_i18n_client_TimeZone;
 