/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.DateTimeFormat.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.DateTimeFormat');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _PredefinedFormat = goog.require('org.gwtproject.i18n.client.DateTimeFormat.PredefinedFormat');
const _DateTimeFormatInfoImpl__en = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _DateTimeFormatInfo__factory = goog.require('org.gwtproject.i18n.shared.impl.cldr.DateTimeFormatInfo_factory');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var org_gwtproject_i18n_client_DateTimeFormat = goog.require('org.gwtproject.i18n.client.DateTimeFormat$impl');
exports = org_gwtproject_i18n_client_DateTimeFormat;
 