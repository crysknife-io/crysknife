/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.TimeZoneInfo.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.TimeZoneInfo');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _JsArray_$Overlay = goog.require('elemental2.core.JsArray.$Overlay');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _Any_$Overlay = goog.require('jsinterop.base.Any.$Overlay');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var TimeZoneInfo = goog.require('org.gwtproject.i18n.client.TimeZoneInfo$impl');
exports = TimeZoneInfo;
 