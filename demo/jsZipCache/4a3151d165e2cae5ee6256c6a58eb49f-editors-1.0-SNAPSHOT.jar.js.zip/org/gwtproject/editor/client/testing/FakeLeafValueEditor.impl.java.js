/**
 * @fileoverview transpiled from org.gwtproject.editor.client.testing.FakeLeafValueEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.testing.FakeLeafValueEditor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor$impl');


/**
 * @template C_T
 * @implements {LeafValueEditor<C_T>}
  */
class FakeLeafValueEditor extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {C_T} */
    this.f_value__org_gwtproject_editor_client_testing_FakeLeafValueEditor_;
  }
  
  /**
   * @template C_T
   * @return {!FakeLeafValueEditor<C_T>}
   * @public
   */
  static $create__() {
    FakeLeafValueEditor.$clinit();
    let $instance = new FakeLeafValueEditor();
    $instance.$ctor__org_gwtproject_editor_client_testing_FakeLeafValueEditor__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_testing_FakeLeafValueEditor__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_getValue__() {
    return this.f_value__org_gwtproject_editor_client_testing_FakeLeafValueEditor_;
  }
  
  /**
   * @override
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
    this.f_value__org_gwtproject_editor_client_testing_FakeLeafValueEditor_ = value;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    FakeLeafValueEditor.$clinit = (() =>{
    });
    FakeLeafValueEditor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof FakeLeafValueEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, FakeLeafValueEditor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(FakeLeafValueEditor, $Util.$makeClassName('org.gwtproject.editor.client.testing.FakeLeafValueEditor'));


LeafValueEditor.$markImplementor(FakeLeafValueEditor);


exports = FakeLeafValueEditor; 
//# sourceMappingURL=FakeLeafValueEditor.js.map