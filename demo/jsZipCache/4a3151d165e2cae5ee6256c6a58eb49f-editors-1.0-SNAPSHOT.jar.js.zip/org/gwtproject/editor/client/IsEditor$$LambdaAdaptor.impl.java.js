/**
 * @fileoverview transpiled from org.gwtproject.editor.client.IsEditor$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.IsEditor.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const IsEditor = goog.require('org.gwtproject.editor.client.IsEditor$impl');

let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');


/**
 * @template C_E
 * @implements {IsEditor<C_E>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function():C_E} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function():C_E} */
    this.f_$$fn__org_gwtproject_editor_client_IsEditor_$LambdaAdaptor;
    this.$ctor__org_gwtproject_editor_client_IsEditor_$LambdaAdaptor__org_gwtproject_editor_client_IsEditor_$JsFunction(fn);
  }
  
  /**
   * @param {?function():C_E} fn
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_IsEditor_$LambdaAdaptor__org_gwtproject_editor_client_IsEditor_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_gwtproject_editor_client_IsEditor_$LambdaAdaptor = fn;
  }
  
  /**
   * @return {C_E}
   * @public
   */
  m_asEditor__() {
    let /** ?function():C_E */ $function;
    return ($function = this.f_$$fn__org_gwtproject_editor_client_IsEditor_$LambdaAdaptor, $function());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.gwtproject.editor.client.IsEditor$$LambdaAdaptor'));


IsEditor.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=IsEditor$$LambdaAdaptor.js.map