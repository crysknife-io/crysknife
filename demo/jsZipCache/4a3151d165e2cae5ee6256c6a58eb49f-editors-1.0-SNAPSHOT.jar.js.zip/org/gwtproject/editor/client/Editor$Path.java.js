/**
 * @fileoverview transpiled from org.gwtproject.editor.client.Editor$Path.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.Editor.Path');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var Path = goog.require('org.gwtproject.editor.client.Editor.Path$impl');
exports = Path;
 