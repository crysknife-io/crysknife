/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.SimpleEditor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.adapters.SimpleEditor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');


// Re-exports the implementation.
var SimpleEditor = goog.require('org.gwtproject.editor.client.adapters.SimpleEditor$impl');
exports = SimpleEditor;
 