/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.SimpleEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.adapters.SimpleEditor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor$impl');


/**
 * @template C_T
 * @implements {LeafValueEditor<C_T>}
  */
class SimpleEditor extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {C_T} */
    this.f_value__org_gwtproject_editor_client_adapters_SimpleEditor_;
  }
  
  /**
   * @template M_T
   * @return {SimpleEditor<M_T>}
   * @public
   */
  static m_of__() {
    SimpleEditor.$clinit();
    return /**@type {!SimpleEditor<*>} */ (SimpleEditor.$create__java_lang_Object(null));
  }
  
  /**
   * @template M_T
   * @param {M_T} value
   * @return {SimpleEditor<M_T>}
   * @public
   */
  static m_of__java_lang_Object(value) {
    SimpleEditor.$clinit();
    return /**@type {!SimpleEditor<*>} */ (SimpleEditor.$create__java_lang_Object(value));
  }
  
  /**
   * @template C_T
   * @param {C_T} value
   * @return {!SimpleEditor<C_T>}
   * @public
   */
  static $create__java_lang_Object(value) {
    SimpleEditor.$clinit();
    let $instance = new SimpleEditor();
    $instance.$ctor__org_gwtproject_editor_client_adapters_SimpleEditor__java_lang_Object(value);
    return $instance;
  }
  
  /**
   * @param {C_T} value
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_adapters_SimpleEditor__java_lang_Object(value) {
    this.$ctor__java_lang_Object__();
    this.f_value__org_gwtproject_editor_client_adapters_SimpleEditor_ = value;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_getValue__() {
    return this.f_value__org_gwtproject_editor_client_adapters_SimpleEditor_;
  }
  
  /**
   * @override
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
    this.f_value__org_gwtproject_editor_client_adapters_SimpleEditor_ = value;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SimpleEditor.$clinit = (() =>{
    });
    SimpleEditor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SimpleEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SimpleEditor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(SimpleEditor, $Util.$makeClassName('org.gwtproject.editor.client.adapters.SimpleEditor'));


LeafValueEditor.$markImplementor(SimpleEditor);


exports = SimpleEditor; 
//# sourceMappingURL=SimpleEditor.js.map