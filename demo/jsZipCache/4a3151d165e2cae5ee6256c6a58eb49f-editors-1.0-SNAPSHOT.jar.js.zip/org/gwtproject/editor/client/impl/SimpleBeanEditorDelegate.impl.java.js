/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate$impl');

let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let HandlerRegistration = goog.forwardDeclare('org.gwtproject.event.shared.HandlerRegistration$impl');


/**
 * @abstract
 * @template C_T, C_E
 * @extends {AbstractEditorDelegate<C_T, C_E>}
  */
class SimpleBeanEditorDelegate extends AbstractEditorDelegate {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_impl_SimpleBeanEditorDelegate__() {
    this.$ctor__org_gwtproject_editor_client_impl_AbstractEditorDelegate__();
  }
  
  /**
   * @override
   * @return {HandlerRegistration}
   * @public
   */
  m_subscribe__() {
    return null;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SimpleBeanEditorDelegate.$clinit = (() =>{
    });
    SimpleBeanEditorDelegate.$loadModules();
    AbstractEditorDelegate.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SimpleBeanEditorDelegate;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SimpleBeanEditorDelegate);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(SimpleBeanEditorDelegate, $Util.$makeClassName('org.gwtproject.editor.client.impl.SimpleBeanEditorDelegate'));




exports = SimpleBeanEditorDelegate; 
//# sourceMappingURL=SimpleBeanEditorDelegate.js.map