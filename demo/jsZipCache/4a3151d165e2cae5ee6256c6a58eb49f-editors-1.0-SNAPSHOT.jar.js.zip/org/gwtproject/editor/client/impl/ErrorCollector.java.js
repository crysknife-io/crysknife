/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.ErrorCollector.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.ErrorCollector');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Stack = goog.require('java.util.Stack');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _SimpleError = goog.require('org.gwtproject.editor.client.impl.SimpleError');
const _$Asserts = goog.require('vmbootstrap.Asserts');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ErrorCollector = goog.require('org.gwtproject.editor.client.impl.ErrorCollector$impl');
exports = ErrorCollector;
 