/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.DirtCollector.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.DirtCollector');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DirtCollector = goog.require('org.gwtproject.editor.client.impl.DirtCollector$impl');
exports = DirtCollector;
 