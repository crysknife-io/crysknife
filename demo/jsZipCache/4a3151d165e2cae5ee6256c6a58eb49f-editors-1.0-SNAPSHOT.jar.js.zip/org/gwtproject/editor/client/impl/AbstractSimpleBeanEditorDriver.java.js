/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.SimpleBeanEditorDriver');
const _BaseEditorDriver = goog.require('org.gwtproject.editor.client.impl.BaseEditorDriver');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');


// Re-exports the implementation.
var AbstractSimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver$impl');
exports = AbstractSimpleBeanEditorDriver;
 