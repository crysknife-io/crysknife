/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleViolation$ConstraintViolationIterable$1.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable.$1');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Iterator = goog.require('java.util.Iterator');
const _$Util = goog.require('nativebootstrap.Util');
const _Consumer = goog.require('java.util.function.Consumer');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _SimpleViolation = goog.require('org.gwtproject.editor.client.impl.SimpleViolation');
const _ConstraintViolationIterable = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable');
const _SimpleViolationAdapter = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.SimpleViolationAdapter');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var $1 = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable.$1$impl');
exports = $1;
 