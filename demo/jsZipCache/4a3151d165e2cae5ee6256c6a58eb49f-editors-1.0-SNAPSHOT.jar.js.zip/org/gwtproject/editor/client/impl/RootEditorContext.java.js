/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.RootEditorContext.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.RootEditorContext');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _AbstractEditorContext = goog.require('org.gwtproject.editor.client.impl.AbstractEditorContext');
const _Class = goog.require('java.lang.Class');
const _j_l_Object = goog.require('java.lang.Object');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var RootEditorContext = goog.require('org.gwtproject.editor.client.impl.RootEditorContext$impl');
exports = RootEditorContext;
 