/**
 * @fileoverview transpiled from org.gwtproject.editor.client.ValueAwareEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.ValueAwareEditor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const HasEditorDelegate = goog.require('org.gwtproject.editor.client.HasEditorDelegate$impl');


/**
 * @interface
 * @template C_T
 * @extends {HasEditorDelegate<C_T>}
 */
class ValueAwareEditor {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_flush__() {
  }
  
  /**
   * @abstract
   * @param {Array<?string>} paths
   * @return {void}
   * @public
   */
  m_onPropertyChange__arrayOf_java_lang_String(paths) {
  }
  
  /**
   * @abstract
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ValueAwareEditor.$clinit = (() =>{
    });
    ValueAwareEditor.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    HasEditorDelegate.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_ValueAwareEditor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_ValueAwareEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_ValueAwareEditor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(ValueAwareEditor, $Util.$makeClassName('org.gwtproject.editor.client.ValueAwareEditor'));


ValueAwareEditor.$markImplementor(/** @type {Function} */ (ValueAwareEditor));


exports = ValueAwareEditor; 
//# sourceMappingURL=ValueAwareEditor.js.map