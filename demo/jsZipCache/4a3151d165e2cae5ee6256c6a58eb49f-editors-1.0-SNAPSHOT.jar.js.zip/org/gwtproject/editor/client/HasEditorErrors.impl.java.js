/**
 * @fileoverview transpiled from org.gwtproject.editor.client.HasEditorErrors.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.HasEditorErrors$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Editor = goog.require('org.gwtproject.editor.client.Editor$impl');

let List = goog.forwardDeclare('java.util.List$impl');
let EditorError = goog.forwardDeclare('org.gwtproject.editor.client.EditorError$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.gwtproject.editor.client.HasEditorErrors.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 * @extends {Editor<C_T>}
 */
class HasEditorErrors {
  /**
   * @abstract
   * @param {List<EditorError>} errors
   * @return {void}
   * @public
   */
  m_showErrors__java_util_List(errors) {
  }
  
  /**
   * @template C_T
   * @param {?function(List<EditorError>):void} fn
   * @return {HasEditorErrors<C_T>}
   * @public
   */
  static $adapt(fn) {
    HasEditorErrors.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasEditorErrors.$clinit = (() =>{
    });
    HasEditorErrors.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Editor.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_HasEditorErrors = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_HasEditorErrors;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_HasEditorErrors;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.gwtproject.editor.client.HasEditorErrors.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasEditorErrors, $Util.$makeClassName('org.gwtproject.editor.client.HasEditorErrors'));


HasEditorErrors.$markImplementor(/** @type {Function} */ (HasEditorErrors));


exports = HasEditorErrors; 
//# sourceMappingURL=HasEditorErrors.js.map