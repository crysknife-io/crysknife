/**
 * @fileoverview transpiled from org.gwtproject.editor.client.Editor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.Editor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @template C_T
 */
class Editor {
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Editor.$clinit = (() =>{
    });
    Editor.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_Editor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_Editor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_Editor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(Editor, $Util.$makeClassName('org.gwtproject.editor.client.Editor'));


Editor.$markImplementor(/** @type {Function} */ (Editor));


exports = Editor; 
//# sourceMappingURL=Editor.js.map