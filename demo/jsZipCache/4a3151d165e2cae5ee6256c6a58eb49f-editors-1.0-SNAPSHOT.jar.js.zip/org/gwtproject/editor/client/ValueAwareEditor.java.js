/**
 * @fileoverview transpiled from org.gwtproject.editor.client.ValueAwareEditor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.ValueAwareEditor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _HasEditorDelegate = goog.require('org.gwtproject.editor.client.HasEditorDelegate');


// Re-exports the implementation.
var ValueAwareEditor = goog.require('org.gwtproject.editor.client.ValueAwareEditor$impl');
exports = ValueAwareEditor;
 