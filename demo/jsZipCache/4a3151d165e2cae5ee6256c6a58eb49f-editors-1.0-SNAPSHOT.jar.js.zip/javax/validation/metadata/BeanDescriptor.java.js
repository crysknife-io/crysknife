/**
 * @fileoverview transpiled from javax.validation.metadata.BeanDescriptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.metadata.BeanDescriptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _ElementDescriptor = goog.require('javax.validation.metadata.ElementDescriptor');
const _$Util = goog.require('nativebootstrap.Util');
const _Set = goog.require('java.util.Set');
const _PropertyDescriptor = goog.require('javax.validation.metadata.PropertyDescriptor');


// Re-exports the implementation.
var BeanDescriptor = goog.require('javax.validation.metadata.BeanDescriptor$impl');
exports = BeanDescriptor;
 