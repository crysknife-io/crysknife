/**
 * @fileoverview transpiled from javax.inject.Inject.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.inject.Inject');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('javax.inject.Inject.$LambdaAdaptor');


// Re-exports the implementation.
var Inject = goog.require('javax.inject.Inject$impl');
exports = Inject;
 