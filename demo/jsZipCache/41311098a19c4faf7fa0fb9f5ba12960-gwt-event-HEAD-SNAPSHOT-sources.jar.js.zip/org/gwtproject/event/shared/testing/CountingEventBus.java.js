/**
 * @fileoverview transpiled from org.gwtproject.event.shared.testing.CountingEventBus.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.testing.CountingEventBus');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EventBus = goog.require('org.gwtproject.event.shared.EventBus');
const _Event = goog.require('org.gwtproject.event.shared.Event');
const _Type = goog.require('org.gwtproject.event.shared.Event.Type');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');
const _SimpleEventBus = goog.require('org.gwtproject.event.shared.SimpleEventBus');
const _KeyedCounter = goog.require('org.gwtproject.event.shared.testing.CountingEventBus.KeyedCounter');
const _TypeSourcePair = goog.require('org.gwtproject.event.shared.testing.CountingEventBus.TypeSourcePair');


// Re-exports the implementation.
var CountingEventBus = goog.require('org.gwtproject.event.shared.testing.CountingEventBus$impl');
exports = CountingEventBus;
 