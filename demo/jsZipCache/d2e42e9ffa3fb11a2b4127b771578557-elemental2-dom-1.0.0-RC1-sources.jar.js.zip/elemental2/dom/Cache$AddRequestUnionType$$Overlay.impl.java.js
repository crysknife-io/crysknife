/**
 * @fileoverview transpiled from elemental2.dom.Cache$AddRequestUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Cache.AddRequestUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Request.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class AddRequestUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    AddRequestUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), AddRequestUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {Request}
   * @public
   */
  static m_asRequest__elemental2_dom_Cache_AddRequestUnionType($thisArg) {
    AddRequestUnionType_$Overlay.$clinit();
    return /**@type {Request} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {?string}
   * @public
   */
  static m_asString__elemental2_dom_Cache_AddRequestUnionType($thisArg) {
    AddRequestUnionType_$Overlay.$clinit();
    return Js.m_asString__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isRequest__elemental2_dom_Cache_AddRequestUnionType($thisArg) {
    AddRequestUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isString__elemental2_dom_Cache_AddRequestUnionType($thisArg) {
    AddRequestUnionType_$Overlay.$clinit();
    return j_l_String.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AddRequestUnionType_$Overlay.$clinit = (() =>{
    });
    AddRequestUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.Request.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = AddRequestUnionType_$Overlay; 
//# sourceMappingURL=Cache$AddRequestUnionType$$Overlay.js.map