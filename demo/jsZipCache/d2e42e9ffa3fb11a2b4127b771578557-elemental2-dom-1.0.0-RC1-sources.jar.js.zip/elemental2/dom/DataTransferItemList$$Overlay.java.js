/**
 * @fileoverview transpiled from elemental2.dom.DataTransferItemList$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.DataTransferItemList.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DataTransferItem_$Overlay = goog.require('elemental2.dom.DataTransferItem.$Overlay');
const _$Overlay = goog.require('elemental2.dom.DataTransferItemList.AddDataUnionType.$Overlay');
const _File_$Overlay = goog.require('elemental2.dom.File.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var DataTransferItemList_$Overlay = goog.require('elemental2.dom.DataTransferItemList.$Overlay$impl');
exports = DataTransferItemList_$Overlay;
 