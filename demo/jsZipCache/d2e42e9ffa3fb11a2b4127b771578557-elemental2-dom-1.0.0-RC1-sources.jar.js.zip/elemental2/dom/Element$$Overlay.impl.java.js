/**
 * @fileoverview transpiled from elemental2.dom.Element$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.Element.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.MatchesSelectorRefNodesUnionType.$Overlay$impl');
let ReplaceWithNodesUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.Element.ReplaceWithNodesUnionType.$Overlay$impl');
let ScrollIntoViewTopType_$Overlay = goog.forwardDeclare('elemental2.dom.Element.ScrollIntoViewTopType.$Overlay$impl');
let ScrollIntoViewTopUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.Element.ScrollIntoViewTopUnionType.$Overlay$impl');
let SetAttributeNSValueUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.Element.SetAttributeNSValueUnionType.$Overlay$impl');
let SetAttributeValueUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.Element.SetAttributeValueUnionType.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let NodeList_$Overlay = goog.forwardDeclare('elemental2.dom.NodeList.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class Element_$Overlay {
  /**
   * @param {Element} $thisArg
   * @param {?string} selectors
   * @param {Node} refNodes
   * @return {boolean}
   * @public
   */
  static m_matchesSelector__elemental2_dom_Element__java_lang_String__elemental2_dom_Node($thisArg, selectors, refNodes) {
    Element_$Overlay.$clinit();
    return $thisArg.matchesSelector(selectors, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(refNodes)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} selectors
   * @param {NodeList<*>} refNodes
   * @return {boolean}
   * @public
   */
  static m_matchesSelector__elemental2_dom_Element__java_lang_String__elemental2_dom_NodeList($thisArg, selectors, refNodes) {
    Element_$Overlay.$clinit();
    return $thisArg.matchesSelector(selectors, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(refNodes)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {Array<Node>} nodes
   * @return {void}
   * @public
   */
  static m_replaceWith__elemental2_dom_Element__arrayOf_elemental2_dom_Node($thisArg, nodes) {
    Element_$Overlay.$clinit();
    $thisArg.replaceWith(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(nodes)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {Array<?string>} nodes
   * @return {void}
   * @public
   */
  static m_replaceWith__elemental2_dom_Element__arrayOf_java_lang_String($thisArg, nodes) {
    Element_$Overlay.$clinit();
    $thisArg.replaceWith(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(nodes)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?} top
   * @return {void}
   * @public
   */
  static m_scrollIntoView__elemental2_dom_Element__elemental2_dom_Element_ScrollIntoViewTopType($thisArg, top) {
    Element_$Overlay.$clinit();
    $thisArg.scrollIntoView(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(top)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {boolean} top
   * @return {void}
   * @public
   */
  static m_scrollIntoView__elemental2_dom_Element__boolean($thisArg, top) {
    Element_$Overlay.$clinit();
    $thisArg.scrollIntoView(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(top)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} name
   * @param {?string} value
   * @return {void}
   * @public
   */
  static m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String($thisArg, name, value) {
    Element_$Overlay.$clinit();
    $thisArg.setAttribute(name, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} name
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static m_setAttribute__elemental2_dom_Element__java_lang_String__boolean($thisArg, name, value) {
    Element_$Overlay.$clinit();
    $thisArg.setAttribute(name, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} name
   * @param {number} value
   * @return {void}
   * @public
   */
  static m_setAttribute__elemental2_dom_Element__java_lang_String__double($thisArg, name, value) {
    Element_$Overlay.$clinit();
    $thisArg.setAttribute(name, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} namespaceURI
   * @param {?string} qualifiedName
   * @param {?string} value
   * @return {void}
   * @public
   */
  static m_setAttributeNS__elemental2_dom_Element__java_lang_String__java_lang_String__java_lang_String($thisArg, namespaceURI, qualifiedName, value) {
    Element_$Overlay.$clinit();
    $thisArg.setAttributeNS(namespaceURI, qualifiedName, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} namespaceURI
   * @param {?string} qualifiedName
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static m_setAttributeNS__elemental2_dom_Element__java_lang_String__java_lang_String__boolean($thisArg, namespaceURI, qualifiedName, value) {
    Element_$Overlay.$clinit();
    $thisArg.setAttributeNS(namespaceURI, qualifiedName, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value)));
  }
  
  /**
   * @param {Element} $thisArg
   * @param {?string} namespaceURI
   * @param {?string} qualifiedName
   * @param {number} value
   * @return {void}
   * @public
   */
  static m_setAttributeNS__elemental2_dom_Element__java_lang_String__java_lang_String__double($thisArg, namespaceURI, qualifiedName, value) {
    Element_$Overlay.$clinit();
    $thisArg.setAttributeNS(namespaceURI, qualifiedName, /**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(value)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Element_$Overlay.$clinit = (() =>{
    });
    Element_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Element;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(Element_$Overlay, $Util.$makeClassName('Element'));


exports = Element_$Overlay; 
//# sourceMappingURL=Element$$Overlay.js.map