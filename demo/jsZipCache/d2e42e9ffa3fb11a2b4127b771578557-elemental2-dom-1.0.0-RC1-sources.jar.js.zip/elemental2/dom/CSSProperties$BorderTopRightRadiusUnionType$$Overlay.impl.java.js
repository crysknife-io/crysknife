/**
 * @fileoverview transpiled from elemental2.dom.CSSProperties$BorderTopRightRadiusUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.CSSProperties.BorderTopRightRadiusUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Double = goog.forwardDeclare('java.lang.Double$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class $Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    $Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {number}
   * @public
   */
  static m_asDouble__elemental2_dom_CSSProperties_BorderTopRightRadiusUnionType($thisArg) {
    $Overlay.$clinit();
    return Js.m_asDouble__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {?string}
   * @public
   */
  static m_asString__elemental2_dom_CSSProperties_BorderTopRightRadiusUnionType($thisArg) {
    $Overlay.$clinit();
    return Js.m_asString__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isDouble__elemental2_dom_CSSProperties_BorderTopRightRadiusUnionType($thisArg) {
    $Overlay.$clinit();
    return Double.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isString__elemental2_dom_CSSProperties_BorderTopRightRadiusUnionType($thisArg) {
    $Overlay.$clinit();
    return j_l_String.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Double = goog.module.get('java.lang.Double$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = $Overlay; 
//# sourceMappingURL=CSSProperties$BorderTopRightRadiusUnionType$$Overlay.js.map