/**
 * @fileoverview transpiled from elemental2.dom.Element$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.Element.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Element.MatchesSelectorRefNodesUnionType.$Overlay');
const _ReplaceWithNodesUnionType_$Overlay = goog.require('elemental2.dom.Element.ReplaceWithNodesUnionType.$Overlay');
const _ScrollIntoViewTopType_$Overlay = goog.require('elemental2.dom.Element.ScrollIntoViewTopType.$Overlay');
const _ScrollIntoViewTopUnionType_$Overlay = goog.require('elemental2.dom.Element.ScrollIntoViewTopUnionType.$Overlay');
const _SetAttributeNSValueUnionType_$Overlay = goog.require('elemental2.dom.Element.SetAttributeNSValueUnionType.$Overlay');
const _SetAttributeValueUnionType_$Overlay = goog.require('elemental2.dom.Element.SetAttributeValueUnionType.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _NodeList_$Overlay = goog.require('elemental2.dom.NodeList.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var Element_$Overlay = goog.require('elemental2.dom.Element.$Overlay$impl');
exports = Element_$Overlay;
 