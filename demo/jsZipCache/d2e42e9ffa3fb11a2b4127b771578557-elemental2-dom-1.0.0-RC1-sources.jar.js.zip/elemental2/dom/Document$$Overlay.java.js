/**
 * @fileoverview transpiled from elemental2.dom.Document$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.Document.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Document.CreateTextNodeDataUnionType.$Overlay');
const _Text_$Overlay = goog.require('elemental2.dom.Text.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var Document_$Overlay = goog.require('elemental2.dom.Document.$Overlay$impl');
exports = Document_$Overlay;
 