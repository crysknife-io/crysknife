/**
 * @fileoverview transpiled from elemental2.dom.CanvasRenderingContext2D$FillStyleUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.CanvasRenderingContext2D.FillStyleUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.CanvasGradient.$Overlay$impl');
let CanvasPattern_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasPattern.$Overlay$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class FillStyleUnionType_$Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    FillStyleUnionType_$Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), FillStyleUnionType_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {CanvasGradient}
   * @public
   */
  static m_asCanvasGradient__elemental2_dom_CanvasRenderingContext2D_FillStyleUnionType($thisArg) {
    FillStyleUnionType_$Overlay.$clinit();
    return /**@type {CanvasGradient} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {CanvasPattern}
   * @public
   */
  static m_asCanvasPattern__elemental2_dom_CanvasRenderingContext2D_FillStyleUnionType($thisArg) {
    FillStyleUnionType_$Overlay.$clinit();
    return /**@type {CanvasPattern} */ ($Casts.$to(Js.m_cast__java_lang_Object($thisArg), CanvasPattern_$Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {?string}
   * @public
   */
  static m_asString__elemental2_dom_CanvasRenderingContext2D_FillStyleUnionType($thisArg) {
    FillStyleUnionType_$Overlay.$clinit();
    return Js.m_asString__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isCanvasGradient__elemental2_dom_CanvasRenderingContext2D_FillStyleUnionType($thisArg) {
    FillStyleUnionType_$Overlay.$clinit();
    return $Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isCanvasPattern__elemental2_dom_CanvasRenderingContext2D_FillStyleUnionType($thisArg) {
    FillStyleUnionType_$Overlay.$clinit();
    return CanvasPattern_$Overlay.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isString__elemental2_dom_CanvasRenderingContext2D_FillStyleUnionType($thisArg) {
    FillStyleUnionType_$Overlay.$clinit();
    return j_l_String.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    FillStyleUnionType_$Overlay.$clinit = (() =>{
    });
    FillStyleUnionType_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.CanvasGradient.$Overlay$impl');
    CanvasPattern_$Overlay = goog.module.get('elemental2.dom.CanvasPattern.$Overlay$impl');
    j_l_Object = goog.module.get('java.lang.Object$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = FillStyleUnionType_$Overlay; 
//# sourceMappingURL=CanvasRenderingContext2D$FillStyleUnionType$$Overlay.js.map