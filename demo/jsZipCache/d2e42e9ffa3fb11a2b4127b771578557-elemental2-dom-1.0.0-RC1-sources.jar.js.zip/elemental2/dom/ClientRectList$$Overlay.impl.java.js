/**
 * @fileoverview transpiled from elemental2.dom.ClientRectList$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.ClientRectList.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClientRectList;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('ClientRectList'));


exports = $Overlay; 
//# sourceMappingURL=ClientRectList$$Overlay.js.map