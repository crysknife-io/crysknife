/**
 * @fileoverview transpiled from elemental2.dom.ConstrainLongRange$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.ConstrainLongRange.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class ConstrainLongRange_$Overlay {
  /**
   * @return {ConstrainLongRange}
   * @public
   */
  static m_create__() {
    ConstrainLongRange_$Overlay.$clinit();
    return /**@type {ConstrainLongRange} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ConstrainLongRange_$Overlay.$clinit = (() =>{
    });
    ConstrainLongRange_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};



exports = ConstrainLongRange_$Overlay; 
//# sourceMappingURL=ConstrainLongRange$$Overlay.js.map