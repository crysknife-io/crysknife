/**
 * @fileoverview transpiled from elemental2.dom.ClipboardEventInit$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.ClipboardEventInit.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');


// Re-exports the implementation.
var ClipboardEventInit_$Overlay = goog.require('elemental2.dom.ClipboardEventInit.$Overlay$impl');
exports = ClipboardEventInit_$Overlay;
 