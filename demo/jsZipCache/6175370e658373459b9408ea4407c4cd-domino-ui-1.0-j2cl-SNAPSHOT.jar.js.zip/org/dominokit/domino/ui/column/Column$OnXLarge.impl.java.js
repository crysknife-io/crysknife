/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column$OnXLarge.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.column.Column.OnXLarge$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.column.Column$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<OnXLarge>}
  */
class OnXLarge extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_column_Column_OnXLarge_;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!OnXLarge}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new OnXLarge();
    $instance.$ctor__org_dominokit_domino_ui_column_Column_OnXLarge__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_column_Column_OnXLarge__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_column_Column_OnXLarge_ = style;
  }
  
  /**
   * @param {number} large
   * @return {OnXLarge}
   * @public
   */
  static m_of__int(large) {
    OnXLarge.$clinit();
    return OnXLarge.m_valueOf__java_lang_String(Column.m_asNumberString__int_$p_org_dominokit_domino_ui_column_Column(large));
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_column_Column_OnXLarge_;
  }
  
  /**
   * @param {string} name
   * @return {!OnXLarge}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    OnXLarge.$clinit();
    if ($Equality.$same(OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_, null)) {
      OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_ = $Enums.createMapFromValues(OnXLarge.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_);
  }
  
  /**
   * @return {!Array<!OnXLarge>}
   * @public
   */
  static m_values__() {
    OnXLarge.$clinit();
    return /**@type {!Array<OnXLarge>} */ ($Arrays.$init([OnXLarge.$f_one__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_two__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_three__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_four__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_five__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_six__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge, OnXLarge.$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge], OnXLarge));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {OnXLarge} */ ($Casts.$to(arg0, OnXLarge)));
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_one__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_one__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_one__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_one__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_two__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_two__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_two__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_two__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_three__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_three__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_three__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_three__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_four__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_four__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_four__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_four__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_five__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_five__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_five__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_five__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_six__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_six__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_six__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_six__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_seven__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_seven__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_eight__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_eight__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_nine__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_nine__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_ten__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_ten__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {!OnXLarge}
   * @public
   */
  static get f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge() {
    return (OnXLarge.$clinit(), OnXLarge.$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge);
  }
  
  /**
   * @param {!OnXLarge} value
   * @return {void}
   * @public
   */
  static set f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge = value);
  }
  
  /**
   * @return {Map<?string, !OnXLarge>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_() {
    return (OnXLarge.$clinit(), OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_);
  }
  
  /**
   * @param {Map<?string, !OnXLarge>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_(value) {
    (OnXLarge.$clinit(), OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    OnXLarge.$clinit = (() =>{
    });
    OnXLarge.$loadModules();
    Enum.$clinit();
    OnXLarge.$f_one__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("one"), OnXLarge.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-1");
    OnXLarge.$f_two__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("two"), OnXLarge.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-2");
    OnXLarge.$f_three__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("three"), OnXLarge.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-3");
    OnXLarge.$f_four__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("four"), OnXLarge.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-4");
    OnXLarge.$f_five__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("five"), OnXLarge.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-5");
    OnXLarge.$f_six__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("six"), OnXLarge.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-6");
    OnXLarge.$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("seven"), OnXLarge.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-7");
    OnXLarge.$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eight"), OnXLarge.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-8");
    OnXLarge.$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("nine"), OnXLarge.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-9");
    OnXLarge.$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("ten"), OnXLarge.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-10");
    OnXLarge.$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("eleven"), OnXLarge.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-11");
    OnXLarge.$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge = OnXLarge.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("twelve"), OnXLarge.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge, "col-xl-12");
    OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof OnXLarge;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, OnXLarge);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    Column = goog.module.get('org.dominokit.domino.ui.column.Column$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(OnXLarge, $Util.$makeClassName('org.dominokit.domino.ui.column.Column$OnXLarge'));


/** @private {!OnXLarge} */
OnXLarge.$f_one__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_two__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_three__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_four__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_five__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_six__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {!OnXLarge} */
OnXLarge.$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge;


/** @private {Map<?string, !OnXLarge>} */
OnXLarge.$f_namesToValuesMap__org_dominokit_domino_ui_column_Column_OnXLarge_;


/** @public {number} @const */
OnXLarge.$ordinal$f_one__org_dominokit_domino_ui_column_Column_OnXLarge = 0;


/** @public {number} @const */
OnXLarge.$ordinal$f_two__org_dominokit_domino_ui_column_Column_OnXLarge = 1;


/** @public {number} @const */
OnXLarge.$ordinal$f_three__org_dominokit_domino_ui_column_Column_OnXLarge = 2;


/** @public {number} @const */
OnXLarge.$ordinal$f_four__org_dominokit_domino_ui_column_Column_OnXLarge = 3;


/** @public {number} @const */
OnXLarge.$ordinal$f_five__org_dominokit_domino_ui_column_Column_OnXLarge = 4;


/** @public {number} @const */
OnXLarge.$ordinal$f_six__org_dominokit_domino_ui_column_Column_OnXLarge = 5;


/** @public {number} @const */
OnXLarge.$ordinal$f_seven__org_dominokit_domino_ui_column_Column_OnXLarge = 6;


/** @public {number} @const */
OnXLarge.$ordinal$f_eight__org_dominokit_domino_ui_column_Column_OnXLarge = 7;


/** @public {number} @const */
OnXLarge.$ordinal$f_nine__org_dominokit_domino_ui_column_Column_OnXLarge = 8;


/** @public {number} @const */
OnXLarge.$ordinal$f_ten__org_dominokit_domino_ui_column_Column_OnXLarge = 9;


/** @public {number} @const */
OnXLarge.$ordinal$f_eleven__org_dominokit_domino_ui_column_Column_OnXLarge = 10;


/** @public {number} @const */
OnXLarge.$ordinal$f_twelve__org_dominokit_domino_ui_column_Column_OnXLarge = 11;




exports = OnXLarge; 
//# sourceMappingURL=Column$OnXLarge.js.map