/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.column.Column');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Cloneable = goog.require('java.lang.Cloneable');
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _OnLarge = goog.require('org.dominokit.domino.ui.column.Column.OnLarge');
const _OnMedium = goog.require('org.dominokit.domino.ui.column.Column.OnMedium');
const _OnSmall = goog.require('org.dominokit.domino.ui.column.Column.OnSmall');
const _OnXLarge = goog.require('org.dominokit.domino.ui.column.Column.OnXLarge');
const _OnXSmall = goog.require('org.dominokit.domino.ui.column.Column.OnXSmall');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Column = goog.require('org.dominokit.domino.ui.column.Column$impl');
exports = Column;
 