/**
 * @fileoverview transpiled from org.dominokit.domino.ui.column.Column.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.column.Column$impl');


const Cloneable = goog.require('java.lang.Cloneable$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let OnLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnLarge$impl');
let OnMedium = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnMedium$impl');
let OnSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnSmall$impl');
let OnXLarge = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXLarge$impl');
let OnXSmall = goog.forwardDeclare('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @deprecated
 * @extends {BaseDominoElement<HTMLDivElement, Column>}
 * @implements {Cloneable}
  */
class Column extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_column__org_dominokit_domino_ui_column_Column_;
    /** @public {OnXLarge} */
    this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnLarge} */
    this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnMedium} */
    this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnSmall} */
    this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {OnXSmall} */
    this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_;
    /** @public {List<?string>} */
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_;
  }
  
  /**
   * @param {HTMLDivElement} htmlDivElement
   * @return {!Column}
   * @public
   */
  static $create__elemental2_dom_HTMLDivElement(htmlDivElement) {
    Column.$clinit();
    let $instance = new Column();
    $instance.$ctor__org_dominokit_domino_ui_column_Column__elemental2_dom_HTMLDivElement(htmlDivElement);
    return $instance;
  }
  
  /**
   * @param {HTMLDivElement} htmlDivElement
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_column_Column__elemental2_dom_HTMLDivElement(htmlDivElement) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_column_Column();
    this.f_column__org_dominokit_domino_ui_column_Column_ = htmlDivElement;
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_create__() {
    Column.$clinit();
    return Column.$create__elemental2_dom_HTMLDivElement(/**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), $Overlay)));
  }
  
  /**
   * @param {number} xLarge
   * @param {number} large
   * @param {number} medium
   * @param {number} small
   * @param {number} xsmall
   * @return {Column}
   * @public
   */
  static m_create__int__int__int__int__int(xLarge, large, medium, small, xsmall) {
    Column.$clinit();
    return Column.m_create__().m_onXLarge__org_dominokit_domino_ui_column_Column_OnXLarge(OnXLarge.m_of__int(xLarge)).m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.m_of__int(large)).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.m_of__int(medium)).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.m_of__int(small)).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.m_of__int(xsmall));
  }
  
  /**
   * @param {number} large
   * @param {number} medium
   * @param {number} small
   * @param {number} xsmall
   * @return {Column}
   * @public
   */
  static m_create__int__int__int__int(large, medium, small, xsmall) {
    Column.$clinit();
    return Column.m_create__int__int__int__int__int(large, large, medium, small, xsmall);
  }
  
  /**
   * @param {number} mediumAnUp
   * @param {number} smallAndDown
   * @return {Column}
   * @public
   */
  static m_create__int__int(mediumAnUp, smallAndDown) {
    Column.$clinit();
    return Column.m_create__int__int__int__int__int(mediumAnUp, mediumAnUp, mediumAnUp, smallAndDown, smallAndDown);
  }
  
  /**
   * @param {number} columnsOnAllScreens
   * @return {Column}
   * @public
   */
  static m_create__int(columnsOnAllScreens) {
    Column.$clinit();
    return Column.m_create__().m_onXLarge__org_dominokit_domino_ui_column_Column_OnXLarge(OnXLarge.m_of__int(columnsOnAllScreens)).m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(OnLarge.m_of__int(columnsOnAllScreens)).m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(OnMedium.m_of__int(columnsOnAllScreens)).m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(OnSmall.m_of__int(columnsOnAllScreens)).m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(OnXSmall.m_of__int(columnsOnAllScreens));
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span1__() {
    Column.$clinit();
    return Column.m_create__int__int(1, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span2__() {
    Column.$clinit();
    return Column.m_create__int__int(2, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span3__() {
    Column.$clinit();
    return Column.m_create__int__int(3, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span4__() {
    Column.$clinit();
    return Column.m_create__int__int(4, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span5__() {
    Column.$clinit();
    return Column.m_create__int__int(5, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span6__() {
    Column.$clinit();
    return Column.m_create__int__int(6, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span7__() {
    Column.$clinit();
    return Column.m_create__int__int(7, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span8__() {
    Column.$clinit();
    return Column.m_create__int__int(8, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span9__() {
    Column.$clinit();
    return Column.m_create__int__int(9, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span10__() {
    Column.$clinit();
    return Column.m_create__int__int(10, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span11__() {
    Column.$clinit();
    return Column.m_create__int__int(11, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  static m_span12__() {
    Column.$clinit();
    return Column.m_create__int__int(12, 12);
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_copy__() {
    let column = Column.m_create__();
    if (Objects.m_nonNull__java_lang_Object(this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onXLarge__org_dominokit_domino_ui_column_Column_OnXLarge(this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      column.m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_);
    }
    if (this.m_asElement__().classList.contains(Styles.f_align_center__org_dominokit_domino_ui_style_Styles)) {
      column.m_centerContent__();
    }
    for (let i = 0; i < this.f_cssClasses__org_dominokit_domino_ui_column_Column_.size(); i++) {
      column.m_addCssClass__java_lang_String(/**@type {?string} */ ($Casts.$to(this.f_cssClasses__org_dominokit_domino_ui_column_Column_.getAtIndex(i), j_l_String)));
    }
    return column;
  }
  
  /**
   * @param {Node} element
   * @return {Column}
   * @public
   */
  m_addElement__elemental2_dom_Node(element) {
    this.m_asElement__().appendChild(element);
    return this;
  }
  
  /**
   * @param {IsElement<?>} element
   * @return {Column}
   * @public
   */
  m_addElement__org_jboss_gwt_elemento_core_IsElement(element) {
    this.m_asElement__().appendChild(element.m_asElement__());
    return this;
  }
  
  /**
   * @param {OnXLarge} onXLarge
   * @return {Column}
   * @public
   */
  m_onXLarge__org_dominokit_domino_ui_column_Column_OnXLarge(onXLarge) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_ = onXLarge;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onXLargeStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnLarge} onLarge
   * @return {Column}
   * @public
   */
  m_onLarge__org_dominokit_domino_ui_column_Column_OnLarge(onLarge) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_ = onLarge;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onLargeStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnMedium} onMedium
   * @return {Column}
   * @public
   */
  m_onMedium__org_dominokit_domino_ui_column_Column_OnMedium(onMedium) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_ = onMedium;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onMediumStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnSmall} onSmall
   * @return {Column}
   * @public
   */
  m_onSmall__org_dominokit_domino_ui_column_Column_OnSmall(onSmall) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_ = onSmall;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @param {OnXSmall} onXSmall
   * @return {Column}
   * @public
   */
  m_onXSmall__org_dominokit_domino_ui_column_Column_OnXSmall(onXSmall) {
    if (Objects.m_nonNull__java_lang_Object(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_)) {
      this.f_column__org_dominokit_domino_ui_column_Column_.classList.remove(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    }
    this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_ = onXSmall;
    this.f_column__org_dominokit_domino_ui_column_Column_.classList.add(this.f_onXSmallStyle__org_dominokit_domino_ui_column_Column_.m_getStyle__());
    return this;
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_centerContent__() {
    this.m_asElement__().classList.add(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_deCenterContent__() {
    this.m_asElement__().classList.remove(Styles.f_align_center__org_dominokit_domino_ui_style_Styles);
    return this;
  }
  
  /**
   * @param {?string} cssClass
   * @return {Column}
   * @public
   */
  m_addCssClass__java_lang_String(cssClass) {
    this.m_asElement__().classList.add(cssClass);
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_.add(cssClass);
    return this;
  }
  
  /**
   * @param {?string} cssClass
   * @return {Column}
   * @public
   */
  m_removeCssClass__java_lang_String(cssClass) {
    this.m_asElement__().classList.remove(cssClass);
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_.remove(cssClass);
    return this;
  }
  
  /**
   * @return {Column}
   * @public
   */
  m_condenced__() {
    return /**@type {Column} */ ($Casts.$to(/**@type {Style<HTMLDivElement, Column>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this)).m_setMarginBottom__java_lang_String("0px").m_get__(), Column));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_column__org_dominokit_domino_ui_column_Column_;
  }
  
  /**
   * @param {number} size
   * @return {?string}
   * @public
   */
  static m_asNumberString__int_$p_org_dominokit_domino_ui_column_Column(size) {
    Column.$clinit();
    switch (size) {
      case 1: 
        return "one";
      case 2: 
        return "two";
      case 3: 
        return "three";
      case 4: 
        return "four";
      case 5: 
        return "five";
      case 6: 
        return "six";
      case 7: 
        return "seven";
      case 8: 
        return "eight";
      case 9: 
        return "nine";
      case 10: 
        return "ten";
      case 11: 
        return "eleven";
      case 12: 
        return "twelve";
      default: 
        return "twelve";
    }
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_column_Column() {
    this.f_cssClasses__org_dominokit_domino_ui_column_Column_ = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Column.$clinit = (() =>{
    });
    Column.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Column;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Column);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    OnLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnLarge$impl');
    OnMedium = goog.module.get('org.dominokit.domino.ui.column.Column.OnMedium$impl');
    OnSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnSmall$impl');
    OnXLarge = goog.module.get('org.dominokit.domino.ui.column.Column.OnXLarge$impl');
    OnXSmall = goog.module.get('org.dominokit.domino.ui.column.Column.OnXSmall$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Column, $Util.$makeClassName('org.dominokit.domino.ui.column.Column'));


Cloneable.$markImplementor(Column);


exports = Column; 
//# sourceMappingURL=Column.js.map