/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DateBox.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datepicker.DateBox');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _ValueBox = goog.require('org.dominokit.domino.ui.forms.ValueBox');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _HTMLInputElement_$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.KeyboardEvent.$Overlay');
const _MutationRecord_$Overlay = goog.require('elemental2.dom.MutationRecord.$Overlay');
const _IllegalArgumentException = goog.require('java.lang.IllegalArgumentException');
const _j_l_String = goog.require('java.lang.String');
const _Date = goog.require('java.util.Date');
const _Objects = goog.require('java.util.Objects');
const _Js = goog.require('jsinterop.base.Js');
const _$LambdaAdaptor$33 = goog.require('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$33');
const _$LambdaAdaptor$34 = goog.require('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$34');
const _$LambdaAdaptor$35 = goog.require('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$35');
const _$LambdaAdaptor$36 = goog.require('org.dominokit.domino.ui.datepicker.DateBox.$LambdaAdaptor$36');
const _Formatter = goog.require('org.dominokit.domino.ui.datepicker.DateBox.Formatter');
const _Pattern = goog.require('org.dominokit.domino.ui.datepicker.DateBox.Pattern');
const _PickerStyle = goog.require('org.dominokit.domino.ui.datepicker.DateBox.PickerStyle');
const _DatePicker = goog.require('org.dominokit.domino.ui.datepicker.DatePicker');
const _BackgroundHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler');
const _DateSelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler');
const _ValidationResult = goog.require('org.dominokit.domino.ui.forms.validations.ValidationResult');
const _CloseHandler = goog.require('org.dominokit.domino.ui.modals.IsModalDialog.CloseHandler');
const _ModalDialog = goog.require('org.dominokit.domino.ui.modals.ModalDialog');
const _PickerHandler = goog.require('org.dominokit.domino.ui.pickers.PickerHandler');
const _Popover = goog.require('org.dominokit.domino.ui.popover.Popover');
const _PopupPosition = goog.require('org.dominokit.domino.ui.popover.PopupPosition');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Validator = goog.require('org.dominokit.domino.ui.utils.HasValidation.Validator');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback');
const _InputBuilder = goog.require('org.jboss.gwt.elemento.core.builder.InputBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var DateBox = goog.require('org.dominokit.domino.ui.datepicker.DateBox$impl');
exports = DateBox;
 