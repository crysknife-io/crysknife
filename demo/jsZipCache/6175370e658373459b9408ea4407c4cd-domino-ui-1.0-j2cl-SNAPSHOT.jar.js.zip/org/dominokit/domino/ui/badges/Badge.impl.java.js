/**
 * @fileoverview transpiled from org.dominokit.domino.ui.badges.Badge.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.badges.Badge$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @extends {BaseDominoElement<HTMLElement, Badge>}
 * @implements {HasBackground<Badge>}
  */
class Badge extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLElement>} */
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_;
    /** @public {Color} */
    this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_;
    /** @public {Text} */
    this.f_textNode__org_dominokit_domino_ui_badges_Badge_;
  }
  
  /**
   * @return {!Badge}
   * @public
   */
  static $create__() {
    Badge.$clinit();
    let $instance = new Badge();
    $instance.$ctor__org_dominokit_domino_ui_badges_Badge__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_badges_Badge__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_badges_Badge();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {?string} content
   * @return {Badge}
   * @public
   */
  static m_create__java_lang_String(content) {
    Badge.$clinit();
    let badge = Badge.$create__();
    badge.f_textNode__org_dominokit_domino_ui_badges_Badge_.textContent = content;
    badge.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.m_appendChild__elemental2_dom_Node(badge.f_textNode__org_dominokit_domino_ui_badges_Badge_);
    return badge;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.m_asElement__();
  }
  
  /**
   * @param {?string} text
   * @return {Badge}
   * @public
   */
  m_setText__java_lang_String(text) {
    this.f_textNode__org_dominokit_domino_ui_badges_Badge_.textContent = text;
    return this;
  }
  
  /**
   * @return {Badge}
   * @public
   */
  m_pullRight__() {
    this.m_style__().m_pullRight__();
    return this;
  }
  
  /**
   * @override
   * @param {Color} badgeBackground
   * @return {Badge}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(badgeBackground) {
    if (Objects.m_nonNull__java_lang_Object(this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_)) {
      this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.m_style__().m_remove__java_lang_String(this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_.m_getBackground__());
    }
    this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_ = badgeBackground;
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_.m_style__().m_add__java_lang_String(this.f_badgeBackground__org_dominokit_domino_ui_badges_Badge_.m_getBackground__());
    return this;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_badges_Badge() {
    this.f_badgeElement__org_dominokit_domino_ui_badges_Badge_ = /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["badge"], j_l_String)))));
    this.f_textNode__org_dominokit_domino_ui_badges_Badge_ = TextNode.m_empty__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Badge.$clinit = (() =>{
    });
    Badge.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Badge;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Badge);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
  }
  
  
};

$Util.$setClassMetadata(Badge, $Util.$makeClassName('org.dominokit.domino.ui.badges.Badge'));


HasBackground.$markImplementor(Badge);


exports = Badge; 
//# sourceMappingURL=Badge.js.map