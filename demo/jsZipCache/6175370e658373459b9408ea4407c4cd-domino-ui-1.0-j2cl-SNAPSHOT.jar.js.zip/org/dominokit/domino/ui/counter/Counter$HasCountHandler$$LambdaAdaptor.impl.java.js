/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$HasCountHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.HasCountHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasCountHandler = goog.require('org.dominokit.domino.ui.counter.Counter.HasCountHandler$impl');

let Counter = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter$impl');
let CountHandler = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.CountHandler$impl');


/**
 * @implements {HasCountHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(CountHandler):Counter} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(CountHandler):Counter} */
    this.f_$$fn__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$LambdaAdaptor__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$JsFunction(fn);
  }
  
  /**
   * @param {?function(CountHandler):Counter} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$LambdaAdaptor__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {CountHandler} arg0
   * @return {Counter}
   * @public
   */
  m_onCount__org_dominokit_domino_ui_counter_Counter_CountHandler(arg0) {
    let /** ?function(CountHandler):Counter */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_counter_Counter_HasCountHandler_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$HasCountHandler$$LambdaAdaptor'));


HasCountHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Counter$HasCountHandler$$LambdaAdaptor.js.map