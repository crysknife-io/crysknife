/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$StripesTableAction.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor$22 = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction.$LambdaAdaptor$22');
const _Icon = goog.require('org.dominokit.domino.ui.icons.Icon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ElementHandler = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var StripesTableAction = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.StripesTableAction$impl');
exports = StripesTableAction;
 