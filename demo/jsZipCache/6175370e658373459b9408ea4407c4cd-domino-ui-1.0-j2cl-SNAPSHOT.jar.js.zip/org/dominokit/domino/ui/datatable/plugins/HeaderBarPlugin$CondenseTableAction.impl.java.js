/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$CondenseTableAction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.CondenseTableAction$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$21 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.CondenseTableAction.$LambdaAdaptor$21$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_CondenseTableAction_T
 * @implements {HeaderActionElement<C_CondenseTableAction_T>}
  */
class CondenseTableAction extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_CondenseTableAction_T
   * @return {!CondenseTableAction<C_CondenseTableAction_T>}
   * @public
   */
  static $create__() {
    CondenseTableAction.$clinit();
    let $instance = new CondenseTableAction();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_CondenseTableAction__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_CondenseTableAction__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {DataTable<C_CondenseTableAction_T>} dataTable
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    let condenseIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_line_weight__().m_clickable__(), Icon)).m_setTooltip__java_lang_String("Condense"), Icon)).m_setToggleIcon__org_dominokit_domino_ui_icons_BaseIcon(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_format_line_spacing__()), Icon)).m_toggleOnClick__boolean(true), Icon)).m_apply__org_dominokit_domino_ui_utils_BaseDominoElement_ElementHandler(ElementHandler.$adapt(((/** Icon */ icon) =>{
      icon.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$21(((/** Event */ evt) =>{
        if (dataTable.m_isCondensed__()) {
          dataTable.m_expand__();
          icon.m_setTooltip__java_lang_String("Condense");
        } else {
          dataTable.m_condense__();
          icon.m_setTooltip__java_lang_String("Expand");
        }
      })));
    }))), Icon));
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(condenseIcon), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    HeaderActionElement.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CondenseTableAction.$clinit = (() =>{
    });
    CondenseTableAction.$loadModules();
    j_l_Object.$clinit();
    HeaderActionElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CondenseTableAction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CondenseTableAction);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor$21 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.CondenseTableAction.$LambdaAdaptor$21$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementHandler = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.ElementHandler$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(CondenseTableAction, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$CondenseTableAction'));


HeaderActionElement.$markImplementor(CondenseTableAction);


exports = CondenseTableAction; 
//# sourceMappingURL=HeaderBarPlugin$CondenseTableAction.js.map