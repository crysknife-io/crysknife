/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.StoreDataChangeListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let DataChangedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 */
class StoreDataChangeListener {
  /**
   * @abstract
   * @param {DataChangedEvent<C_T>} dataChangedEvent
   * @return {void}
   * @public
   */
  m_onDataChanged__org_dominokit_domino_ui_datatable_store_DataChangedEvent(dataChangedEvent) {
  }
  
  /**
   * @template C_T
   * @param {?function(DataChangedEvent<C_T>):void} fn
   * @return {StoreDataChangeListener<C_T>}
   * @public
   */
  static $adapt(fn) {
    StoreDataChangeListener.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    StoreDataChangeListener.$clinit = (() =>{
    });
    StoreDataChangeListener.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(StoreDataChangeListener, $Util.$makeClassName('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener'));


StoreDataChangeListener.$markImplementor(/** @type {Function} */ (StoreDataChangeListener));


exports = StoreDataChangeListener; 
//# sourceMappingURL=StoreDataChangeListener.js.map