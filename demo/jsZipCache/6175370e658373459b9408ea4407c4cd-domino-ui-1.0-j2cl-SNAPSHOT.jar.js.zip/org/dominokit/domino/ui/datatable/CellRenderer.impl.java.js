/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.CellRenderer.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.CellRenderer$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.$LambdaAdaptor$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');


/**
 * @interface
 * @template C_T
 */
class CellRenderer {
  /**
   * @abstract
   * @param {CellInfo<C_T>} cellInfo
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cellInfo) {
  }
  
  /**
   * @template C_T
   * @param {?function(CellInfo<C_T>):Node} fn
   * @return {CellRenderer<C_T>}
   * @public
   */
  static $adapt(fn) {
    CellRenderer.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CellRenderer.$clinit = (() =>{
    });
    CellRenderer.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_CellRenderer = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_CellRenderer;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_CellRenderer;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CellRenderer, $Util.$makeClassName('org.dominokit.domino.ui.datatable.CellRenderer'));


CellRenderer.$markImplementor(/** @type {Function} */ (CellRenderer));


exports = CellRenderer; 
//# sourceMappingURL=CellRenderer.js.map