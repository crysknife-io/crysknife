package org.dominokit.domino.ui.datatable.plugins;

public interface IsRecordDetailsPlugin<T> {

    void collapse();

    void expand();

}
