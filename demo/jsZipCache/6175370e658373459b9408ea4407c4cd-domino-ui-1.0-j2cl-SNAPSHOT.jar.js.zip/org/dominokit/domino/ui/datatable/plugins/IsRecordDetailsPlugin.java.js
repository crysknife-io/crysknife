/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.IsRecordDetailsPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.IsRecordDetailsPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var IsRecordDetailsPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.IsRecordDetailsPlugin$impl');
exports = IsRecordDetailsPlugin;
 