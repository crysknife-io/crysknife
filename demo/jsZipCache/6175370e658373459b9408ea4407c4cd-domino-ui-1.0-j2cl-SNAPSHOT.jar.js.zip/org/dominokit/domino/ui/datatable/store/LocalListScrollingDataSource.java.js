/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataStore = goog.require('org.dominokit.domino.ui.datatable.store.DataStore');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Predicate = goog.require('java.util.function.Predicate');
const _Collector = goog.require('java.util.stream.Collector');
const _Collectors = goog.require('java.util.stream.Collectors');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _BodyScrollEvent = goog.require('org.dominokit.domino.ui.datatable.events.BodyScrollEvent');
const _SearchEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchEvent');
const _SortEvent = goog.require('org.dominokit.domino.ui.datatable.events.SortEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _ScrollPosition = goog.require('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition');
const _DataChangedEvent = goog.require('org.dominokit.domino.ui.datatable.store.DataChangedEvent');
const _RecordsSorter = goog.require('org.dominokit.domino.ui.datatable.store.RecordsSorter');
const _SearchFilter = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter');
const _StoreDataChangeListener = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var LocalListScrollingDataSource = goog.require('org.dominokit.domino.ui.datatable.store.LocalListScrollingDataSource$impl');
exports = LocalListScrollingDataSource;
 