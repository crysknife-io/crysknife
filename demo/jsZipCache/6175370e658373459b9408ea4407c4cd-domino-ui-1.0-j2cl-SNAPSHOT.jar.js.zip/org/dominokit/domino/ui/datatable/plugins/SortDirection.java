package org.dominokit.domino.ui.datatable.plugins;

public enum SortDirection {
    ASC, DESC
}
