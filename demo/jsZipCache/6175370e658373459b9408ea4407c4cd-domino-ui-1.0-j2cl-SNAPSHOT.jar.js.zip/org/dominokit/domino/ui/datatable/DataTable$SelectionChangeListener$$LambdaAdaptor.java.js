/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable$SelectionChangeListener$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SelectionChangeListener = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener');
const _List = goog.require('java.util.List');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 