/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.IsRecordDetailsPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.IsRecordDetailsPlugin$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @template C_T
 */
class IsRecordDetailsPlugin {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_collapse__() {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_expand__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    IsRecordDetailsPlugin.$clinit = (() =>{
    });
    IsRecordDetailsPlugin.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_IsRecordDetailsPlugin = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_plugins_IsRecordDetailsPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_IsRecordDetailsPlugin;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(IsRecordDetailsPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.IsRecordDetailsPlugin'));


IsRecordDetailsPlugin.$markImplementor(/** @type {Function} */ (IsRecordDetailsPlugin));


exports = IsRecordDetailsPlugin; 
//# sourceMappingURL=IsRecordDetailsPlugin.js.map