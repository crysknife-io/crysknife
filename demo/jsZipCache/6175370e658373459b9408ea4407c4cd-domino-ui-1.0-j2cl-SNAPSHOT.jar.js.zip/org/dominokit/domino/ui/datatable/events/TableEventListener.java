package org.dominokit.domino.ui.datatable.events;

public interface TableEventListener {
    void handleEvent(TableEvent event);
}
