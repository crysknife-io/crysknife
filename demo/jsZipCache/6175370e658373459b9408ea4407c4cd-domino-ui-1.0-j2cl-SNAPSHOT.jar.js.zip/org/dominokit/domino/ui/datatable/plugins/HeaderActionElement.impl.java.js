/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 * @extends {TableEventListener}
 */
class HeaderActionElement {
  /**
   * @abstract
   * @param {DataTable<C_T>} dataTable
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
  }
  
  /**
   * @abstract
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
  }
  
  /**
   * @template C_T
   * @param {?function(DataTable<C_T>):Node} fn
   * @return {HeaderActionElement<C_T>}
   * @public
   */
  static $adapt(fn) {
    HeaderActionElement.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @template C_T
   * @param {HeaderActionElement<C_T>} $thisArg
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  static m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement__org_dominokit_domino_ui_datatable_events_TableEvent($thisArg, event) {
    HeaderActionElement.$clinit();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HeaderActionElement.$clinit = (() =>{
    });
    HeaderActionElement.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    TableEventListener.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HeaderActionElement, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement'));


HeaderActionElement.$markImplementor(/** @type {Function} */ (HeaderActionElement));


exports = HeaderActionElement; 
//# sourceMappingURL=HeaderActionElement.js.map