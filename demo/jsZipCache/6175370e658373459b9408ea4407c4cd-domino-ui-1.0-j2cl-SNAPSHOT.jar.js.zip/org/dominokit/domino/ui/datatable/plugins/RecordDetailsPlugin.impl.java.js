/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLTableCellElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let HTMLTableRowElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let CellRenderer = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let HeaderElement = goog.forwardDeclare('org.dominokit.domino.ui.datatable.HeaderElement$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let ExpandRecordEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.ExpandRecordEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let DetailsButtonElement = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class RecordDetailsPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {BaseIcon<?>} */
    this.f_collapseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {BaseIcon<?>} */
    this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {HTMLTableCellElement} */
    this.f_td__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {HTMLTableRowElement} */
    this.f_tr__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {CellRenderer<C_T>} */
    this.f_cellRenderer__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {DetailsButtonElement} */
    this.f_buttonElement__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
    /** @public {DataTable<C_T>} */
    this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
  }
  
  /**
   * Factory method corresponding to constructor 'RecordDetailsPlugin(CellRenderer)'.
   * @template C_T
   * @param {CellRenderer<C_T>} cellRenderer
   * @return {!RecordDetailsPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_CellRenderer(cellRenderer) {
    RecordDetailsPlugin.$clinit();
    let $instance = new RecordDetailsPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer(cellRenderer);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RecordDetailsPlugin(CellRenderer)'.
   * @param {CellRenderer<C_T>} cellRenderer
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer(cellRenderer) {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon(cellRenderer, Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_fullscreen_exit__(), Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_fullscreen__());
  }
  
  /**
   * Factory method corresponding to constructor 'RecordDetailsPlugin(CellRenderer, BaseIcon, BaseIcon)'.
   * @template C_T
   * @param {CellRenderer<C_T>} cellRenderer
   * @param {BaseIcon<?>} collapseIcon
   * @param {BaseIcon<?>} expandIcon
   * @return {!RecordDetailsPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_CellRenderer__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon(cellRenderer, collapseIcon, expandIcon) {
    RecordDetailsPlugin.$clinit();
    let $instance = new RecordDetailsPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon(cellRenderer, collapseIcon, expandIcon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'RecordDetailsPlugin(CellRenderer, BaseIcon, BaseIcon)'.
   * @param {CellRenderer<C_T>} cellRenderer
   * @param {BaseIcon<?>} collapseIcon
   * @param {BaseIcon<?>} expandIcon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon(cellRenderer, collapseIcon, expandIcon) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin();
    this.f_cellRenderer__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = cellRenderer;
    this.f_collapseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = collapseIcon;
    this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = expandIcon;
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = dataTable;
    let column = /**@type {ColumnConfig<C_T>} */ (ColumnConfig.m_create__java_lang_String("data-table-details-cm")).m_setSortable__boolean(false).m_setWidth__java_lang_String("60px").m_setFixed__boolean(true).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(/**@type {CellRenderer<C_T>} */ (CellRenderer.$adapt(((/** CellInfo<*> */ cell) =>{
      this.m_applyStyles__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell);
      let detailsButtonElement = /**@type {!DetailsButtonElement<*>} */ (DetailsButtonElement.$create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_, this.f_collapseIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_, this, cell));
      cell.m_getTableRow__().m_addMetaObject__org_dominokit_domino_ui_datatable_TableRow_RowMetaObject(detailsButtonElement);
      this.m_applyStyles__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell);
      return detailsButtonElement.m_asElement__();
    })))).m_setHeaderElement__org_dominokit_domino_ui_datatable_HeaderElement(HeaderElement.$adapt(((/** ?string */ columnTitle) =>{
      return /**@type {Button} */ ($Casts.$to(/**@type {Button} */ ($Casts.$to(Button.m_create__org_dominokit_domino_ui_icons_BaseIcon(this.f_expandIcon__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.m_copy__()).m_linkify__(), Button)).m_disable__(), Button)).m_style__().m_setProperty__java_lang_String__java_lang_String("padding", "0px").m_setHeight__java_lang_String("24px").m_asElement__();
    }))).m_asHeader__().m_textAlign__java_lang_String("center");
    this.m_setupColumn__org_dominokit_domino_ui_datatable_ColumnConfig(column);
    dataTable.m_getTableConfig__().m_insertColumnFirst__org_dominokit_domino_ui_datatable_ColumnConfig(column);
  }
  
  /**
   * @override
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
    if (j_l_String.m_equals__java_lang_String__java_lang_Object(ExpandRecordEvent.f_EXPAND_RECORD__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent, event.m_getType__())) {
      this.m_expandRow__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent_$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin(/**@type {ExpandRecordEvent<C_T>} */ ($Casts.$to(event, ExpandRecordEvent)));
    }
  }
  
  /**
   * @param {ExpandRecordEvent<C_T>} event
   * @return {void}
   * @public
   */
  m_expandRow__org_dominokit_domino_ui_datatable_events_ExpandRecordEvent_$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin(event) {
    let detailsButtonElement = /**@type {DetailsButtonElement<C_T>} */ ($Casts.$to(event.m_getTableRow__().m_getMetaObject__java_lang_String(RecordDetailsPlugin.f_RECORD_DETAILS_BUTTON__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin), DetailsButtonElement));
    this.m_setExpanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin(detailsButtonElement);
  }
  
  /**
   * @return {HTMLDivElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
  }
  
  /**
   * @return {HTMLTableCellElement}
   * @public
   */
  m_getTd__() {
    return this.f_td__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
  }
  
  /**
   * @return {HTMLTableRowElement}
   * @public
   */
  m_getTr__() {
    return this.f_tr__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_;
  }
  
  /**
   * @param {CellInfo<C_T>} cellInfo
   * @return {void}
   * @public
   */
  m_applyStyles__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cellInfo) {
  }
  
  /**
   * @param {ColumnConfig<C_T>} column
   * @return {void}
   * @public
   */
  m_setupColumn__org_dominokit_domino_ui_datatable_ColumnConfig(column) {
  }
  
  /**
   * @return {void}
   * @public
   */
  m_clear___$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin() {
    this.f_tr__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.remove();
    ElementUtil.m_clear__elemental2_dom_Element(this.f_element__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_);
    this.f_buttonElement__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = null;
  }
  
  /**
   * @param {DetailsButtonElement} buttonElement
   * @return {void}
   * @public
   */
  m_setExpanded__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_DetailsButtonElement_$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin(buttonElement) {
    if (Objects.m_nonNull__java_lang_Object(this.f_buttonElement__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_)) {
      this.f_buttonElement__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.m_collapse__();
      this.m_clear___$p_org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin();
    }
    this.f_buttonElement__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = buttonElement;
    /**@type {HtmlContentBuilder<HTMLTableCellElement>} */ (ElementUtil.m_contentBuilder__elemental2_dom_HTMLElement(this.f_td__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_)).m_attr__java_lang_String__java_lang_String("colspan", this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.m_getTableConfig__().m_getColumns__().size() + "");
    this.f_element__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.appendChild(this.f_cellRenderer__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.m_asElement__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(buttonElement.m_getCellInfo__()));
    /**@type {HTMLTableSectionElement} */ ($Casts.$to(this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_.m_bodyElement__().m_asElement__(), $Overlay)).insertBefore(this.f_tr__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_, buttonElement.m_getCellInfo__().m_getTableRow__().m_asElement__().nextSibling);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin() {
    this.f_element__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = /**@type {HTMLDivElement} */ ($Casts.$to(Elements.m_div__().m_asElement__(), HTMLDivElement_$Overlay));
    this.f_td__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = /**@type {HTMLTableCellElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableCellElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableCellElement>} */ ($Casts.$to(Elements.m_td__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["details-td"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_element__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_), HtmlContentBuilder)).m_asElement__(), HTMLTableCellElement_$Overlay));
    this.f_tr__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_ = /**@type {HTMLTableRowElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLTableRowElement>} */ ($Casts.$to(Elements.m_tr__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["details-tr"], j_l_String))), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_td__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin_), HtmlContentBuilder)).m_asElement__(), HTMLTableRowElement_$Overlay));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RecordDetailsPlugin.$clinit = (() =>{
    });
    RecordDetailsPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RecordDetailsPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RecordDetailsPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLTableCellElement_$Overlay = goog.module.get('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
    HTMLTableRowElement_$Overlay = goog.module.get('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Button = goog.module.get('org.dominokit.domino.ui.button.Button$impl');
    CellRenderer = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer$impl');
    ColumnConfig = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
    HeaderElement = goog.module.get('org.dominokit.domino.ui.datatable.HeaderElement$impl');
    ExpandRecordEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.ExpandRecordEvent$impl');
    DetailsButtonElement = goog.module.get('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(RecordDetailsPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin'));


/** @public {?string} @const */
RecordDetailsPlugin.f_RECORD_DETAILS_BUTTON__org_dominokit_domino_ui_datatable_plugins_RecordDetailsPlugin = "record-details-button";


DataTablePlugin.$markImplementor(RecordDetailsPlugin);


exports = RecordDetailsPlugin; 
//# sourceMappingURL=RecordDetailsPlugin.js.map