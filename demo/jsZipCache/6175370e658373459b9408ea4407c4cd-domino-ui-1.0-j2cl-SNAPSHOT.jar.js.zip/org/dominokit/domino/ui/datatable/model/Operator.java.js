/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.Operator.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.model.Operator');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Objects = goog.require('java.util.Objects');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Operator = goog.require('org.dominokit.domino.ui.datatable.model.Operator$impl');
exports = Operator;
 