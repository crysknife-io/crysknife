/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.ShortHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.ShortHeaderFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DelayedHeaderFilterInput = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let ShortBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.ShortBox$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {DelayedHeaderFilterInput<ShortBox, C_T>}
  */
class ShortHeaderFilter extends DelayedHeaderFilterInput {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {ShortBox} */
    this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_;
  }
  
  /**
   * @template C_T
   * @return {!ShortHeaderFilter<C_T>}
   * @public
   */
  static $create__() {
    ShortHeaderFilter.$clinit();
    let $instance = new ShortHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput__();
  }
  
  /**
   * @template M_T
   * @return {ShortHeaderFilter<M_T>}
   * @public
   */
  static m_create__() {
    ShortHeaderFilter.$clinit();
    return /**@type {!ShortHeaderFilter<*>} */ (ShortHeaderFilter.$create__());
  }
  
  /**
   * @override
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
    return /**@type {HTMLInputElement} */ ($Casts.$to(this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {ShortBox}
   * @public
   */
  m_createValueBox__() {
    this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_ = ShortBox.m_create__();
    return this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_isEmpty__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return j_l_String.m_valueOf__java_lang_Object(this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_getValue__()) + "";
  }
  
  /**
   * @override
   * @return {FilterTypes}
   * @public
   */
  m_getType__() {
    return FilterTypes.f_SHORT__org_dominokit_domino_ui_datatable_model_FilterTypes;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_pauseChangeHandlers__();
    this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_clear__();
    /**@type {HTMLInputElement} */ ($Casts.$to(this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay)).value = "";
    this.f_shortBox__org_dominokit_domino_ui_datatable_plugins_filter_header_ShortHeaderFilter_.m_resumeChangeHandlers__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ShortHeaderFilter.$clinit = (() =>{
    });
    ShortHeaderFilter.$loadModules();
    DelayedHeaderFilterInput.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ShortHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ShortHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    ShortBox = goog.module.get('org.dominokit.domino.ui.forms.ShortBox$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ShortHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.ShortHeaderFilter'));




exports = ShortHeaderFilter; 
//# sourceMappingURL=ShortHeaderFilter.js.map