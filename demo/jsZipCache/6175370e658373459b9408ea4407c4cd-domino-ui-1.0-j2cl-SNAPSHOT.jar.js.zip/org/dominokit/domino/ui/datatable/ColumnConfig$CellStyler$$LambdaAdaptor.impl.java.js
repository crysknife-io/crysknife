/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.ColumnConfig$CellStyler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CellStyler = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');


/**
 * @template C_CellStyler_T
 * @implements {CellStyler<C_CellStyler_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(HTMLTableCellElement):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(HTMLTableCellElement):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$LambdaAdaptor__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$JsFunction(fn);
  }
  
  /**
   * @param {?function(HTMLTableCellElement):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$LambdaAdaptor__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {HTMLTableCellElement} arg0
   * @return {void}
   * @public
   */
  m_styleCell__elemental2_dom_HTMLTableCellElement(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.ColumnConfig$CellStyler$$LambdaAdaptor'));


CellStyler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ColumnConfig$CellStyler$$LambdaAdaptor.js.map