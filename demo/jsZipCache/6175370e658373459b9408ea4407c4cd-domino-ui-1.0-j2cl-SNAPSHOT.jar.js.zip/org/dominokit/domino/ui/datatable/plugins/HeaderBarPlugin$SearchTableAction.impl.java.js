/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$SearchTableAction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let KeyboardEvent_$Overlay = goog.forwardDeclare('elemental2.dom.KeyboardEvent.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let SearchClearedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let $1 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$1$impl');
let $LambdaAdaptor$26 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$26$impl');
let $LambdaAdaptor$27 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$27$impl');
let $LambdaAdaptor$28 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$28$impl');
let $LambdaAdaptor$29 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$29$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let Icon = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let Timer = goog.forwardDeclare('org.gwtproject.timer.client.Timer$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_SearchTableAction_T
 * @implements {HeaderActionElement<C_SearchTableAction_T>}
  */
class SearchTableAction extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_autoSearchDelay__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = 0;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
    /** @public {DataTable<C_SearchTableAction_T>} */
    this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
    /** @public {TextBox} */
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
    /** @public {boolean} */
    this.f_autoSearch__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = false;
    /** @public {Timer} */
    this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
    /** @public {EventListener} */
    this.f_autoSearchEventListener__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
  }
  
  /**
   * @template C_SearchTableAction_T
   * @return {!SearchTableAction<C_SearchTableAction_T>}
   * @public
   */
  static $create__() {
    SearchTableAction.$clinit();
    let $instance = new SearchTableAction();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction();
    let searchIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_search__().m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$26(((/** Event */ evt) =>{
      this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_cancel__();
      this.m_doSearch___$p_org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction();
    }))), Icon)).m_setTooltip__java_lang_String("Search"), Icon)).m_style__().m_setCursor__java_lang_String("pointer").m_get__(), Icon));
    let clearIcon = /**@type {Icon} */ ($Casts.$to(/**@type {Icon} */ ($Casts.$to(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_clear__().m_setTooltip__java_lang_String("Clear"), Icon)).m_style__().m_setCursor__java_lang_String("pointer").m_get__(), Icon));
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = /**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(/**@type {TextBox} */ ($Casts.$to(TextBox.m_create__().m_setPlaceholder__java_lang_String("Search"), TextBox)).m_setLeftAddon__org_jboss_gwt_elemento_core_IsElement(searchIcon), TextBox)).m_setRightAddon__org_jboss_gwt_elemento_core_IsElement(clearIcon), TextBox)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, TextBox> */ style) =>{
      style.m_add__java_lang_String("table-search-box").m_setMarginBottom__java_lang_String("0px").m_setMaxWidth__java_lang_String("300px").m_add__java_lang_String(Styles.f_pull_right__org_dominokit_domino_ui_style_Styles);
    }))), TextBox));
    clearIcon.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$27(((/** Event */ evt$1$) =>{
      this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_clear__();
      this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_cancel__();
      this.m_doSearch___$p_org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction();
    })));
    this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.appendChild(this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_asElement__());
    this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = /**@type {!$1<C_SearchTableAction_T>} */ ($1.$create__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction(this));
    this.f_autoSearchEventListener__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = new $LambdaAdaptor$28(((/** Event */ evt$2$) =>{
      this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_cancel__();
      this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_schedule__int(this.f_autoSearchDelay__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_);
    }));
    this.m_setAutoSearch__boolean(true);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isAutoSearch__() {
    return this.f_autoSearch__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
  }
  
  /**
   * @param {boolean} autoSearch
   * @return {SearchTableAction<C_SearchTableAction_T>}
   * @public
   */
  m_setAutoSearch__boolean(autoSearch) {
    this.f_autoSearch__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = autoSearch;
    if (autoSearch) {
      this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("input", this.f_autoSearchEventListener__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_);
    } else {
      this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_removeEventListener__java_lang_String__elemental2_dom_EventListener("input", this.f_autoSearchEventListener__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_);
      this.f_autoSearchTimer__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_cancel__();
    }
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_keypress__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$29(((/** Event */ evt) =>{
      if (ElementUtil.m_isEnterKey__elemental2_dom_KeyboardEvent(/**@type {KeyboardEvent} */ (Js.m_uncheckedCast__java_lang_Object(evt)))) {
        this.m_doSearch___$p_org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction();
      }
    })));
    return this;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getAutoSearchDelay__() {
    return this.f_autoSearchDelay__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
  }
  
  /**
   * @param {number} autoSearchDelayInMillies
   * @return {void}
   * @public
   */
  m_setAutoSearchDelay__int(autoSearchDelayInMillies) {
    this.f_autoSearchDelay__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = autoSearchDelayInMillies;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_doSearch___$p_org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction() {
    let searchContext = this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_getSearchContext__();
    let search = Category.f_SEARCH__org_dominokit_domino_ui_datatable_model_Category;
    searchContext.m_removeByCategory__org_dominokit_domino_ui_datatable_model_Category(search);
    searchContext.m_add__org_dominokit_domino_ui_datatable_model_Filter(Filter.m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category("*", this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_getValue__(), Category.f_SEARCH__org_dominokit_domino_ui_datatable_model_Category)).m_fireSearchEvent__();
  }
  
  /**
   * @override
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
    if (j_l_String.m_equals__java_lang_String__java_lang_Object(SearchClearedEvent.f_SEARCH_EVENT_CLEARED__org_dominokit_domino_ui_datatable_events_SearchClearedEvent, event.m_getType__())) {
      this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_pauseChangeHandlers__();
      this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_clear__();
      this.f_textBox__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_.m_resumeChangeHandlers__();
    }
  }
  
  /**
   * @override
   * @param {DataTable<C_SearchTableAction_T>} dataTable
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    this.f_dataTable__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = dataTable;
    dataTable.m_addTableEventListner__java_lang_String__org_dominokit_domino_ui_datatable_events_TableEventListener(SearchClearedEvent.f_SEARCH_EVENT_CLEARED__org_dominokit_domino_ui_datatable_events_SearchClearedEvent, this);
    return this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction() {
    this.f_autoSearchDelay__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = 200;
    this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["search-new"], j_l_String))), HtmlContentBuilder)).m_asElement__(), $Overlay));
    this.f_autoSearch__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_SearchTableAction_ = true;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SearchTableAction.$clinit = (() =>{
    });
    SearchTableAction.$loadModules();
    j_l_Object.$clinit();
    HeaderActionElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SearchTableAction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SearchTableAction);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    SearchClearedEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');
    Category = goog.module.get('org.dominokit.domino.ui.datatable.model.Category$impl');
    Filter = goog.module.get('org.dominokit.domino.ui.datatable.model.Filter$impl');
    $1 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$1$impl');
    $LambdaAdaptor$26 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$26$impl');
    $LambdaAdaptor$27 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$27$impl');
    $LambdaAdaptor$28 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$28$impl');
    $LambdaAdaptor$29 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.SearchTableAction.$LambdaAdaptor$29$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    Icon = goog.module.get('org.dominokit.domino.ui.icons.Icon$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(SearchTableAction, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$SearchTableAction'));


HeaderActionElement.$markImplementor(SearchTableAction);


exports = SearchTableAction; 
//# sourceMappingURL=HeaderBarPlugin$SearchTableAction.js.map