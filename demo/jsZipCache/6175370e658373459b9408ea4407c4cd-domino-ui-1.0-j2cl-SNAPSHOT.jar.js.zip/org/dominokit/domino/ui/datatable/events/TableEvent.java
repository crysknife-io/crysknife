package org.dominokit.domino.ui.datatable.events;

public interface TableEvent {
    String getType();
}
