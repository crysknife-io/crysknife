/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.TextHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.TextHeaderFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DelayedHeaderFilterInput = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let TextBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.TextBox$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {DelayedHeaderFilterInput<TextBox, C_T>}
  */
class TextHeaderFilter extends DelayedHeaderFilterInput {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TextBox} */
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_;
  }
  
  /**
   * @template C_T
   * @return {!TextHeaderFilter<C_T>}
   * @public
   */
  static $create__() {
    TextHeaderFilter.$clinit();
    let $instance = new TextHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput__();
  }
  
  /**
   * @template M_T
   * @return {TextHeaderFilter<M_T>}
   * @public
   */
  static m_create__() {
    TextHeaderFilter.$clinit();
    return /**@type {!TextHeaderFilter<*>} */ (TextHeaderFilter.$create__());
  }
  
  /**
   * @override
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
    return /**@type {HTMLInputElement} */ ($Casts.$to(this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {TextBox}
   * @public
   */
  m_createValueBox__() {
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_ = TextBox.m_create__();
    return this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_.m_isEmpty__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_.m_getValue__();
  }
  
  /**
   * @return {TextBox}
   * @public
   */
  m_getTextBox__() {
    return this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_;
  }
  
  /**
   * @override
   * @return {FilterTypes}
   * @public
   */
  m_getType__() {
    return FilterTypes.f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_.m_pauseChangeHandlers__();
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_.m_clear__();
    this.f_textBox__org_dominokit_domino_ui_datatable_plugins_filter_header_TextHeaderFilter_.m_resumeChangeHandlers__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TextHeaderFilter.$clinit = (() =>{
    });
    TextHeaderFilter.$loadModules();
    DelayedHeaderFilterInput.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TextHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TextHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    TextBox = goog.module.get('org.dominokit.domino.ui.forms.TextBox$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(TextHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.TextHeaderFilter'));




exports = TextHeaderFilter; 
//# sourceMappingURL=TextHeaderFilter.js.map