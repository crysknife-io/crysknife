/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.TableEventListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEventListener.$LambdaAdaptor$impl');


/**
 * @interface
 */
class TableEventListener {
  /**
   * @abstract
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
  }
  
  /**
   * @param {?function(TableEvent):void} fn
   * @return {TableEventListener}
   * @public
   */
  static $adapt(fn) {
    TableEventListener.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TableEventListener.$clinit = (() =>{
    });
    TableEventListener.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_events_TableEventListener = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_events_TableEventListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_events_TableEventListener;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.events.TableEventListener.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(TableEventListener, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.TableEventListener'));


TableEventListener.$markImplementor(/** @type {Function} */ (TableEventListener));


exports = TableEventListener; 
//# sourceMappingURL=TableEventListener.js.map