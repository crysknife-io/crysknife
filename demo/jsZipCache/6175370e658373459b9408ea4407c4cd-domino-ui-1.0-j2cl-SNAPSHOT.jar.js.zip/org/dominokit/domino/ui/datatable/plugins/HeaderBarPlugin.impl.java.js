/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let HeaderActionElement = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');
let Column = goog.forwardDeclare('org.dominokit.domino.ui.grid.Column$impl');
let Row = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row$impl');
let Row__12 = goog.forwardDeclare('org.dominokit.domino.ui.grid.Row_12$impl');
let FlexItem = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
let FlexJustifyContent = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexJustifyContent$impl');
let FlexLayout = goog.forwardDeclare('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class HeaderBarPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Column} */
    this.f_titleColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_;
    /** @public {Column} */
    this.f_actionsBarColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_;
    /** @public {HTMLHeadingElement} */
    this.f_title__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_;
    /** @public {FlexLayout} */
    this.f_actionsBar__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_;
    /** @public {HTMLDivElement} */
    this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_;
    /** @public {List<HeaderActionElement<C_T>>} */
    this.f_actionElements__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_;
  }
  
  /**
   * Factory method corresponding to constructor 'HeaderBarPlugin(String)'.
   * @template C_T
   * @param {?string} title
   * @return {!HeaderBarPlugin<C_T>}
   * @public
   */
  static $create__java_lang_String(title) {
    HeaderBarPlugin.$clinit();
    let $instance = new HeaderBarPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin__java_lang_String(title);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HeaderBarPlugin(String)'.
   * @param {?string} title
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin__java_lang_String(title) {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin__java_lang_String__java_lang_String(title, "");
  }
  
  /**
   * Factory method corresponding to constructor 'HeaderBarPlugin(String, String)'.
   * @template C_T
   * @param {?string} title
   * @param {?string} description
   * @return {!HeaderBarPlugin<C_T>}
   * @public
   */
  static $create__java_lang_String__java_lang_String(title, description) {
    HeaderBarPlugin.$clinit();
    let $instance = new HeaderBarPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin__java_lang_String__java_lang_String(title, description);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HeaderBarPlugin(String, String)'.
   * @param {?string} title
   * @param {?string} description
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin__java_lang_String__java_lang_String(title, description) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin();
    this.f_title__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.appendChild($Overlay.m_createTextNode__elemental2_dom_Document__java_lang_String(DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay, title));
    if (Objects.m_nonNull__java_lang_Object(description) && !j_l_String.m_isEmpty__java_lang_String(description)) {
      this.f_title__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.appendChild(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_small__().m_textContent__java_lang_String(description), HtmlContentBuilder)).m_asElement__());
    }
    /**@type {Style<HTMLDivElement, Column>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_titleColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_)).m_setMarginBottom__java_lang_String("0px");
    /**@type {Style<HTMLDivElement, Column>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_actionsBarColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_)).m_setMarginBottom__java_lang_String("0px");
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    this.f_actionElements__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** HeaderActionElement<*> */ actionElement) =>{
      this.f_actionsBar__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.m_appendChild__elemental2_dom_Node(/**@type {FlexItem} */ ($Casts.$to(/**@type {FlexItem} */ ($Casts.$to(FlexItem.m_create__().m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLDivElement, FlexItem> */ style) =>{
        style.m_add__java_lang_String(Styles.f_m_r_5__org_dominokit_domino_ui_style_Styles).m_add__java_lang_String(Styles.f_m_l_5__org_dominokit_domino_ui_style_Styles);
      }))), FlexItem)).m_appendChild__elemental2_dom_Node(actionElement.m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable)), FlexItem)).m_asElement__());
    })));
    dataTable.m_asElement__().appendChild(this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_);
  }
  
  /**
   * @param {HeaderActionElement<C_T>} headerActionElement
   * @return {HeaderBarPlugin<C_T>}
   * @public
   */
  m_addActionElement__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement(headerActionElement) {
    this.f_actionElements__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.add(headerActionElement);
    return this;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin() {
    this.f_titleColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ = Column.m_span6__();
    this.f_actionsBarColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ = Column.m_span6__();
    this.f_title__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ = /**@type {HTMLHeadingElement} */ ($Casts.$to(/**@type {Style<HTMLHeadingElement, HtmlContentBuilder<HTMLHeadingElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_h__int(2))).m_setMarginBottom__java_lang_String("0px").m_asElement__(), HTMLHeadingElement_$Overlay));
    this.f_actionsBar__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ = FlexLayout.m_create__().m_setJustifyContent__org_dominokit_domino_ui_grid_flex_FlexJustifyContent(FlexJustifyContent.f_END__org_dominokit_domino_ui_grid_flex_FlexJustifyContent);
    this.f_element__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(/**@type {Row__12} */ ($Casts.$to(/**@type {Row__12} */ ($Casts.$to(Row.m_create__().m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_titleColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.m_appendChild__elemental2_dom_Node(this.f_title__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_), Column))), Row__12)).m_appendChild__org_dominokit_domino_ui_grid_Column(/**@type {Column} */ ($Casts.$to(this.f_actionsBarColumn__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_actionsBar__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_), Column))), Row__12)).m_asElement__()), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["header"], j_l_String))), HtmlContentBuilder)).m_style__java_lang_String("padding-bottom: 5px;"), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_actionElements__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ = /**@type {!ArrayList<HeaderActionElement<C_T>>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HeaderBarPlugin.$clinit = (() =>{
    });
    HeaderBarPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HeaderBarPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HeaderBarPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.Document.$Overlay$impl');
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    Column = goog.module.get('org.dominokit.domino.ui.grid.Column$impl');
    Row = goog.module.get('org.dominokit.domino.ui.grid.Row$impl');
    Row__12 = goog.module.get('org.dominokit.domino.ui.grid.Row_12$impl');
    FlexItem = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexItem$impl');
    FlexJustifyContent = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexJustifyContent$impl');
    FlexLayout = goog.module.get('org.dominokit.domino.ui.grid.flex.FlexLayout$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(HeaderBarPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin'));


DataTablePlugin.$markImplementor(HeaderBarPlugin);


exports = HeaderBarPlugin; 
//# sourceMappingURL=HeaderBarPlugin.js.map