/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor$20 = goog.require('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.$LambdaAdaptor$20');
const _DoublClickHandler = goog.require('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin.DoublClickHandler');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');


// Re-exports the implementation.
var DoubleClickPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DoubleClickPlugin$impl');
exports = DoubleClickPlugin;
 