/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.SelectionPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let HTMLTableRowElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableRowElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Boolean = goog.forwardDeclare('java.lang.Boolean$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let CellRenderer = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let SelectionChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');
let HeaderElement = goog.forwardDeclare('org.dominokit.domino.ui.datatable.HeaderElement$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$31 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin.$LambdaAdaptor$31$impl');
let CheckBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.CheckBox$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let ChangeHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
let Selectable = goog.forwardDeclare('org.dominokit.domino.ui.utils.Selectable$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.Selectable.SelectionHandler$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class SelectionPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {ColorScheme} */
    this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_;
    /** @public {Selectable<C_T>} */
    this.f_selectedRow__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_;
    /** @public {HTMLElement} */
    this.f_singleSelectIndicator__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_;
  }
  
  /**
   * Factory method corresponding to constructor 'SelectionPlugin()'.
   * @template C_T
   * @return {!SelectionPlugin<C_T>}
   * @public
   */
  static $create__() {
    SelectionPlugin.$clinit();
    let $instance = new SelectionPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectionPlugin()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin();
  }
  
  /**
   * Factory method corresponding to constructor 'SelectionPlugin(ColorScheme)'.
   * @template C_T
   * @param {ColorScheme} colorScheme
   * @return {!SelectionPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_style_ColorScheme(colorScheme) {
    SelectionPlugin.$clinit();
    let $instance = new SelectionPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme(colorScheme);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectionPlugin(ColorScheme)'.
   * @param {ColorScheme} colorScheme
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme(colorScheme) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin();
    this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_ = colorScheme;
  }
  
  /**
   * Factory method corresponding to constructor 'SelectionPlugin(ColorScheme, HTMLElement)'.
   * @template C_T
   * @param {ColorScheme} colorScheme
   * @param {HTMLElement} singleSelectIndicator
   * @return {!SelectionPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_HTMLElement(colorScheme, singleSelectIndicator) {
    SelectionPlugin.$clinit();
    let $instance = new SelectionPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_HTMLElement(colorScheme, singleSelectIndicator);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectionPlugin(ColorScheme, HTMLElement)'.
   * @param {ColorScheme} colorScheme
   * @param {HTMLElement} singleSelectIndicator
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_HTMLElement(colorScheme, singleSelectIndicator) {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme(colorScheme);
    this.f_singleSelectIndicator__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_ = singleSelectIndicator;
  }
  
  /**
   * Factory method corresponding to constructor 'SelectionPlugin(ColorScheme, IsElement)'.
   * @template C_T
   * @param {ColorScheme} colorScheme
   * @param {IsElement} singleSelectIndicator
   * @return {!SelectionPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_style_ColorScheme__org_jboss_gwt_elemento_core_IsElement(colorScheme, singleSelectIndicator) {
    SelectionPlugin.$clinit();
    let $instance = new SelectionPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme__org_jboss_gwt_elemento_core_IsElement(colorScheme, singleSelectIndicator);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'SelectionPlugin(ColorScheme, IsElement)'.
   * @param {ColorScheme} colorScheme
   * @param {IsElement} singleSelectIndicator
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme__org_jboss_gwt_elemento_core_IsElement(colorScheme, singleSelectIndicator) {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin__org_dominokit_domino_ui_style_ColorScheme__elemental2_dom_HTMLElement(colorScheme, singleSelectIndicator.m_asElement__());
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    dataTable.m_getTableConfig__().m_insertColumnFirst__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<C_T>} */ (ColumnConfig.m_create__java_lang_String("data-table-select-cm")).m_setSortable__boolean(false).m_setWidth__java_lang_String(dataTable.m_getTableConfig__().m_isMultiSelect__() ? "40px" : "45px").m_setFixed__boolean(true).m_setTooltipNode__elemental2_dom_Node($Overlay.m_createTextNode__elemental2_dom_Document__java_lang_String(DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay, "Select")).m_setHeaderElement__org_dominokit_domino_ui_datatable_HeaderElement(HeaderElement.$adapt(((/** ?string */ columnTitle) =>{
      if (dataTable.m_getTableConfig__().m_isMultiSelect__()) {
        return this.m_createMultiSelectHeader__org_dominokit_domino_ui_datatable_DataTable_$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin(dataTable);
      } else {
        return this.m_createSingleSelectHeader___$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin();
      }
    }))).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(/**@type {CellRenderer<C_T>} */ (CellRenderer.$adapt(((/** CellInfo<*> */ cell) =>{
      if (dataTable.m_getTableConfig__().m_isMultiSelect__()) {
        return this.m_createMultiSelectCell__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin(dataTable, cell);
      } else {
        return this.m_createSingleSelectCell__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin(dataTable, cell);
      }
    })))).m_asHeader__());
  }
  
  /**
   * @return {Node}
   * @public
   */
  m_createSingleSelectHeader___$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin() {
    return this.f_singleSelectIndicator__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.cloneNode(true);
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @param {CellInfo<C_T>} cell
   * @return {Node}
   * @public
   */
  m_createSingleSelectCell__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin(dataTable, cell) {
    let clonedIndicator = /**@type {HTMLElement} */ (Js.m_uncheckedCast__java_lang_Object(this.f_singleSelectIndicator__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.cloneNode(true)));
    cell.m_getTableRow__().m_asElement__().addEventListener("click", new $LambdaAdaptor$31(((/** Event */ evt) =>{
      cell.m_getTableRow__().m_select__();
      dataTable.m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(cell.m_getTableRow__());
    })));
    cell.m_getTableRow__().m_addSelectionHandler__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(/**@type {SelectionHandler<C_T>} */ (SelectionHandler.$adapt(((/** Selectable<*> */ selectable) =>{
      if (selectable.m_isSelected__()) {
        if (Objects.m_nonNull__java_lang_Object(this.f_selectedRow__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          this.f_selectedRow__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_deselect__();
        }
        /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(clonedIndicator)).m_setDisplay__java_lang_String("inline-block");
        if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          /**@type {Style<HTMLTableRowElement, IsElement<HTMLTableRowElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(/**@type {TableRow<*>} */ ($Casts.$to(selectable, TableRow)).m_asElement__())).m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_lighten_5__().m_getBackground__());
        }
        this.f_selectedRow__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_ = selectable;
      } else {
        /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(clonedIndicator)).m_setDisplay__java_lang_String("none");
        if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          /**@type {Style<HTMLTableRowElement, IsElement<HTMLTableRowElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(/**@type {TableRow<*>} */ ($Casts.$to(selectable, TableRow)).m_asElement__())).m_remove__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_lighten_5__().m_getBackground__());
        }
      }
    }))));
    /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(clonedIndicator)).m_setDisplay__java_lang_String("none");
    return clonedIndicator;
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @param {CellInfo<C_T>} cell
   * @return {Node}
   * @public
   */
  m_createMultiSelectCell__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin(dataTable, cell) {
    let checkBox = this.m_createCheckBox___$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin();
    cell.m_getTableRow__().m_addSelectionHandler__org_dominokit_domino_ui_utils_Selectable_SelectionHandler(/**@type {SelectionHandler<C_T>} */ (SelectionHandler.$adapt(((/** Selectable<*> */ selectable) =>{
      if (selectable.m_isSelected__()) {
        checkBox.m_check__boolean(true);
        if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          /**@type {Style<HTMLTableRowElement, IsElement<HTMLTableRowElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(/**@type {TableRow<*>} */ ($Casts.$to(selectable, TableRow)).m_asElement__())).m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_lighten_5__().m_getBackground__());
        }
      } else {
        checkBox.m_uncheck__boolean(true);
        if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          /**@type {Style<HTMLTableRowElement, IsElement<HTMLTableRowElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(/**@type {TableRow<*>} */ ($Casts.$to(selectable, TableRow)).m_asElement__())).m_remove__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_lighten_5__().m_getBackground__());
        }
      }
    }))));
    checkBox.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ checked) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(checked)) {
        cell.m_getTableRow__().m_select__();
        if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          /**@type {Style<HTMLTableRowElement, IsElement<HTMLTableRowElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(cell.m_getTableRow__().m_asElement__())).m_add__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_lighten_5__().m_getBackground__());
        }
        dataTable.m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(cell.m_getTableRow__());
      } else {
        cell.m_getTableRow__().m_deselect__();
        if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
          /**@type {Style<HTMLTableRowElement, IsElement<HTMLTableRowElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(cell.m_getTableRow__().m_asElement__())).m_remove__java_lang_String(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_lighten_5__().m_getBackground__());
        }
        dataTable.m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(cell.m_getTableRow__());
      }
    })));
    return checkBox.m_asElement__();
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @return {Node}
   * @public
   */
  m_createMultiSelectHeader__org_dominokit_domino_ui_datatable_DataTable_$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin(dataTable) {
    let checkBox = this.m_createCheckBox___$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin();
    checkBox.m_addChangeHandler__org_dominokit_domino_ui_utils_HasChangeHandlers_ChangeHandler(ChangeHandler.$adapt(((/** ?boolean */ checked) =>{
      if (Boolean.m_booleanValue__java_lang_Boolean(checked)) {
        dataTable.m_selectAll__();
      } else {
        dataTable.m_deselectAll__();
      }
    })));
    dataTable.m_addSelectionListener__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener(/**@type {SelectionChangeListener<C_T>} */ (SelectionChangeListener.$adapt(((/** List<TableRow<*>> */ selectedRows, /** List<*> */ selectedRecords) =>{
      if (selectedRows.size() != dataTable.m_getItems__().size()) {
        checkBox.m_uncheck__boolean(true);
      } else {
        checkBox.m_check__boolean(true);
      }
    }))));
    return checkBox.m_asElement__();
  }
  
  /**
   * @param {BaseIcon<?>} singleSelectIcon
   * @return {SelectionPlugin<C_T>}
   * @public
   */
  m_setSingleSelectIcon__org_dominokit_domino_ui_icons_BaseIcon(singleSelectIcon) {
    return this;
  }
  
  /**
   * @return {CheckBox}
   * @public
   */
  m_createCheckBox___$p_org_dominokit_domino_ui_datatable_plugins_SelectionPlugin() {
    let checkBox = CheckBox.m_create__();
    if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_)) {
      checkBox.m_setColor__org_dominokit_domino_ui_style_Color(this.f_colorScheme__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_.m_color__());
    }
    /**@type {Style<HTMLElement, CheckBox>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(checkBox)).m_add__java_lang_String("select-checkbox");
    return checkBox;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin() {
    this.f_singleSelectIndicator__org_dominokit_domino_ui_datatable_plugins_SelectionPlugin_ = Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_check__().m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SelectionPlugin.$clinit = (() =>{
    });
    SelectionPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SelectionPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SelectionPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.Document.$Overlay$impl');
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Boolean = goog.module.get('java.lang.Boolean$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    CellRenderer = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer$impl');
    ColumnConfig = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
    SelectionChangeListener = goog.module.get('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');
    HeaderElement = goog.module.get('org.dominokit.domino.ui.datatable.HeaderElement$impl');
    TableRow = goog.module.get('org.dominokit.domino.ui.datatable.TableRow$impl');
    $LambdaAdaptor$31 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin.$LambdaAdaptor$31$impl');
    CheckBox = goog.module.get('org.dominokit.domino.ui.forms.CheckBox$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    ChangeHandler = goog.module.get('org.dominokit.domino.ui.utils.HasChangeHandlers.ChangeHandler$impl');
    SelectionHandler = goog.module.get('org.dominokit.domino.ui.utils.Selectable.SelectionHandler$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(SelectionPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.SelectionPlugin'));


DataTablePlugin.$markImplementor(SelectionPlugin);


exports = SelectionPlugin; 
//# sourceMappingURL=SelectionPlugin.js.map