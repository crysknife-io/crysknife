/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');


/**
 * @template C_T
 * @implements {HeaderActionElement<C_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(DataTable<C_T>):Node} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(DataTable<C_T>):Node} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$LambdaAdaptor__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$JsFunction(fn);
  }
  
  /**
   * @param {?function(DataTable<C_T>):Node} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$LambdaAdaptor__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {DataTable<C_T>} arg0
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    let /** ?function(DataTable<C_T>):Node */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    HeaderActionElement.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
    HeaderActionElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$$LambdaAdaptor'));


HeaderActionElement.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=HeaderActionElement$$LambdaAdaptor.js.map