/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.CellRenderer$CellInfo.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @template C_CellInfo_T
  */
class CellInfo extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {TableRow<C_CellInfo_T>} */
    this.f_tableRow__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_;
    /** @public {HTMLTableCellElement} */
    this.f_element__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_;
  }
  
  /**
   * @template C_CellInfo_T
   * @param {TableRow<C_CellInfo_T>} tableRow
   * @param {HTMLTableCellElement} element
   * @return {!CellInfo<C_CellInfo_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_TableRow__elemental2_dom_HTMLTableCellElement(tableRow, element) {
    CellInfo.$clinit();
    let $instance = new CellInfo();
    $instance.$ctor__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo__org_dominokit_domino_ui_datatable_TableRow__elemental2_dom_HTMLTableCellElement(tableRow, element);
    return $instance;
  }
  
  /**
   * @param {TableRow<C_CellInfo_T>} tableRow
   * @param {HTMLTableCellElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo__org_dominokit_domino_ui_datatable_TableRow__elemental2_dom_HTMLTableCellElement(tableRow, element) {
    this.$ctor__java_lang_Object__();
    this.f_tableRow__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_ = tableRow;
    this.f_element__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_ = element;
  }
  
  /**
   * @return {TableRow<C_CellInfo_T>}
   * @public
   */
  m_getTableRow__() {
    return this.f_tableRow__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_;
  }
  
  /**
   * @return {HTMLTableCellElement}
   * @public
   */
  m_getElement__() {
    return this.f_element__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_;
  }
  
  /**
   * @return {C_CellInfo_T}
   * @public
   */
  m_getRecord__() {
    return this.f_tableRow__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo_.m_getRecord__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CellInfo.$clinit = (() =>{
    });
    CellInfo.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CellInfo;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CellInfo);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(CellInfo, $Util.$makeClassName('org.dominokit.domino.ui.datatable.CellRenderer$CellInfo'));




exports = CellInfo; 
//# sourceMappingURL=CellRenderer$CellInfo.js.map