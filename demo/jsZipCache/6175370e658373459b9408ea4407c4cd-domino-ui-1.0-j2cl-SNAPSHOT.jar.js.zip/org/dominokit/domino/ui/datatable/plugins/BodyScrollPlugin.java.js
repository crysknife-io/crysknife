/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLTableSectionElement.$Overlay');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _BodyScrollEvent = goog.require('org.dominokit.domino.ui.datatable.events.BodyScrollEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _$LambdaAdaptor$19 = goog.require('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.$LambdaAdaptor$19');
const _ScrollPosition = goog.require('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin.ScrollPosition');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BodyScrollPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.BodyScrollPlugin$impl');
exports = BodyScrollPlugin;
 