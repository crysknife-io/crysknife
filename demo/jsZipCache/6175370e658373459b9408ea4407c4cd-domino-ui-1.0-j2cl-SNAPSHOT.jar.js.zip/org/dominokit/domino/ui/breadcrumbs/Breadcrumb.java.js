/**
 * @fileoverview transpiled from org.dominokit.domino.ui.breadcrumbs.Breadcrumb.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.breadcrumbs.Breadcrumb');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _EventListener_$Overlay = goog.require('elemental2.dom.EventListener.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLOListElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _$LambdaAdaptor$3 = goog.require('org.dominokit.domino.ui.breadcrumbs.Breadcrumb.$LambdaAdaptor$3');
const _BreadcrumbItem = goog.require('org.dominokit.domino.ui.breadcrumbs.BreadcrumbItem');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Breadcrumb = goog.require('org.dominokit.domino.ui.breadcrumbs.Breadcrumb$impl');
exports = Breadcrumb;
 