/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.CircleSize.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.CircleSize$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<CircleSize>}
  */
class CircleSize extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_button_CircleSize_;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!CircleSize}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new CircleSize();
    $instance.$ctor__org_dominokit_domino_ui_button_CircleSize__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_CircleSize__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_button_CircleSize_ = style;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_button_CircleSize_;
  }
  
  /**
   * @param {string} name
   * @return {!CircleSize}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    CircleSize.$clinit();
    if ($Equality.$same(CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_, null)) {
      CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_ = $Enums.createMapFromValues(CircleSize.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_);
  }
  
  /**
   * @return {!Array<!CircleSize>}
   * @public
   */
  static m_values__() {
    CircleSize.$clinit();
    return /**@type {!Array<CircleSize>} */ ($Arrays.$init([CircleSize.$f_SMALL__org_dominokit_domino_ui_button_CircleSize, CircleSize.$f_LARGE__org_dominokit_domino_ui_button_CircleSize], CircleSize));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {CircleSize} */ ($Casts.$to(arg0, CircleSize)));
  }
  
  /**
   * @return {!CircleSize}
   * @public
   */
  static get f_SMALL__org_dominokit_domino_ui_button_CircleSize() {
    return (CircleSize.$clinit(), CircleSize.$f_SMALL__org_dominokit_domino_ui_button_CircleSize);
  }
  
  /**
   * @param {!CircleSize} value
   * @return {void}
   * @public
   */
  static set f_SMALL__org_dominokit_domino_ui_button_CircleSize(value) {
    (CircleSize.$clinit(), CircleSize.$f_SMALL__org_dominokit_domino_ui_button_CircleSize = value);
  }
  
  /**
   * @return {!CircleSize}
   * @public
   */
  static get f_LARGE__org_dominokit_domino_ui_button_CircleSize() {
    return (CircleSize.$clinit(), CircleSize.$f_LARGE__org_dominokit_domino_ui_button_CircleSize);
  }
  
  /**
   * @param {!CircleSize} value
   * @return {void}
   * @public
   */
  static set f_LARGE__org_dominokit_domino_ui_button_CircleSize(value) {
    (CircleSize.$clinit(), CircleSize.$f_LARGE__org_dominokit_domino_ui_button_CircleSize = value);
  }
  
  /**
   * @return {Map<?string, !CircleSize>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_() {
    return (CircleSize.$clinit(), CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_);
  }
  
  /**
   * @param {Map<?string, !CircleSize>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_(value) {
    (CircleSize.$clinit(), CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CircleSize.$clinit = (() =>{
    });
    CircleSize.$loadModules();
    Enum.$clinit();
    CircleSize.$f_SMALL__org_dominokit_domino_ui_button_CircleSize = CircleSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("SMALL"), CircleSize.$ordinal$f_SMALL__org_dominokit_domino_ui_button_CircleSize, "btn-circle");
    CircleSize.$f_LARGE__org_dominokit_domino_ui_button_CircleSize = CircleSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("LARGE"), CircleSize.$ordinal$f_LARGE__org_dominokit_domino_ui_button_CircleSize, "btn-circle-lg");
    CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CircleSize;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, CircleSize);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(CircleSize, $Util.$makeClassName('org.dominokit.domino.ui.button.CircleSize'));


/** @private {!CircleSize} */
CircleSize.$f_SMALL__org_dominokit_domino_ui_button_CircleSize;


/** @private {!CircleSize} */
CircleSize.$f_LARGE__org_dominokit_domino_ui_button_CircleSize;


/** @private {Map<?string, !CircleSize>} */
CircleSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_CircleSize_;


/** @public {number} @const */
CircleSize.$ordinal$f_SMALL__org_dominokit_domino_ui_button_CircleSize = 0;


/** @public {number} @const */
CircleSize.$ordinal$f_LARGE__org_dominokit_domino_ui_button_CircleSize = 1;




exports = CircleSize; 
//# sourceMappingURL=CircleSize.js.map