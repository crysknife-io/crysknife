/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.SplitButton.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.SplitButton');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');
const _ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SplitButton = goog.require('org.dominokit.domino.ui.button.SplitButton$impl');
exports = SplitButton;
 