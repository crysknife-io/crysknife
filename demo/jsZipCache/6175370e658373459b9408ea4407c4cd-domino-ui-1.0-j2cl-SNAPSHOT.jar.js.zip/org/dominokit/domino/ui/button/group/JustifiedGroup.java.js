/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.JustifiedGroup.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.group.JustifiedGroup');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _IsGroup = goog.require('org.dominokit.domino.ui.button.group.IsGroup');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');
const _ButtonsGroup = goog.require('org.dominokit.domino.ui.button.group.ButtonsGroup');


// Re-exports the implementation.
var JustifiedGroup = goog.require('org.dominokit.domino.ui.button.group.JustifiedGroup$impl');
exports = JustifiedGroup;
 