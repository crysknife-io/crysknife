/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Collapsible$CollapseCompletedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class CollapseCompletedHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onCollapsed__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {CollapseCompletedHandler}
   * @public
   */
  static $adapt(fn) {
    CollapseCompletedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CollapseCompletedHandler.$clinit = (() =>{
    });
    CollapseCompletedHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_collapsible_Collapsible_CollapseCompletedHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(CollapseCompletedHandler, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Collapsible$CollapseCompletedHandler'));


CollapseCompletedHandler.$markImplementor(/** @type {Function} */ (CollapseCompletedHandler));


exports = CollapseCompletedHandler; 
//# sourceMappingURL=Collapsible$CollapseCompletedHandler.js.map