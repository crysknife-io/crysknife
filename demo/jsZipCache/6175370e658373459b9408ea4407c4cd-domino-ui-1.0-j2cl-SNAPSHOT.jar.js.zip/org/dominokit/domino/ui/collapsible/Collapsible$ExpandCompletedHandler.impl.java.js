/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Collapsible$ExpandCompletedHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ExpandCompletedHandler {
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_onExpanded__() {
  }
  
  /**
   * @param {?function():void} fn
   * @return {ExpandCompletedHandler}
   * @public
   */
  static $adapt(fn) {
    ExpandCompletedHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ExpandCompletedHandler.$clinit = (() =>{
    });
    ExpandCompletedHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_collapsible_Collapsible_ExpandCompletedHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ExpandCompletedHandler, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Collapsible$ExpandCompletedHandler'));


ExpandCompletedHandler.$markImplementor(/** @type {Function} */ (ExpandCompletedHandler));


exports = ExpandCompletedHandler; 
//# sourceMappingURL=Collapsible$ExpandCompletedHandler.js.map