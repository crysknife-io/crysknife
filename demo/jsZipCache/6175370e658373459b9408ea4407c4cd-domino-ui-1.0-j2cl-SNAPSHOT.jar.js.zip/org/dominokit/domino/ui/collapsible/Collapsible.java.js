/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Collapsible.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.collapsible.Collapsible');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _CollapseCompletedHandler = goog.require('org.dominokit.domino.ui.collapsible.Collapsible.CollapseCompletedHandler');
const _ExpandCompletedHandler = goog.require('org.dominokit.domino.ui.collapsible.Collapsible.ExpandCompletedHandler');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');


// Re-exports the implementation.
var Collapsible = goog.require('org.dominokit.domino.ui.collapsible.Collapsible$impl');
exports = Collapsible;
 