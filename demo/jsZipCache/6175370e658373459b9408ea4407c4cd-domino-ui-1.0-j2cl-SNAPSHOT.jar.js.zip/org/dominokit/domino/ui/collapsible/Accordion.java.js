/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Accordion.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.collapsible.Accordion');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _LinkedList = goog.require('java.util.LinkedList');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _$LambdaAdaptor$18 = goog.require('org.dominokit.domino.ui.collapsible.Accordion.$LambdaAdaptor$18');
const _AccordionPanel = goog.require('org.dominokit.domino.ui.collapsible.AccordionPanel');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Accordion = goog.require('org.dominokit.domino.ui.collapsible.Accordion$impl');
exports = Accordion;
 