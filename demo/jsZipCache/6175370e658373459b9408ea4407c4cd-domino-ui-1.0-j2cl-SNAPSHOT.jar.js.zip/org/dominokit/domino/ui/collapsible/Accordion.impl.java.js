/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.Accordion.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.collapsible.Accordion$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let LinkedList = goog.forwardDeclare('java.util.LinkedList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let $LambdaAdaptor$18 = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.Accordion.$LambdaAdaptor$18$impl');
let AccordionPanel = goog.forwardDeclare('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, Accordion>}
  */
class Accordion extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_;
    /** @public {List<AccordionPanel>} */
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_;
    /** @public {boolean} */
    this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_ = false;
  }
  
  /**
   * @return {!Accordion}
   * @public
   */
  static $create__() {
    Accordion.$clinit();
    let $instance = new Accordion();
    $instance.$ctor__org_dominokit_domino_ui_collapsible_Accordion__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_collapsible_Accordion__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_collapsible_Accordion();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  static m_create__() {
    Accordion.$clinit();
    return Accordion.$create__();
  }
  
  /**
   * @param {AccordionPanel} panel
   * @return {Accordion}
   * @public
   * @deprecated
   */
  m_addPanel__org_dominokit_domino_ui_collapsible_AccordionPanel(panel) {
    return this.m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(panel);
  }
  
  /**
   * @param {AccordionPanel} panel
   * @return {Accordion}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_collapsible_AccordionPanel(panel) {
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_.add(panel);
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(panel);
    /**@type {DominoElement<HTMLAnchorElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(panel.m_getClickableElement__())).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$18(((/** Event */ evt) =>{
      if (!this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_) {
        let accordionPanels = this.m_otherPanels__org_dominokit_domino_ui_collapsible_AccordionPanel_$p_org_dominokit_domino_ui_collapsible_Accordion(panel);
        accordionPanels.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** AccordionPanel */ accordionPanel) =>{
          if (!accordionPanel.m_isCollapsed__()) {
            accordionPanel.m_collapse__();
          }
        })));
        if (panel.m_isCollapsed__()) {
          panel.m_expand__();
        }
      } else {
        panel.m_toggleDisplay__();
      }
    })));
    return this;
  }
  
  /**
   * @param {AccordionPanel} exclude
   * @return {List<AccordionPanel>}
   * @public
   */
  m_otherPanels__org_dominokit_domino_ui_collapsible_AccordionPanel_$p_org_dominokit_domino_ui_collapsible_Accordion(exclude) {
    let newList = /**@type {!ArrayList<AccordionPanel>} */ (ArrayList.$create__java_util_Collection(this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_));
    newList.remove(exclude);
    return newList;
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_multiOpen__() {
    this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_ = true;
    return this;
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_primary__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-primary");
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_success__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-success");
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_warning__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-warning");
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_danger__() {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion("panel-danger");
  }
  
  /**
   * @param {Color} color
   * @return {Accordion}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    return this.m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion(color.m_getStyle__());
  }
  
  /**
   * @param {?string} style
   * @return {Accordion}
   * @public
   */
  m_applyStyle__java_lang_String_$p_org_dominokit_domino_ui_collapsible_Accordion(style) {
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** AccordionPanel */ p) =>{
      p.m_applyStyle__java_lang_String_$pp_org_dominokit_domino_ui_collapsible(style);
    })));
    return this;
  }
  
  /**
   * @return {Accordion}
   * @public
   */
  m_fullBody__() {
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_.m_style__().m_add__java_lang_String("full-body");
    return this;
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_collapsible_Accordion_.m_asElement__(), $Overlay));
  }
  
  /**
   * @return {List<AccordionPanel>}
   * @public
   */
  m_getPanels__() {
    return this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_collapsible_Accordion() {
    this.f_element__org_dominokit_domino_ui_collapsible_Accordion_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["panel-group"], j_l_String)))));
    this.f_panels__org_dominokit_domino_ui_collapsible_Accordion_ = /**@type {!LinkedList<AccordionPanel>} */ (LinkedList.$create__());
    this.f_multiOpen__org_dominokit_domino_ui_collapsible_Accordion_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Accordion.$clinit = (() =>{
    });
    Accordion.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Accordion;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Accordion);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    LinkedList = goog.module.get('java.util.LinkedList$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    $LambdaAdaptor$18 = goog.module.get('org.dominokit.domino.ui.collapsible.Accordion.$LambdaAdaptor$18$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Accordion, $Util.$makeClassName('org.dominokit.domino.ui.collapsible.Accordion'));




exports = Accordion; 
//# sourceMappingURL=Accordion.js.map