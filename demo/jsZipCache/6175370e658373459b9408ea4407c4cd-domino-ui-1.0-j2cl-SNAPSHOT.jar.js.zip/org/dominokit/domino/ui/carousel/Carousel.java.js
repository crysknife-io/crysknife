/**
 * @fileoverview transpiled from org.dominokit.domino.ui.carousel.Carousel.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.carousel.Carousel');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _$Overlay = goog.require('elemental2.dom.DomGlobal.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _HTMLOListElement_$Overlay = goog.require('elemental2.dom.HTMLOListElement.$Overlay');
const _MutationRecord_$Overlay = goog.require('elemental2.dom.MutationRecord.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _$1 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$1');
const _$LambdaAdaptor$10 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$10');
const _$LambdaAdaptor$11 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$11');
const _$LambdaAdaptor$12 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$12');
const _$LambdaAdaptor$13 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$13');
const _$LambdaAdaptor$14 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$14');
const _$LambdaAdaptor$15 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$15');
const _$LambdaAdaptor$6 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$6');
const _$LambdaAdaptor$7 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$7');
const _$LambdaAdaptor$8 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$8');
const _$LambdaAdaptor$9 = goog.require('org.dominokit.domino.ui.carousel.Carousel.$LambdaAdaptor$9');
const _Slide = goog.require('org.dominokit.domino.ui.carousel.Slide');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _SwipeUtil = goog.require('org.dominokit.domino.ui.utils.SwipeUtil');
const _SwipeDirection = goog.require('org.dominokit.domino.ui.utils.SwipeUtil.SwipeDirection');
const _Timer = goog.require('org.gwtproject.timer.client.Timer');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _ObserverCallback = goog.require('org.jboss.gwt.elemento.core.ObserverCallback');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Carousel = goog.require('org.dominokit.domino.ui.carousel.Carousel$impl');
exports = Carousel;
 