/**
 * @fileoverview transpiled from org.dominokit.domino.ui.carousel.Slide.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.carousel.Slide');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLImageElement.$Overlay');
const _HTMLLIElement_$Overlay = goog.require('elemental2.dom.HTMLLIElement.$Overlay');
const _HTMLParagraphElement_$Overlay = goog.require('elemental2.dom.HTMLParagraphElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Slide = goog.require('org.dominokit.domino.ui.carousel.Slide$impl');
exports = Slide;
 