/**
 * @fileoverview transpiled from javax.inject.Singleton$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.inject.Singleton.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Singleton = goog.require('javax.inject.Singleton');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Annotation = goog.require('java.lang.annotation.Annotation');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('javax.inject.Singleton.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 