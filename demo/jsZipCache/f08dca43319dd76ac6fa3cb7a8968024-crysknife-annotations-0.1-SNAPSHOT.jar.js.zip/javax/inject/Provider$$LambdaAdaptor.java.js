/**
 * @fileoverview transpiled from javax.inject.Provider$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.inject.Provider.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Provider = goog.require('javax.inject.Provider');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('javax.inject.Provider.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 