/**
 * @fileoverview transpiled from javax.enterprise.context.NormalScope.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('javax.enterprise.context.NormalScope$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class NormalScope {
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_passivating__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    NormalScope.$clinit = (() =>{
    });
    NormalScope.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__javax_enterprise_context_NormalScope = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__javax_enterprise_context_NormalScope;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__javax_enterprise_context_NormalScope;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(NormalScope, $Util.$makeClassName('javax.enterprise.context.NormalScope'));


NormalScope.$markImplementor(/** @type {Function} */ (NormalScope));


exports = NormalScope; 
//# sourceMappingURL=NormalScope.js.map