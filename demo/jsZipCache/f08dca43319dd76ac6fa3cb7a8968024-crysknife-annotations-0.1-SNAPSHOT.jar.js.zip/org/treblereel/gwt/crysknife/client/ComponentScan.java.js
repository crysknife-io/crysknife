/**
 * @fileoverview transpiled from org.treblereel.gwt.crysknife.client.ComponentScan.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.treblereel.gwt.crysknife.client.ComponentScan');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var ComponentScan = goog.require('org.treblereel.gwt.crysknife.client.ComponentScan$impl');
exports = ComponentScan;
 