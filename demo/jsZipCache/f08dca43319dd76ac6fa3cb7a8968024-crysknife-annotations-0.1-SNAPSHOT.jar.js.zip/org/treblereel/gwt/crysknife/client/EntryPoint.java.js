/**
 * @fileoverview transpiled from org.treblereel.gwt.crysknife.client.EntryPoint.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.treblereel.gwt.crysknife.client.EntryPoint');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.treblereel.gwt.crysknife.client.EntryPoint.$LambdaAdaptor');


// Re-exports the implementation.
var EntryPoint = goog.require('org.treblereel.gwt.crysknife.client.EntryPoint$impl');
exports = EntryPoint;
 