/**
 * @fileoverview transpiled from org.treblereel.gwt.crysknife.client.EntryPoint$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.treblereel.gwt.crysknife.client.EntryPoint.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EntryPoint = goog.require('org.treblereel.gwt.crysknife.client.EntryPoint');
const _Class = goog.require('java.lang.Class');
const _Annotation = goog.require('java.lang.annotation.Annotation');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.treblereel.gwt.crysknife.client.EntryPoint.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 