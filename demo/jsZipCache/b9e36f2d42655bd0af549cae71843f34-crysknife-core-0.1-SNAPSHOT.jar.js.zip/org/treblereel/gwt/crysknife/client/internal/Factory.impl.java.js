/**
 * @fileoverview transpiled from org.treblereel.gwt.crysknife.client.internal.Factory.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.treblereel.gwt.crysknife.client.internal.Factory$impl');


const Provider = goog.require('javax.inject.Provider$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.treblereel.gwt.crysknife.client.internal.Factory.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_T
 * @extends {Provider<C_T>}
 */
class Factory {
  /**
   * @template C_T
   * @param {?function():C_T} fn
   * @return {Factory<C_T>}
   * @public
   */
  static $adapt(fn) {
    Factory.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Factory.$clinit = (() =>{
    });
    Factory.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Provider.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_treblereel_gwt_crysknife_client_internal_Factory = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_treblereel_gwt_crysknife_client_internal_Factory;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_treblereel_gwt_crysknife_client_internal_Factory;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.treblereel.gwt.crysknife.client.internal.Factory.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(Factory, $Util.$makeClassName('org.treblereel.gwt.crysknife.client.internal.Factory'));


Factory.$markImplementor(/** @type {Function} */ (Factory));


exports = Factory; 
//# sourceMappingURL=Factory.js.map