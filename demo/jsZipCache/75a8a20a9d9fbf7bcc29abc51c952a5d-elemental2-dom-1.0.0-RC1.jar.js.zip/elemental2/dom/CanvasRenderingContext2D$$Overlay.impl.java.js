/**
 * @fileoverview transpiled from elemental2.dom.CanvasRenderingContext2D$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.CanvasRenderingContext2D.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let CanvasPattern_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasPattern.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.CanvasRenderingContext2D.ClipOptFillRuleOrPathUnionType.$Overlay$impl');
let CreatePatternImageUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasRenderingContext2D.CreatePatternImageUnionType.$Overlay$impl');
let DrawImageImageUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasRenderingContext2D.DrawImageImageUnionType.$Overlay$impl');
let FillOptFillRuleOrPathUnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasRenderingContext2D.FillOptFillRuleOrPathUnionType.$Overlay$impl');
let SetFillColorP0UnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasRenderingContext2D.SetFillColorP0UnionType.$Overlay$impl');
let SetStrokeColorP0UnionType_$Overlay = goog.forwardDeclare('elemental2.dom.CanvasRenderingContext2D.SetStrokeColorP0UnionType.$Overlay$impl');
let HTMLCanvasElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLCanvasElement.$Overlay$impl');
let HTMLImageElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let HTMLVideoElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLVideoElement.$Overlay$impl');
let Path2D_$Overlay = goog.forwardDeclare('elemental2.dom.Path2D.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class CanvasRenderingContext2D_$Overlay {
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {Path2D} optFillRuleOrPath
   * @param {?string} optFillRule
   * @return {void}
   * @public
   */
  static m_clip__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_Path2D__java_lang_String($thisArg, optFillRuleOrPath, optFillRule) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.clip(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)), optFillRule);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {Path2D} optFillRuleOrPath
   * @return {void}
   * @public
   */
  static m_clip__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_Path2D($thisArg, optFillRuleOrPath) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.clip(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} optFillRuleOrPath
   * @param {?string} optFillRule
   * @return {void}
   * @public
   */
  static m_clip__elemental2_dom_CanvasRenderingContext2D__java_lang_String__java_lang_String($thisArg, optFillRuleOrPath, optFillRule) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.clip(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)), optFillRule);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} optFillRuleOrPath
   * @return {void}
   * @public
   */
  static m_clip__elemental2_dom_CanvasRenderingContext2D__java_lang_String($thisArg, optFillRuleOrPath) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.clip(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {?string} repetition
   * @return {CanvasPattern}
   * @public
   */
  static m_createPattern__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__java_lang_String($thisArg, image, repetition) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    return $thisArg.createPattern(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), repetition);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {?string} repetition
   * @return {CanvasPattern}
   * @public
   */
  static m_createPattern__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__java_lang_String($thisArg, image, repetition) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    return $thisArg.createPattern(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), repetition);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {?string} repetition
   * @return {CanvasPattern}
   * @public
   */
  static m_createPattern__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__java_lang_String($thisArg, image, repetition) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    return $thisArg.createPattern(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), repetition);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @param {number} sw
   * @param {number} sh
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy, sw, sh) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy, sw, sh);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @param {number} sw
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy, sw) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy, sw);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double__double__double($thisArg, image, dx, dy, dw, dh) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double__double($thisArg, image, dx, dy, dw) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLCanvasElement} image
   * @param {number} dx
   * @param {number} dy
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLCanvasElement__double__double($thisArg, image, dx, dy) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @param {number} sw
   * @param {number} sh
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy, sw, sh) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy, sw, sh);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @param {number} sw
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy, sw) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy, sw);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double__double__double($thisArg, image, dx, dy, dw, dh) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double__double($thisArg, image, dx, dy, dw) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLImageElement} image
   * @param {number} dx
   * @param {number} dy
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLImageElement__double__double($thisArg, image, dx, dy) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @param {number} sw
   * @param {number} sh
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy, sw, sh) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy, sw, sh);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @param {number} sw
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy, sw) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy, sw);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @param {number} sy
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx, sy) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx, sy);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @param {number} sx
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double__double__double__double($thisArg, image, dx, dy, dw, dh, sx) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh, sx);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @param {number} dh
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double__double__double($thisArg, image, dx, dy, dw, dh) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw, dh);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @param {number} dw
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double__double($thisArg, image, dx, dy, dw) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy, dw);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {HTMLVideoElement} image
   * @param {number} dx
   * @param {number} dy
   * @return {void}
   * @public
   */
  static m_drawImage__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_HTMLVideoElement__double__double($thisArg, image, dx, dy) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.drawImage(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(image)), dx, dy);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {Path2D} optFillRuleOrPath
   * @param {?string} optFillRule
   * @return {void}
   * @public
   */
  static m_fill__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_Path2D__java_lang_String($thisArg, optFillRuleOrPath, optFillRule) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.fill(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)), optFillRule);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {Path2D} optFillRuleOrPath
   * @return {void}
   * @public
   */
  static m_fill__elemental2_dom_CanvasRenderingContext2D__elemental2_dom_Path2D($thisArg, optFillRuleOrPath) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.fill(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} optFillRuleOrPath
   * @param {?string} optFillRule
   * @return {void}
   * @public
   */
  static m_fill__elemental2_dom_CanvasRenderingContext2D__java_lang_String__java_lang_String($thisArg, optFillRuleOrPath, optFillRule) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.fill(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)), optFillRule);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} optFillRuleOrPath
   * @return {void}
   * @public
   */
  static m_fill__elemental2_dom_CanvasRenderingContext2D__java_lang_String($thisArg, optFillRuleOrPath) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.fill(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(optFillRuleOrPath)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @param {number} p4
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double__double__double__double($thisArg, p0, p1, p2, p3, p4) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3, p4);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double__double__double($thisArg, p0, p1, p2, p3) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @param {number} p2
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double__double($thisArg, p0, p1, p2) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double($thisArg, p0, p1) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String($thisArg, p0) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @param {number} p4
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__double__double__double__double__double($thisArg, p0, p1, p2, p3, p4) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3, p4);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__double__double__double__double($thisArg, p0, p1, p2, p3) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @param {number} p2
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__double__double__double($thisArg, p0, p1, p2) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__double__double($thisArg, p0, p1) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @return {void}
   * @public
   */
  static m_setFillColor__elemental2_dom_CanvasRenderingContext2D__double($thisArg, p0) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setFillColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @param {number} p4
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double__double__double__double($thisArg, p0, p1, p2, p3, p4) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3, p4);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double__double__double($thisArg, p0, p1, p2, p3) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @param {number} p2
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double__double($thisArg, p0, p1, p2) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @param {number} p1
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String__double($thisArg, p0, p1) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {?string} p0
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__java_lang_String($thisArg, p0) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)));
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @param {number} p4
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__double__double__double__double__double($thisArg, p0, p1, p2, p3, p4) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3, p4);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @param {number} p2
   * @param {number} p3
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__double__double__double__double($thisArg, p0, p1, p2, p3) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2, p3);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @param {number} p2
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__double__double__double($thisArg, p0, p1, p2) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1, p2);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @param {number} p1
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__double__double($thisArg, p0, p1) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)), p1);
  }
  
  /**
   * @param {CanvasRenderingContext2D} $thisArg
   * @param {number} p0
   * @return {void}
   * @public
   */
  static m_setStrokeColor__elemental2_dom_CanvasRenderingContext2D__double($thisArg, p0) {
    CanvasRenderingContext2D_$Overlay.$clinit();
    $thisArg.setStrokeColor(/**@type {?} */ (Js.m_uncheckedCast__java_lang_Object(p0)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    CanvasRenderingContext2D_$Overlay.$clinit = (() =>{
    });
    CanvasRenderingContext2D_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof CanvasRenderingContext2D;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(CanvasRenderingContext2D_$Overlay, $Util.$makeClassName('CanvasRenderingContext2D'));


exports = CanvasRenderingContext2D_$Overlay; 
//# sourceMappingURL=CanvasRenderingContext2D$$Overlay.js.map