/**
 * @fileoverview transpiled from elemental2.dom.CharacterData$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.CharacterData.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.CharacterData.ReplaceWithNodesUnionType.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var CharacterData_$Overlay = goog.require('elemental2.dom.CharacterData.$Overlay$impl');
exports = CharacterData_$Overlay;
 