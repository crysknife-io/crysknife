/**
 * @fileoverview transpiled from elemental2.dom.FetchEvent$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.dom.FetchEvent.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.FetchEvent.RespondWithRUnionType.$Overlay');
const _Response_$Overlay = goog.require('elemental2.dom.Response.$Overlay');
const _IThenable_$Overlay = goog.require('elemental2.promise.IThenable.$Overlay');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var FetchEvent_$Overlay = goog.require('elemental2.dom.FetchEvent.$Overlay$impl');
exports = FetchEvent_$Overlay;
 