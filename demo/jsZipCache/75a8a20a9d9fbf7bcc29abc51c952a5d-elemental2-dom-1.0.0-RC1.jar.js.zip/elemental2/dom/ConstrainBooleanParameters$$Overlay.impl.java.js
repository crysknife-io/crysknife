/**
 * @fileoverview transpiled from elemental2.dom.ConstrainBooleanParameters$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.dom.ConstrainBooleanParameters.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class ConstrainBooleanParameters_$Overlay {
  /**
   * @return {ConstrainBooleanParameters}
   * @public
   */
  static m_create__() {
    ConstrainBooleanParameters_$Overlay.$clinit();
    return /**@type {ConstrainBooleanParameters} */ (Js.m_uncheckedCast__java_lang_Object($Overlay.m_of__()));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ConstrainBooleanParameters_$Overlay.$clinit = (() =>{
    });
    ConstrainBooleanParameters_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Overlay = goog.module.get('jsinterop.base.JsPropertyMap.$Overlay$impl');
  }
  
  
};



exports = ConstrainBooleanParameters_$Overlay; 
//# sourceMappingURL=ConstrainBooleanParameters$$Overlay.js.map