/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlString.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlString');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');
const _NullPointerException = goog.require('java.lang.NullPointerException');
const _j_l_String = goog.require('java.lang.String');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var SafeHtmlString = goog.require('org.gwtproject.safehtml.shared.SafeHtmlString$impl');
exports = SafeHtmlString;
 