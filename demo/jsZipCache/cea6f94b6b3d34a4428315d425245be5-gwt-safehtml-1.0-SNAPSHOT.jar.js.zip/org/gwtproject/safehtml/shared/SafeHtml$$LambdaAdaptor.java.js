/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtml$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtml.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.SafeHtml.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 