/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeUri$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeUri.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _SafeUri = goog.require('org.gwtproject.safehtml.shared.SafeUri');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.SafeUri.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 