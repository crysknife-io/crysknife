/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeUriHostedModeUtils$JreImpl.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.SafeUriHostedModeUtils.JreImpl');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsImpl = goog.require('org.gwtproject.safehtml.shared.SafeUriHostedModeUtils.JsImpl');


// Re-exports the implementation.
var JreImpl = goog.require('org.gwtproject.safehtml.shared.SafeUriHostedModeUtils.JreImpl$impl');
exports = JreImpl;
 