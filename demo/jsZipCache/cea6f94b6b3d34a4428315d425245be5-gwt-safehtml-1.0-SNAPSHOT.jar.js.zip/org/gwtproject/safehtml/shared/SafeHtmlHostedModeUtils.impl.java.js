/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let JreImpl = goog.forwardDeclare('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils.JreImpl$impl');


class SafeHtmlHostedModeUtils extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!SafeHtmlHostedModeUtils}
   * @public
   */
  static $create__() {
    SafeHtmlHostedModeUtils.$clinit();
    let $instance = new SafeHtmlHostedModeUtils();
    $instance.$ctor__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @param {?string} html
   * @return {boolean}
   * @public
   */
  static m_isCompleteHtml__java_lang_String(html) {
    SafeHtmlHostedModeUtils.$clinit();
    return SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_.m_isCompleteHtml__java_lang_String(html);
  }
  
  /**
   * @param {?string} html
   * @return {void}
   * @public
   */
  static m_maybeCheckCompleteHtml__java_lang_String(html) {
    SafeHtmlHostedModeUtils.$clinit();
    SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_.m_maybeCheckCompleteHtml__java_lang_String(html);
  }
  
  /**
   * @param {boolean} check
   * @return {void}
   * @public
   */
  static m_setForceCheckCompleteHtml__boolean(check) {
    SafeHtmlHostedModeUtils.$clinit();
    SafeHtmlHostedModeUtils.$f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_ = check;
  }
  
  /**
   * @return {void}
   * @public
   */
  static m_setForceCheckCompleteHtmlFromProperty__() {
    SafeHtmlHostedModeUtils.$clinit();
    SafeHtmlHostedModeUtils.$f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_ = SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_.m_getForceCheckCompleteHtmlFromProperty__();
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static get f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_() {
    return (SafeHtmlHostedModeUtils.$clinit(), SafeHtmlHostedModeUtils.$f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_);
  }
  
  /**
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static set f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_(value) {
    (SafeHtmlHostedModeUtils.$clinit(), SafeHtmlHostedModeUtils.$f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_ = value);
  }
  
  /**
   * @return {JreImpl}
   * @public
   */
  static get f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_() {
    return (SafeHtmlHostedModeUtils.$clinit(), SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_);
  }
  
  /**
   * @param {JreImpl} value
   * @return {void}
   * @public
   */
  static set f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_(value) {
    (SafeHtmlHostedModeUtils.$clinit(), SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SafeHtmlHostedModeUtils.$clinit = (() =>{
    });
    SafeHtmlHostedModeUtils.$loadModules();
    j_l_Object.$clinit();
    SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_ = JreImpl.$create__();
    SafeHtmlHostedModeUtils.m_setForceCheckCompleteHtmlFromProperty__();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SafeHtmlHostedModeUtils;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SafeHtmlHostedModeUtils);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    JreImpl = goog.module.get('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils.JreImpl$impl');
  }
  
  
};

$Util.$setClassMetadata(SafeHtmlHostedModeUtils, $Util.$makeClassName('org.gwtproject.safehtml.shared.SafeHtmlHostedModeUtils'));


/** @public {?string} @const */
SafeHtmlHostedModeUtils.f_FORCE_CHECK_COMPLETE_HTML__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils = "com.google.gwt.safehtml.ForceCheckCompleteHtml";


/** @private {boolean} */
SafeHtmlHostedModeUtils.$f_forceCheckCompleteHtml__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_ = false;


/** @private {JreImpl} */
SafeHtmlHostedModeUtils.$f_impl__org_gwtproject_safehtml_shared_SafeHtmlHostedModeUtils_;




exports = SafeHtmlHostedModeUtils; 
//# sourceMappingURL=SafeHtmlHostedModeUtils.js.map