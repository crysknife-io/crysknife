/**
 * @fileoverview transpiled from org.gwtproject.safehtml.shared.HtmlSanitizer.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.safehtml.shared.HtmlSanitizer');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.gwtproject.safehtml.shared.HtmlSanitizer.$LambdaAdaptor');
const _SafeHtml = goog.require('org.gwtproject.safehtml.shared.SafeHtml');


// Re-exports the implementation.
var HtmlSanitizer = goog.require('org.gwtproject.safehtml.shared.HtmlSanitizer$impl');
exports = HtmlSanitizer;
 