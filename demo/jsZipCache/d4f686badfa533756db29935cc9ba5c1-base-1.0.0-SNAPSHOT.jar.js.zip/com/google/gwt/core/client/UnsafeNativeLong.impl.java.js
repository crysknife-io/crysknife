/**
 * @fileoverview transpiled from com.google.gwt.core.client.UnsafeNativeLong.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('com.google.gwt.core.client.UnsafeNativeLong$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('com.google.gwt.core.client.UnsafeNativeLong.$LambdaAdaptor$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class UnsafeNativeLong {
  /**
   * @param {?function():Class<?>} fn
   * @return {UnsafeNativeLong}
   * @public
   */
  static $adapt(fn) {
    UnsafeNativeLong.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    UnsafeNativeLong.$clinit = (() =>{
    });
    UnsafeNativeLong.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__com_google_gwt_core_client_UnsafeNativeLong = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__com_google_gwt_core_client_UnsafeNativeLong;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__com_google_gwt_core_client_UnsafeNativeLong;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('com.google.gwt.core.client.UnsafeNativeLong.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(UnsafeNativeLong, $Util.$makeClassName('com.google.gwt.core.client.UnsafeNativeLong'));


UnsafeNativeLong.$markImplementor(/** @type {Function} */ (UnsafeNativeLong));


exports = UnsafeNativeLong; 
//# sourceMappingURL=UnsafeNativeLong.js.map