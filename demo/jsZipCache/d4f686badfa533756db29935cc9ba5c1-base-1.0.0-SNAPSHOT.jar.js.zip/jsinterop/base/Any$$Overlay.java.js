/**
 * @fileoverview transpiled from jsinterop.base.Any$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.Any.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_Object = goog.require('java.lang.Object');
const _Js = goog.require('jsinterop.base.Js');
const _JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay');
const _$Overlay = goog.require('jsinterop.base.JsPropertyMap.$Overlay');
const _$Long = goog.require('nativebootstrap.Long');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Any_$Overlay = goog.require('jsinterop.base.Any.$Overlay$impl');
exports = Any_$Overlay;
 