/**
 * @fileoverview transpiled from jsinterop.base.JsArrayLike$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.JsArrayLike.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _j_l_Object = goog.require('java.lang.Object');
const _Arrays = goog.require('java.util.Arrays');
const _List = goog.require('java.util.List');
const _$Overlay = goog.require('jsinterop.base.Any.$Overlay');
const _InternalJsUtil = goog.require('jsinterop.base.InternalJsUtil');
const _Js = goog.require('jsinterop.base.Js');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var JsArrayLike_$Overlay = goog.require('jsinterop.base.JsArrayLike.$Overlay$impl');
exports = JsArrayLike_$Overlay;
 