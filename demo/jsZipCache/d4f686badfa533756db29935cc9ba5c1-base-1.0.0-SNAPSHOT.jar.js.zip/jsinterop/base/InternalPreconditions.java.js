/**
 * @fileoverview transpiled from jsinterop.base.InternalPreconditions.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('jsinterop.base.InternalPreconditions');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _AssertionError = goog.require('java.lang.AssertionError');
const _ClassCastException = goog.require('java.lang.ClassCastException');
const _Exception = goog.require('java.lang.Exception');
const _j_l_String = goog.require('java.lang.String');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var InternalPreconditions = goog.require('jsinterop.base.InternalPreconditions$impl');
exports = InternalPreconditions;
 