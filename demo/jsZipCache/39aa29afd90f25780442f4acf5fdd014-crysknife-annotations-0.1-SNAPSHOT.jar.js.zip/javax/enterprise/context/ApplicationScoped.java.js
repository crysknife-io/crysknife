/**
 * @fileoverview transpiled from javax.enterprise.context.ApplicationScoped.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.enterprise.context.ApplicationScoped');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('javax.enterprise.context.ApplicationScoped.$LambdaAdaptor');


// Re-exports the implementation.
var ApplicationScoped = goog.require('javax.enterprise.context.ApplicationScoped$impl');
exports = ApplicationScoped;
 