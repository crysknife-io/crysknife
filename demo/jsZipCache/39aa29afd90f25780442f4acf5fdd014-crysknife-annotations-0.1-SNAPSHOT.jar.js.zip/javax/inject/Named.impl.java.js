/**
 * @fileoverview transpiled from javax.inject.Named.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('javax.inject.Named$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class Named {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Named.$clinit = (() =>{
    });
    Named.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__javax_inject_Named = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__javax_inject_Named;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__javax_inject_Named;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(Named, $Util.$makeClassName('javax.inject.Named'));


Named.$markImplementor(/** @type {Function} */ (Named));


exports = Named; 
//# sourceMappingURL=Named.js.map