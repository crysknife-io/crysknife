/**
 * @fileoverview transpiled from javax.inject.Qualifier$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.inject.Qualifier.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _Qualifier = goog.require('javax.inject.Qualifier');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Annotation = goog.require('java.lang.annotation.Annotation');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('javax.inject.Qualifier.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 