/**
 * @fileoverview transpiled from javax.validation.metadata.ElementDescriptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('javax.validation.metadata.ElementDescriptor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


/**
 * @interface
 */
class ElementDescriptor {
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ElementDescriptor.$clinit = (() =>{
    });
    ElementDescriptor.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__javax_validation_metadata_ElementDescriptor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__javax_validation_metadata_ElementDescriptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__javax_validation_metadata_ElementDescriptor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(ElementDescriptor, $Util.$makeClassName('javax.validation.metadata.ElementDescriptor'));


ElementDescriptor.$markImplementor(/** @type {Function} */ (ElementDescriptor));


exports = ElementDescriptor; 
//# sourceMappingURL=ElementDescriptor.js.map