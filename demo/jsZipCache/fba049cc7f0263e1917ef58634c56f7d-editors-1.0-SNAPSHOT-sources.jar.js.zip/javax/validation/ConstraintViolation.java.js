/**
 * @fileoverview transpiled from javax.validation.ConstraintViolation.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.validation.ConstraintViolation');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _Path = goog.require('javax.validation.Path');


// Re-exports the implementation.
var ConstraintViolation = goog.require('javax.validation.ConstraintViolation$impl');
exports = ConstraintViolation;
 