/**
 * @fileoverview transpiled from javax.validation.ConstraintViolation.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('javax.validation.ConstraintViolation$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let Path = goog.forwardDeclare('javax.validation.Path$impl');


/**
 * @interface
 * @template C_T
 */
class ConstraintViolation {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getMessage__() {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getMessageTemplate__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_getRootBean__() {
  }
  
  /**
   * @abstract
   * @return {Class<C_T>}
   * @public
   */
  m_getRootBeanClass__() {
  }
  
  /**
   * @abstract
   * @return {*}
   * @public
   */
  m_getLeafBean__() {
  }
  
  /**
   * @abstract
   * @return {Path}
   * @public
   */
  m_getPropertyPath__() {
  }
  
  /**
   * @abstract
   * @return {*}
   * @public
   */
  m_getInvalidValue__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ConstraintViolation.$clinit = (() =>{
    });
    ConstraintViolation.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__javax_validation_ConstraintViolation = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__javax_validation_ConstraintViolation;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__javax_validation_ConstraintViolation;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(ConstraintViolation, $Util.$makeClassName('javax.validation.ConstraintViolation'));


ConstraintViolation.$markImplementor(/** @type {Function} */ (ConstraintViolation));


exports = ConstraintViolation; 
//# sourceMappingURL=ConstraintViolation.js.map