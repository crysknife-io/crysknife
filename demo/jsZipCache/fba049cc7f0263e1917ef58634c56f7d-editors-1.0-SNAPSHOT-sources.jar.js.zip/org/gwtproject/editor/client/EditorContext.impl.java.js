/**
 * @fileoverview transpiled from org.gwtproject.editor.client.EditorContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.EditorContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let CompositeEditor = goog.forwardDeclare('org.gwtproject.editor.client.CompositeEditor$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.EditorDelegate$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');
let HasEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.HasEditorDelegate$impl');
let HasEditorErrors = goog.forwardDeclare('org.gwtproject.editor.client.HasEditorErrors$impl');
let LeafValueEditor = goog.forwardDeclare('org.gwtproject.editor.client.LeafValueEditor$impl');
let ValueAwareEditor = goog.forwardDeclare('org.gwtproject.editor.client.ValueAwareEditor$impl');


/**
 * @interface
 * @template C_T
 */
class EditorContext {
  /**
   * @abstract
   * @return {CompositeEditor<C_T, ?, ?>}
   * @public
   */
  m_asCompositeEditor__() {
  }
  
  /**
   * @abstract
   * @return {HasEditorDelegate<C_T>}
   * @public
   */
  m_asHasEditorDelegate__() {
  }
  
  /**
   * @abstract
   * @return {HasEditorErrors<C_T>}
   * @public
   */
  m_asHasEditorErrors__() {
  }
  
  /**
   * @abstract
   * @return {LeafValueEditor<C_T>}
   * @public
   */
  m_asLeafValueEditor__() {
  }
  
  /**
   * @abstract
   * @return {ValueAwareEditor<C_T>}
   * @public
   */
  m_asValueAwareEditor__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_canSetInModel__() {
  }
  
  /**
   * @abstract
   * @param {*} value
   * @return {C_T}
   * @public
   */
  m_checkAssignment__java_lang_Object(value) {
  }
  
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getAbsolutePath__() {
  }
  
  /**
   * @abstract
   * @return {Class<C_T>}
   * @public
   */
  m_getEditedType__() {
  }
  
  /**
   * @abstract
   * @return {Editor<C_T>}
   * @public
   */
  m_getEditor__() {
  }
  
  /**
   * @abstract
   * @return {EditorDelegate<C_T>}
   * @public
   */
  m_getEditorDelegate__() {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_getFromModel__() {
  }
  
  /**
   * @abstract
   * @param {C_T} data
   * @return {void}
   * @public
   */
  m_setInModel__java_lang_Object(data) {
  }
  
  /**
   * @abstract
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_traverseSyntheticCompositeEditor__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditorContext.$clinit = (() =>{
    });
    EditorContext.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_EditorContext = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_EditorContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_EditorContext;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(EditorContext, $Util.$makeClassName('org.gwtproject.editor.client.EditorContext'));


/** @public {?string} @const */
EditorContext.f_ROOT_PATH__org_gwtproject_editor_client_EditorContext = "";


EditorContext.$markImplementor(/** @type {Function} */ (EditorContext));


exports = EditorContext; 
//# sourceMappingURL=EditorContext.js.map