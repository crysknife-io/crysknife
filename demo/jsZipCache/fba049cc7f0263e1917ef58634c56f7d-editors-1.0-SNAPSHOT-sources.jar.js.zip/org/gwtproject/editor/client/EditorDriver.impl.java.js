/**
 * @fileoverview transpiled from org.gwtproject.editor.client.EditorDriver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.EditorDriver$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let ConstraintViolation = goog.forwardDeclare('javax.validation.ConstraintViolation$impl');
let EditorError = goog.forwardDeclare('org.gwtproject.editor.client.EditorError$impl');
let EditorVisitor = goog.forwardDeclare('org.gwtproject.editor.client.EditorVisitor$impl');


/**
 * @interface
 * @template C_T
 */
class EditorDriver {
  /**
   * @abstract
   * @param {EditorVisitor} visitor
   * @return {void}
   * @public
   */
  m_accept__org_gwtproject_editor_client_EditorVisitor(visitor) {
  }
  
  /**
   * @abstract
   * @return {C_T}
   * @public
   */
  m_flush__() {
  }
  
  /**
   * @abstract
   * @return {List<EditorError>}
   * @public
   */
  m_getErrors__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_hasErrors__() {
  }
  
  /**
   * @abstract
   * @return {boolean}
   * @public
   */
  m_isDirty__() {
  }
  
  /**
   * @abstract
   * @param {Iterable<ConstraintViolation<?>>} violations
   * @return {boolean}
   * @public
   */
  m_setConstraintViolations__java_lang_Iterable(violations) {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    EditorDriver.$clinit = (() =>{
    });
    EditorDriver.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_EditorDriver = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_EditorDriver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_EditorDriver;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(EditorDriver, $Util.$makeClassName('org.gwtproject.editor.client.EditorDriver'));


EditorDriver.$markImplementor(/** @type {Function} */ (EditorDriver));


exports = EditorDriver; 
//# sourceMappingURL=EditorDriver.js.map