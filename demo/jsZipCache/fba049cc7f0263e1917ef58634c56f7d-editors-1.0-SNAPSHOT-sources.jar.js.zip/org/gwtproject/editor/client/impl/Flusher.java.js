/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.Flusher.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.Flusher');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _Stack = goog.require('java.util.Stack');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorContext = goog.require('org.gwtproject.editor.client.EditorContext');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$Asserts = goog.require('vmbootstrap.Asserts');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Flusher = goog.require('org.gwtproject.editor.client.impl.Flusher$impl');
exports = Flusher;
 