/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleViolation.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleViolation');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _Iterable = goog.require('java.lang.Iterable');
const _j_l_String = goog.require('java.lang.String');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _DelegateMap = goog.require('org.gwtproject.editor.client.impl.DelegateMap');
const _KeyMethod = goog.require('org.gwtproject.editor.client.impl.DelegateMap.KeyMethod');
const _ConstraintViolationIterable = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var SimpleViolation = goog.require('org.gwtproject.editor.client.impl.SimpleViolation$impl');
exports = SimpleViolation;
 