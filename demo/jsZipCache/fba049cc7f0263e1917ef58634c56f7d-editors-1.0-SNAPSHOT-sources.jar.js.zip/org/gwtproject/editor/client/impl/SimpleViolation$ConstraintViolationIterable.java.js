/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.SimpleViolation$ConstraintViolationIterable.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Iterable = goog.require('java.lang.Iterable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Iterator = goog.require('java.util.Iterator');
const _Spliterator = goog.require('java.util.Spliterator');
const _Consumer = goog.require('java.util.function.Consumer');
const _ConstraintViolation = goog.require('javax.validation.ConstraintViolation');
const _SimpleViolation = goog.require('org.gwtproject.editor.client.impl.SimpleViolation');
const _$1 = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable.$1');


// Re-exports the implementation.
var ConstraintViolationIterable = goog.require('org.gwtproject.editor.client.impl.SimpleViolation.ConstraintViolationIterable$impl');
exports = ConstraintViolationIterable;
 