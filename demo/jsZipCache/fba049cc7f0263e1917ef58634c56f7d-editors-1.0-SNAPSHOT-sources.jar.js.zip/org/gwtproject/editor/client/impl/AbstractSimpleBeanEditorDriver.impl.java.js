/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const SimpleBeanEditorDriver = goog.require('org.gwtproject.editor.client.SimpleBeanEditorDriver$impl');
const BaseEditorDriver = goog.require('org.gwtproject.editor.client.impl.BaseEditorDriver$impl');

let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');


/**
 * @abstract
 * @template C_T, C_E
 * @extends {BaseEditorDriver<C_T, C_E>}
 * @implements {SimpleBeanEditorDriver<C_T, C_E>}
  */
class AbstractSimpleBeanEditorDriver extends BaseEditorDriver {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_impl_AbstractSimpleBeanEditorDriver__() {
    this.$ctor__org_gwtproject_editor_client_impl_BaseEditorDriver__();
  }
  
  /**
   * @override
   * @param {C_T} object
   * @return {void}
   * @public
   */
  m_edit__java_lang_Object(object) {
    this.m_doEdit__java_lang_Object(object);
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_flush__() {
    this.m_doFlush__();
    return this.m_getObject__();
  }
  
  /**
   * @override
   * @param {C_E} editor
   * @return {void}
   * @public
   */
  m_initialize__org_gwtproject_editor_client_Editor(editor) {
    this.m_doInitialize__org_gwtproject_editor_client_Editor(editor);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AbstractSimpleBeanEditorDriver.$clinit = (() =>{
    });
    AbstractSimpleBeanEditorDriver.$loadModules();
    BaseEditorDriver.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AbstractSimpleBeanEditorDriver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AbstractSimpleBeanEditorDriver);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(AbstractSimpleBeanEditorDriver, $Util.$makeClassName('org.gwtproject.editor.client.impl.AbstractSimpleBeanEditorDriver'));


SimpleBeanEditorDriver.$markImplementor(AbstractSimpleBeanEditorDriver);


exports = AbstractSimpleBeanEditorDriver; 
//# sourceMappingURL=AbstractSimpleBeanEditorDriver.js.map