/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.RootEditorContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.impl.RootEditorContext$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const AbstractEditorContext = goog.require('org.gwtproject.editor.client.impl.AbstractEditorContext$impl');

let Class = goog.forwardDeclare('java.lang.Class$impl');
let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let AbstractEditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.impl.AbstractEditorDelegate$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {AbstractEditorContext<C_T>}
  */
class RootEditorContext extends AbstractEditorContext {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Class<C_T>} */
    this.f_editedType__org_gwtproject_editor_client_impl_RootEditorContext_;
    /** @public {C_T} */
    this.f_value__org_gwtproject_editor_client_impl_RootEditorContext_;
  }
  
  /**
   * @template C_T
   * @param {AbstractEditorDelegate<C_T, ?>} editorDelegate
   * @param {Class<C_T>} editedType
   * @param {C_T} value
   * @return {!RootEditorContext<C_T>}
   * @public
   */
  static $create__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_Class__java_lang_Object(editorDelegate, editedType, value) {
    RootEditorContext.$clinit();
    let $instance = new RootEditorContext();
    $instance.$ctor__org_gwtproject_editor_client_impl_RootEditorContext__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_Class__java_lang_Object(editorDelegate, editedType, value);
    return $instance;
  }
  
  /**
   * @param {AbstractEditorDelegate<C_T, ?>} editorDelegate
   * @param {Class<C_T>} editedType
   * @param {C_T} value
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_impl_RootEditorContext__org_gwtproject_editor_client_impl_AbstractEditorDelegate__java_lang_Class__java_lang_Object(editorDelegate, editedType, value) {
    this.$ctor__org_gwtproject_editor_client_impl_AbstractEditorContext__org_gwtproject_editor_client_Editor__java_lang_String(editorDelegate.m_getEditor__(), editorDelegate.m_getPath__());
    this.m_setEditorDelegate__org_gwtproject_editor_client_impl_AbstractEditorDelegate(editorDelegate);
    this.f_editedType__org_gwtproject_editor_client_impl_RootEditorContext_ = editedType;
    this.f_value__org_gwtproject_editor_client_impl_RootEditorContext_ = value;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_canSetInModel__() {
    return true;
  }
  
  /**
   * @override
   * @param {*} value
   * @return {C_T}
   * @public
   */
  m_checkAssignment__java_lang_Object(value) {
    return /**@type {C_T} */ ($Casts.$to(value, j_l_Object));
  }
  
  /**
   * @override
   * @return {Class<C_T>}
   * @public
   */
  m_getEditedType__() {
    return this.f_editedType__org_gwtproject_editor_client_impl_RootEditorContext_;
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_getFromModel__() {
    return this.f_value__org_gwtproject_editor_client_impl_RootEditorContext_;
  }
  
  /**
   * @override
   * @param {C_T} data
   * @return {void}
   * @public
   */
  m_setInModel__java_lang_Object(data) {
    /**@type {AbstractEditorDelegate<C_T, Editor>} */ ($Casts.$to(this.m_getEditorDelegate__(), AbstractEditorDelegate)).m_setObject__java_lang_Object(data);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RootEditorContext.$clinit = (() =>{
    });
    RootEditorContext.$loadModules();
    AbstractEditorContext.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RootEditorContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RootEditorContext);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_Object = goog.module.get('java.lang.Object$impl');
    AbstractEditorDelegate = goog.module.get('org.gwtproject.editor.client.impl.AbstractEditorDelegate$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(RootEditorContext, $Util.$makeClassName('org.gwtproject.editor.client.impl.RootEditorContext'));




exports = RootEditorContext; 
//# sourceMappingURL=RootEditorContext.js.map