/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.AbstractEditorDelegate.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.AbstractEditorDelegate');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EditorDelegate = goog.require('org.gwtproject.editor.client.EditorDelegate');
const _Class = goog.require('java.lang.Class');
const _IllegalStateException = goog.require('java.lang.IllegalStateException');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorError = goog.require('org.gwtproject.editor.client.EditorError');
const _EditorVisitor = goog.require('org.gwtproject.editor.client.EditorVisitor');
const _Chain = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate.Chain');
const _Initializer = goog.require('org.gwtproject.editor.client.impl.Initializer');
const _SimpleError = goog.require('org.gwtproject.editor.client.impl.SimpleError');
const _HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Exceptions = goog.require('vmbootstrap.Exceptions');


// Re-exports the implementation.
var AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate$impl');
exports = AbstractEditorDelegate;
 