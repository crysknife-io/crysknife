/**
 * @fileoverview transpiled from org.gwtproject.editor.client.impl.DelegateMap.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.impl.DelegateMap');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Iterable = goog.require('java.lang.Iterable');
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _ArrayList = goog.require('java.util.ArrayList');
const _HashMap = goog.require('java.util.HashMap');
const _Iterator = goog.require('java.util.Iterator');
const _List = goog.require('java.util.List');
const _Map = goog.require('java.util.Map');
const _Spliterator = goog.require('java.util.Spliterator');
const _Consumer = goog.require('java.util.function.Consumer');
const _$Equality = goog.require('nativebootstrap.Equality');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDriver = goog.require('org.gwtproject.editor.client.EditorDriver');
const _AbstractEditorDelegate = goog.require('org.gwtproject.editor.client.impl.AbstractEditorDelegate');
const _$1 = goog.require('org.gwtproject.editor.client.impl.DelegateMap.$1');
const _$2 = goog.require('org.gwtproject.editor.client.impl.DelegateMap.$2');
const _KeyMethod = goog.require('org.gwtproject.editor.client.impl.DelegateMap.KeyMethod');
const _MapIterator = goog.require('org.gwtproject.editor.client.impl.DelegateMap.MapIterator');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DelegateMap = goog.require('org.gwtproject.editor.client.impl.DelegateMap$impl');
exports = DelegateMap;
 