/**
 * @fileoverview transpiled from org.gwtproject.editor.client.IsEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.IsEditor$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.gwtproject.editor.client.IsEditor.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_E
 */
class IsEditor {
  /**
   * @abstract
   * @return {C_E}
   * @public
   */
  m_asEditor__() {
  }
  
  /**
   * @template C_E
   * @param {?function():C_E} fn
   * @return {IsEditor<C_E>}
   * @public
   */
  static $adapt(fn) {
    IsEditor.$clinit();
    return /**@type {!$LambdaAdaptor<Editor>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    IsEditor.$clinit = (() =>{
    });
    IsEditor.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_gwtproject_editor_client_IsEditor = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_gwtproject_editor_client_IsEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_gwtproject_editor_client_IsEditor;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.gwtproject.editor.client.IsEditor.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(IsEditor, $Util.$makeClassName('org.gwtproject.editor.client.IsEditor'));


IsEditor.$markImplementor(/** @type {Function} */ (IsEditor));


exports = IsEditor; 
//# sourceMappingURL=IsEditor.js.map