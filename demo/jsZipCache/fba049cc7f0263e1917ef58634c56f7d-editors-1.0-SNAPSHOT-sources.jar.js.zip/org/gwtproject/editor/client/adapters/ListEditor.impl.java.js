/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.ListEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.adapters.ListEditor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor$impl');

let Collections = goog.forwardDeclare('java.util.Collections$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let EditorChain = goog.forwardDeclare('org.gwtproject.editor.client.CompositeEditor.EditorChain$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.EditorDelegate$impl');
let EditorSource = goog.forwardDeclare('org.gwtproject.editor.client.adapters.EditorSource$impl');
let ListEditorWrapper = goog.forwardDeclare('org.gwtproject.editor.client.adapters.ListEditorWrapper$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T, C_E
 * @implements {CompositeEditor<List<C_T>, C_T, C_E>}
  */
class ListEditor extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {EditorChain<C_T, C_E>} */
    this.f_chain__org_gwtproject_editor_client_adapters_ListEditor_;
    /** @public {EditorSource<C_E>} */
    this.f_editorSource__org_gwtproject_editor_client_adapters_ListEditor_;
    /** @public {ListEditorWrapper<C_T, C_E>} */
    this.f_list__org_gwtproject_editor_client_adapters_ListEditor_;
  }
  
  /**
   * @template M_T, M_E
   * @param {EditorSource<M_E>} source
   * @return {ListEditor<M_T, M_E>}
   * @public
   */
  static m_of__org_gwtproject_editor_client_adapters_EditorSource(source) {
    ListEditor.$clinit();
    return /**@type {!ListEditor<*, Editor>} */ (ListEditor.$create__org_gwtproject_editor_client_adapters_EditorSource(source));
  }
  
  /**
   * @template C_T, C_E
   * @param {EditorSource<C_E>} source
   * @return {!ListEditor<C_T, C_E>}
   * @public
   */
  static $create__org_gwtproject_editor_client_adapters_EditorSource(source) {
    ListEditor.$clinit();
    let $instance = new ListEditor();
    $instance.$ctor__org_gwtproject_editor_client_adapters_ListEditor__org_gwtproject_editor_client_adapters_EditorSource(source);
    return $instance;
  }
  
  /**
   * @param {EditorSource<C_E>} source
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_adapters_ListEditor__org_gwtproject_editor_client_adapters_EditorSource(source) {
    this.$ctor__java_lang_Object__();
    this.f_editorSource__org_gwtproject_editor_client_adapters_ListEditor_ = source;
  }
  
  /**
   * @override
   * @return {C_E}
   * @public
   */
  m_createEditorForTraversal__() {
    return this.f_editorSource__org_gwtproject_editor_client_adapters_ListEditor_.m_createEditorForTraversal__();
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_flush__() {
    if (!$Equality.$same(this.f_list__org_gwtproject_editor_client_adapters_ListEditor_, null)) {
      this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_flush___$pp_org_gwtproject_editor_client_adapters();
    }
  }
  
  /**
   * @return {List<C_E>}
   * @public
   */
  m_getEditors__() {
    if ($Equality.$same(this.f_list__org_gwtproject_editor_client_adapters_ListEditor_, null)) {
      return /**@type {List<C_E>} */ (Collections.m_emptyList__());
    }
    return /**@type {List<C_E>} */ (Collections.m_unmodifiableList__java_util_List(this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_getEditors___$pp_org_gwtproject_editor_client_adapters()));
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getList__() {
    return this.f_list__org_gwtproject_editor_client_adapters_ListEditor_;
  }
  
  /**
   * @override
   * @param {C_E} subEditor
   * @return {?string}
   * @public
   */
  m_getPathElement__org_gwtproject_editor_client_Editor(subEditor) {
    return "[" + this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_getEditors___$pp_org_gwtproject_editor_client_adapters().indexOf(subEditor) + "]";
  }
  
  /**
   * @override
   * @param {Array<?string>} paths
   * @return {void}
   * @public
   */
  m_onPropertyChange__arrayOf_java_lang_String(paths) {
  }
  
  /**
   * @override
   * @param {EditorDelegate<List<C_T>>} delegate
   * @return {void}
   * @public
   */
  m_setDelegate__org_gwtproject_editor_client_EditorDelegate(delegate) {
  }
  
  /**
   * @override
   * @param {EditorChain<C_T, C_E>} chain
   * @return {void}
   * @public
   */
  m_setEditorChain__org_gwtproject_editor_client_CompositeEditor_EditorChain(chain) {
    this.f_chain__org_gwtproject_editor_client_adapters_ListEditor_ = chain;
  }
  
  /**
   * @param {List<C_T>} value
   * @return {void}
   * @public
   */
  m_setValue__java_util_List(value) {
    if ($Equality.$same(this.f_list__org_gwtproject_editor_client_adapters_ListEditor_, null) && $Equality.$same(value, null)) {
      return;
    }
    if (!$Equality.$same(this.f_list__org_gwtproject_editor_client_adapters_ListEditor_, null) && this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_isSameValue__java_util_List_$pp_org_gwtproject_editor_client_adapters(value)) {
      this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_refresh___$pp_org_gwtproject_editor_client_adapters();
      return;
    }
    if (!$Equality.$same(this.f_list__org_gwtproject_editor_client_adapters_ListEditor_, null)) {
      this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_detach___$pp_org_gwtproject_editor_client_adapters();
    }
    if ($Equality.$same(value, null)) {
      this.f_list__org_gwtproject_editor_client_adapters_ListEditor_ = null;
    } else {
      this.f_list__org_gwtproject_editor_client_adapters_ListEditor_ = /**@type {!ListEditorWrapper<C_T, C_E>} */ (ListEditorWrapper.$create__java_util_List__org_gwtproject_editor_client_CompositeEditor_EditorChain__org_gwtproject_editor_client_adapters_EditorSource(value, this.f_chain__org_gwtproject_editor_client_adapters_ListEditor_, this.f_editorSource__org_gwtproject_editor_client_adapters_ListEditor_));
      this.f_list__org_gwtproject_editor_client_adapters_ListEditor_.m_attach___$pp_org_gwtproject_editor_client_adapters();
    }
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(arg0) {
    this.m_setValue__java_util_List(/**@type {List<C_T>} */ ($Casts.$to(arg0, List)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ListEditor.$clinit = (() =>{
    });
    ListEditor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ListEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ListEditor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Collections = goog.module.get('java.util.Collections$impl');
    List = goog.module.get('java.util.List$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    ListEditorWrapper = goog.module.get('org.gwtproject.editor.client.adapters.ListEditorWrapper$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ListEditor, $Util.$makeClassName('org.gwtproject.editor.client.adapters.ListEditor'));


CompositeEditor.$markImplementor(ListEditor);


exports = ListEditor; 
//# sourceMappingURL=ListEditor.js.map