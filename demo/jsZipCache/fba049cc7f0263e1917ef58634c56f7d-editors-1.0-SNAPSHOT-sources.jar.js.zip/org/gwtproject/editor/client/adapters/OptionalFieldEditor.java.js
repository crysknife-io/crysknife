/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.OptionalFieldEditor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.adapters.OptionalFieldEditor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');
const _$Equality = goog.require('nativebootstrap.Equality');
const _EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDelegate = goog.require('org.gwtproject.editor.client.EditorDelegate');


// Re-exports the implementation.
var OptionalFieldEditor = goog.require('org.gwtproject.editor.client.adapters.OptionalFieldEditor$impl');
exports = OptionalFieldEditor;
 