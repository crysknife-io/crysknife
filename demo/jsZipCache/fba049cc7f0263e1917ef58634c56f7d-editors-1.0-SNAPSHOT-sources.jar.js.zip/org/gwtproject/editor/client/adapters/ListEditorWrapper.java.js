/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.ListEditorWrapper.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.adapters.ListEditorWrapper');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _AbstractList = goog.require('java.util.AbstractList');
const _$Util = goog.require('nativebootstrap.Util');
const _Iterable = goog.require('java.lang.Iterable');
const _ArrayList = goog.require('java.util.ArrayList');
const _Collection = goog.require('java.util.Collection');
const _Comparator = goog.require('java.util.Comparator');
const _List = goog.require('java.util.List');
const _Spliterator = goog.require('java.util.Spliterator');
const _Consumer = goog.require('java.util.function.Consumer');
const _Predicate = goog.require('java.util.function.Predicate');
const _UnaryOperator = goog.require('java.util.function.UnaryOperator');
const _Stream = goog.require('java.util.stream.Stream');
const _$Equality = goog.require('nativebootstrap.Equality');
const _EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorSource = goog.require('org.gwtproject.editor.client.adapters.EditorSource');
const _$Asserts = goog.require('vmbootstrap.Asserts');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var ListEditorWrapper = goog.require('org.gwtproject.editor.client.adapters.ListEditorWrapper$impl');
exports = ListEditorWrapper;
 