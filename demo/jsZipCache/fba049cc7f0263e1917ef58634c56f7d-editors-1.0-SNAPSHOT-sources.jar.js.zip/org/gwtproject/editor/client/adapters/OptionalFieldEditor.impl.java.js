/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.OptionalFieldEditor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.editor.client.adapters.OptionalFieldEditor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor$impl');
const LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let EditorChain = goog.forwardDeclare('org.gwtproject.editor.client.CompositeEditor.EditorChain$impl');
let Editor = goog.forwardDeclare('org.gwtproject.editor.client.Editor$impl');
let EditorDelegate = goog.forwardDeclare('org.gwtproject.editor.client.EditorDelegate$impl');


/**
 * @template C_T, C_E
 * @implements {CompositeEditor<C_T, C_T, C_E>}
 * @implements {LeafValueEditor<C_T>}
  */
class OptionalFieldEditor extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {EditorChain<C_T, C_E>} */
    this.f_chain__org_gwtproject_editor_client_adapters_OptionalFieldEditor_;
    /** @public {C_T} */
    this.f_currentValue__org_gwtproject_editor_client_adapters_OptionalFieldEditor_;
    /** @public {C_E} */
    this.f_subEditor__org_gwtproject_editor_client_adapters_OptionalFieldEditor_;
  }
  
  /**
   * @template M_T, M_E
   * @param {M_E} subEditor
   * @return {OptionalFieldEditor<M_T, M_E>}
   * @public
   */
  static m_of__org_gwtproject_editor_client_Editor(subEditor) {
    OptionalFieldEditor.$clinit();
    return /**@type {!OptionalFieldEditor<*, Editor>} */ (OptionalFieldEditor.$create__org_gwtproject_editor_client_Editor(subEditor));
  }
  
  /**
   * @template C_T, C_E
   * @param {C_E} subEditor
   * @return {!OptionalFieldEditor<C_T, C_E>}
   * @public
   */
  static $create__org_gwtproject_editor_client_Editor(subEditor) {
    OptionalFieldEditor.$clinit();
    let $instance = new OptionalFieldEditor();
    $instance.$ctor__org_gwtproject_editor_client_adapters_OptionalFieldEditor__org_gwtproject_editor_client_Editor(subEditor);
    return $instance;
  }
  
  /**
   * @param {C_E} subEditor
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_editor_client_adapters_OptionalFieldEditor__org_gwtproject_editor_client_Editor(subEditor) {
    this.$ctor__java_lang_Object__();
    this.f_subEditor__org_gwtproject_editor_client_adapters_OptionalFieldEditor_ = subEditor;
  }
  
  /**
   * @override
   * @return {C_E}
   * @public
   */
  m_createEditorForTraversal__() {
    return this.f_subEditor__org_gwtproject_editor_client_adapters_OptionalFieldEditor_;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_flush__() {
    this.f_currentValue__org_gwtproject_editor_client_adapters_OptionalFieldEditor_ = this.f_chain__org_gwtproject_editor_client_adapters_OptionalFieldEditor_.m_getValue__org_gwtproject_editor_client_Editor(this.f_subEditor__org_gwtproject_editor_client_adapters_OptionalFieldEditor_);
  }
  
  /**
   * @override
   * @param {C_E} subEditor
   * @return {?string}
   * @public
   */
  m_getPathElement__org_gwtproject_editor_client_Editor(subEditor) {
    return "";
  }
  
  /**
   * @override
   * @return {C_T}
   * @public
   */
  m_getValue__() {
    return this.f_currentValue__org_gwtproject_editor_client_adapters_OptionalFieldEditor_;
  }
  
  /**
   * @override
   * @param {Array<?string>} paths
   * @return {void}
   * @public
   */
  m_onPropertyChange__arrayOf_java_lang_String(paths) {
  }
  
  /**
   * @override
   * @param {EditorDelegate<C_T>} delegate
   * @return {void}
   * @public
   */
  m_setDelegate__org_gwtproject_editor_client_EditorDelegate(delegate) {
  }
  
  /**
   * @override
   * @param {EditorChain<C_T, C_E>} chain
   * @return {void}
   * @public
   */
  m_setEditorChain__org_gwtproject_editor_client_CompositeEditor_EditorChain(chain) {
    this.f_chain__org_gwtproject_editor_client_adapters_OptionalFieldEditor_ = chain;
  }
  
  /**
   * @override
   * @param {C_T} value
   * @return {void}
   * @public
   */
  m_setValue__java_lang_Object(value) {
    if (!$Equality.$same(this.f_currentValue__org_gwtproject_editor_client_adapters_OptionalFieldEditor_, null) && $Equality.$same(value, null)) {
      this.f_chain__org_gwtproject_editor_client_adapters_OptionalFieldEditor_.m_detach__org_gwtproject_editor_client_Editor(this.f_subEditor__org_gwtproject_editor_client_adapters_OptionalFieldEditor_);
    }
    this.f_currentValue__org_gwtproject_editor_client_adapters_OptionalFieldEditor_ = value;
    if (!$Equality.$same(value, null)) {
      this.f_chain__org_gwtproject_editor_client_adapters_OptionalFieldEditor_.m_attach__java_lang_Object__org_gwtproject_editor_client_Editor(value, this.f_subEditor__org_gwtproject_editor_client_adapters_OptionalFieldEditor_);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    OptionalFieldEditor.$clinit = (() =>{
    });
    OptionalFieldEditor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof OptionalFieldEditor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, OptionalFieldEditor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
  }
  
  
};

$Util.$setClassMetadata(OptionalFieldEditor, $Util.$makeClassName('org.gwtproject.editor.client.adapters.OptionalFieldEditor'));


CompositeEditor.$markImplementor(OptionalFieldEditor);
LeafValueEditor.$markImplementor(OptionalFieldEditor);


exports = OptionalFieldEditor; 
//# sourceMappingURL=OptionalFieldEditor.js.map