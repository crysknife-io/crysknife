/**
 * @fileoverview transpiled from org.gwtproject.editor.client.adapters.ListEditor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.adapters.ListEditor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _CompositeEditor = goog.require('org.gwtproject.editor.client.CompositeEditor');
const _Collections = goog.require('java.util.Collections');
const _List = goog.require('java.util.List');
const _$Equality = goog.require('nativebootstrap.Equality');
const _EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _EditorDelegate = goog.require('org.gwtproject.editor.client.EditorDelegate');
const _EditorSource = goog.require('org.gwtproject.editor.client.adapters.EditorSource');
const _ListEditorWrapper = goog.require('org.gwtproject.editor.client.adapters.ListEditorWrapper');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ListEditor = goog.require('org.gwtproject.editor.client.adapters.ListEditor$impl');
exports = ListEditor;
 