/**
 * @fileoverview transpiled from org.gwtproject.editor.client.EditorError.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.EditorError');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');


// Re-exports the implementation.
var EditorError = goog.require('org.gwtproject.editor.client.EditorError$impl');
exports = EditorError;
 