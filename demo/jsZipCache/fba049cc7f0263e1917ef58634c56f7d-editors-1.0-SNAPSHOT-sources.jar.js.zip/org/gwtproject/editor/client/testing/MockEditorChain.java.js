/**
 * @fileoverview transpiled from org.gwtproject.editor.client.testing.MockEditorChain.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.editor.client.testing.MockEditorChain');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _EditorChain = goog.require('org.gwtproject.editor.client.CompositeEditor.EditorChain');
const _Boolean = goog.require('java.lang.Boolean');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _Editor = goog.require('org.gwtproject.editor.client.Editor');
const _FakeLeafValueEditor = goog.require('org.gwtproject.editor.client.testing.FakeLeafValueEditor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var MockEditorChain = goog.require('org.gwtproject.editor.client.testing.MockEditorChain$impl');
exports = MockEditorChain;
 