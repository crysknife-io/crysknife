/**
 * @fileoverview transpiled from javax.annotation.Generated.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.annotation.Generated');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');


// Re-exports the implementation.
var Generated = goog.require('javax.annotation.Generated$impl');
exports = Generated;
 