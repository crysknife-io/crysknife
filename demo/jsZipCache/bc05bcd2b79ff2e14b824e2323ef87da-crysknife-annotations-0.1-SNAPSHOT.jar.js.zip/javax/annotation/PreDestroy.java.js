/**
 * @fileoverview transpiled from javax.annotation.PreDestroy.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('javax.annotation.PreDestroy');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('javax.annotation.PreDestroy.$LambdaAdaptor');


// Re-exports the implementation.
var PreDestroy = goog.require('javax.annotation.PreDestroy$impl');
exports = PreDestroy;
 