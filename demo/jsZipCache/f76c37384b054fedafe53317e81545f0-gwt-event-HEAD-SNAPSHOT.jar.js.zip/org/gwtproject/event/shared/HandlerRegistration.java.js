/**
 * @fileoverview transpiled from org.gwtproject.event.shared.HandlerRegistration.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.event.shared.HandlerRegistration');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.gwtproject.event.shared.HandlerRegistration.$LambdaAdaptor');


// Re-exports the implementation.
var HandlerRegistration = goog.require('org.gwtproject.event.shared.HandlerRegistration$impl');
exports = HandlerRegistration;
 