/**
 * @fileoverview transpiled from elemental2.svg.SVGException$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGException.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_INVALID_VALUE_ERR__elemental2_svg_SVGException_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_INVALID_VALUE_ERR__elemental2_svg_SVGException_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_INVALID_VALUE_ERR__elemental2_svg_SVGException_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_INVALID_VALUE_ERR__elemental2_svg_SVGException_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MATRIX_NOT_INVERTABLE__elemental2_svg_SVGException_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MATRIX_NOT_INVERTABLE__elemental2_svg_SVGException_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MATRIX_NOT_INVERTABLE__elemental2_svg_SVGException_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MATRIX_NOT_INVERTABLE__elemental2_svg_SVGException_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_WRONG_TYPE_ERR__elemental2_svg_SVGException_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_WRONG_TYPE_ERR__elemental2_svg_SVGException_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_WRONG_TYPE_ERR__elemental2_svg_SVGException_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_WRONG_TYPE_ERR__elemental2_svg_SVGException_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_INVALID_VALUE_ERR__elemental2_svg_SVGException_$Overlay = SVGException.SVG_INVALID_VALUE_ERR;
    $Overlay.$f_SVG_MATRIX_NOT_INVERTABLE__elemental2_svg_SVGException_$Overlay = SVGException.SVG_MATRIX_NOT_INVERTABLE;
    $Overlay.$f_SVG_WRONG_TYPE_ERR__elemental2_svg_SVGException_$Overlay = SVGException.SVG_WRONG_TYPE_ERR;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGException;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGException'));


/** @private {number} */
$Overlay.$f_SVG_INVALID_VALUE_ERR__elemental2_svg_SVGException_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MATRIX_NOT_INVERTABLE__elemental2_svg_SVGException_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_WRONG_TYPE_ERR__elemental2_svg_SVGException_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGException$$Overlay.js.map