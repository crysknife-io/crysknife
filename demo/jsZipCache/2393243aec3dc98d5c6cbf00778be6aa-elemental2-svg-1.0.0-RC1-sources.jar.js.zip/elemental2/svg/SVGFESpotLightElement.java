package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGFESpotLightElement extends SVGElement {
  public SVGAnimatedNumber limitingConeAngle;
  public SVGAnimatedNumber pointsAtX;
  public SVGAnimatedNumber pointsAtY;
  public SVGAnimatedNumber pointsAtZ;
  public SVGAnimatedNumber specularExponent;
  public SVGAnimatedNumber x;
  public SVGAnimatedNumber y;
  public SVGAnimatedNumber z;
}
