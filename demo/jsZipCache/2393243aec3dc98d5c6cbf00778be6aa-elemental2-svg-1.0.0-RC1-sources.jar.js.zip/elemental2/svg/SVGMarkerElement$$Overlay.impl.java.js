/**
 * @fileoverview transpiled from elemental2.svg.SVGMarkerElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGMarkerElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MARKERUNITS_STROKEWIDTH__elemental2_svg_SVGMarkerElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MARKERUNITS_STROKEWIDTH__elemental2_svg_SVGMarkerElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MARKERUNITS_STROKEWIDTH__elemental2_svg_SVGMarkerElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MARKERUNITS_STROKEWIDTH__elemental2_svg_SVGMarkerElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MARKERUNITS_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MARKERUNITS_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MARKERUNITS_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MARKERUNITS_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MARKERUNITS_USERSPACEONUSE__elemental2_svg_SVGMarkerElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MARKERUNITS_USERSPACEONUSE__elemental2_svg_SVGMarkerElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MARKERUNITS_USERSPACEONUSE__elemental2_svg_SVGMarkerElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MARKERUNITS_USERSPACEONUSE__elemental2_svg_SVGMarkerElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MARKER_ORIENT_ANGLE__elemental2_svg_SVGMarkerElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MARKER_ORIENT_ANGLE__elemental2_svg_SVGMarkerElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MARKER_ORIENT_ANGLE__elemental2_svg_SVGMarkerElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MARKER_ORIENT_ANGLE__elemental2_svg_SVGMarkerElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MARKER_ORIENT_AUTO__elemental2_svg_SVGMarkerElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MARKER_ORIENT_AUTO__elemental2_svg_SVGMarkerElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MARKER_ORIENT_AUTO__elemental2_svg_SVGMarkerElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MARKER_ORIENT_AUTO__elemental2_svg_SVGMarkerElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_MARKER_ORIENT_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_MARKER_ORIENT_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_MARKER_ORIENT_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_MARKER_ORIENT_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_MARKERUNITS_STROKEWIDTH__elemental2_svg_SVGMarkerElement_$Overlay = SVGMarkerElement.SVG_MARKERUNITS_STROKEWIDTH;
    $Overlay.$f_SVG_MARKERUNITS_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay = SVGMarkerElement.SVG_MARKERUNITS_UNKNOWN;
    $Overlay.$f_SVG_MARKERUNITS_USERSPACEONUSE__elemental2_svg_SVGMarkerElement_$Overlay = SVGMarkerElement.SVG_MARKERUNITS_USERSPACEONUSE;
    $Overlay.$f_SVG_MARKER_ORIENT_ANGLE__elemental2_svg_SVGMarkerElement_$Overlay = SVGMarkerElement.SVG_MARKER_ORIENT_ANGLE;
    $Overlay.$f_SVG_MARKER_ORIENT_AUTO__elemental2_svg_SVGMarkerElement_$Overlay = SVGMarkerElement.SVG_MARKER_ORIENT_AUTO;
    $Overlay.$f_SVG_MARKER_ORIENT_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay = SVGMarkerElement.SVG_MARKER_ORIENT_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGMarkerElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGMarkerElement'));


/** @private {number} */
$Overlay.$f_SVG_MARKERUNITS_STROKEWIDTH__elemental2_svg_SVGMarkerElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MARKERUNITS_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MARKERUNITS_USERSPACEONUSE__elemental2_svg_SVGMarkerElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MARKER_ORIENT_ANGLE__elemental2_svg_SVGMarkerElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MARKER_ORIENT_AUTO__elemental2_svg_SVGMarkerElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_MARKER_ORIENT_UNKNOWN__elemental2_svg_SVGMarkerElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGMarkerElement$$Overlay.js.map