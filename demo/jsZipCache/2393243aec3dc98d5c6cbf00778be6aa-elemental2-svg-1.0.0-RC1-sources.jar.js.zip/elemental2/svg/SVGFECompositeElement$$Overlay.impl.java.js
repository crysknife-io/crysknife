/**
 * @fileoverview transpiled from elemental2.svg.SVGFECompositeElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFECompositeElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_ARITHMETIC__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ARITHMETIC__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_ARITHMETIC__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ARITHMETIC__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_ATOP__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ATOP__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_ATOP__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ATOP__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_IN__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_IN__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_IN__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_IN__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_OUT__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OUT__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_OUT__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OUT__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_OVER__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OVER__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_OVER__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OVER__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_UNKNOWN__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_UNKNOWN__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_UNKNOWN__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_UNKNOWN__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FECOMPOSITE_OPERATOR_XOR__elemental2_svg_SVGFECompositeElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_XOR__elemental2_svg_SVGFECompositeElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FECOMPOSITE_OPERATOR_XOR__elemental2_svg_SVGFECompositeElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_XOR__elemental2_svg_SVGFECompositeElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ARITHMETIC__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_ARITHMETIC;
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ATOP__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_ATOP;
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_IN__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_IN;
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OUT__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_OUT;
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OVER__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_OVER;
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_UNKNOWN__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_UNKNOWN;
    $Overlay.$f_SVG_FECOMPOSITE_OPERATOR_XOR__elemental2_svg_SVGFECompositeElement_$Overlay = SVGFECompositeElement.SVG_FECOMPOSITE_OPERATOR_XOR;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFECompositeElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFECompositeElement'));


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ARITHMETIC__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_ATOP__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_IN__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OUT__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_OVER__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_UNKNOWN__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FECOMPOSITE_OPERATOR_XOR__elemental2_svg_SVGFECompositeElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFECompositeElement$$Overlay.js.map