/**
 * @fileoverview transpiled from elemental2.svg.SVGFEDisplacementMapElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFEDisplacementMapElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_CHANNEL_A__elemental2_svg_SVGFEDisplacementMapElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_A__elemental2_svg_SVGFEDisplacementMapElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_CHANNEL_A__elemental2_svg_SVGFEDisplacementMapElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_A__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_CHANNEL_B__elemental2_svg_SVGFEDisplacementMapElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_B__elemental2_svg_SVGFEDisplacementMapElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_CHANNEL_B__elemental2_svg_SVGFEDisplacementMapElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_B__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_CHANNEL_G__elemental2_svg_SVGFEDisplacementMapElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_G__elemental2_svg_SVGFEDisplacementMapElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_CHANNEL_G__elemental2_svg_SVGFEDisplacementMapElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_G__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_CHANNEL_R__elemental2_svg_SVGFEDisplacementMapElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_R__elemental2_svg_SVGFEDisplacementMapElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_CHANNEL_R__elemental2_svg_SVGFEDisplacementMapElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_R__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_CHANNEL_UNKNOWN__elemental2_svg_SVGFEDisplacementMapElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_UNKNOWN__elemental2_svg_SVGFEDisplacementMapElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_CHANNEL_UNKNOWN__elemental2_svg_SVGFEDisplacementMapElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_CHANNEL_UNKNOWN__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_CHANNEL_A__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = SVGFEDisplacementMapElement.SVG_CHANNEL_A;
    $Overlay.$f_SVG_CHANNEL_B__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = SVGFEDisplacementMapElement.SVG_CHANNEL_B;
    $Overlay.$f_SVG_CHANNEL_G__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = SVGFEDisplacementMapElement.SVG_CHANNEL_G;
    $Overlay.$f_SVG_CHANNEL_R__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = SVGFEDisplacementMapElement.SVG_CHANNEL_R;
    $Overlay.$f_SVG_CHANNEL_UNKNOWN__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = SVGFEDisplacementMapElement.SVG_CHANNEL_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFEDisplacementMapElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFEDisplacementMapElement'));


/** @private {number} */
$Overlay.$f_SVG_CHANNEL_A__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_CHANNEL_B__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_CHANNEL_G__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_CHANNEL_R__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_CHANNEL_UNKNOWN__elemental2_svg_SVGFEDisplacementMapElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFEDisplacementMapElement$$Overlay.js.map