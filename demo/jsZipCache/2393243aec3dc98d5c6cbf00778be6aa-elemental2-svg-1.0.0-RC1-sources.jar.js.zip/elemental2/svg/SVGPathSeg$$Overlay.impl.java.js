/**
 * @fileoverview transpiled from elemental2.svg.SVGPathSeg$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGPathSeg.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_ARC_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_ARC_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_ARC_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_ARC_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_ARC_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_ARC_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_ARC_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_ARC_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CLOSEPATH__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CLOSEPATH__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CLOSEPATH__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CLOSEPATH__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_CUBIC_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_CUBIC_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_CUBIC_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_CUBIC_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_CUBIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_CUBIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_CUBIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_CUBIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_QUADRATIC_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_QUADRATIC_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_QUADRATIC_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_QUADRATIC_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_LINETO_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_LINETO_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_LINETO_HORIZONTAL_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_HORIZONTAL_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_LINETO_HORIZONTAL_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_HORIZONTAL_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_LINETO_HORIZONTAL_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_HORIZONTAL_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_LINETO_HORIZONTAL_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_HORIZONTAL_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_LINETO_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_LINETO_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_LINETO_VERTICAL_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_VERTICAL_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_LINETO_VERTICAL_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_VERTICAL_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_LINETO_VERTICAL_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_VERTICAL_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_LINETO_VERTICAL_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_LINETO_VERTICAL_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_MOVETO_ABS__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_MOVETO_ABS__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_MOVETO_ABS__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_MOVETO_ABS__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_MOVETO_REL__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_MOVETO_REL__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_MOVETO_REL__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_MOVETO_REL__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_PATHSEG_UNKNOWN__elemental2_svg_SVGPathSeg_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_PATHSEG_UNKNOWN__elemental2_svg_SVGPathSeg_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_PATHSEG_UNKNOWN__elemental2_svg_SVGPathSeg_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_PATHSEG_UNKNOWN__elemental2_svg_SVGPathSeg_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_PATHSEG_ARC_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_ARC_ABS;
    $Overlay.$f_PATHSEG_ARC_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_ARC_REL;
    $Overlay.$f_PATHSEG_CLOSEPATH__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CLOSEPATH;
    $Overlay.$f_PATHSEG_CURVETO_CUBIC_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_CUBIC_ABS;
    $Overlay.$f_PATHSEG_CURVETO_CUBIC_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_CUBIC_REL;
    $Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_ABS;
    $Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_CUBIC_SMOOTH_REL;
    $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_ABS;
    $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_REL;
    $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS;
    $Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL;
    $Overlay.$f_PATHSEG_LINETO_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_LINETO_ABS;
    $Overlay.$f_PATHSEG_LINETO_HORIZONTAL_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_ABS;
    $Overlay.$f_PATHSEG_LINETO_HORIZONTAL_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_LINETO_HORIZONTAL_REL;
    $Overlay.$f_PATHSEG_LINETO_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_LINETO_REL;
    $Overlay.$f_PATHSEG_LINETO_VERTICAL_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_LINETO_VERTICAL_ABS;
    $Overlay.$f_PATHSEG_LINETO_VERTICAL_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_LINETO_VERTICAL_REL;
    $Overlay.$f_PATHSEG_MOVETO_ABS__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_MOVETO_ABS;
    $Overlay.$f_PATHSEG_MOVETO_REL__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_MOVETO_REL;
    $Overlay.$f_PATHSEG_UNKNOWN__elemental2_svg_SVGPathSeg_$Overlay = SVGPathSeg.PATHSEG_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGPathSeg;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGPathSeg'));


/** @private {number} */
$Overlay.$f_PATHSEG_ARC_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_ARC_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CLOSEPATH__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_CUBIC_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_CUBIC_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_CUBIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_QUADRATIC_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_QUADRATIC_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_CURVETO_QUADRATIC_SMOOTH_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_LINETO_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_LINETO_HORIZONTAL_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_LINETO_HORIZONTAL_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_LINETO_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_LINETO_VERTICAL_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_LINETO_VERTICAL_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_MOVETO_ABS__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_MOVETO_REL__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_PATHSEG_UNKNOWN__elemental2_svg_SVGPathSeg_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGPathSeg$$Overlay.js.map