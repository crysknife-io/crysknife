/**
 * @fileoverview transpiled from elemental2.svg.SVGFEBlendElement$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.svg.SVGFEBlendElement.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FEBLEND_MODE_DARKEN__elemental2_svg_SVGFEBlendElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_DARKEN__elemental2_svg_SVGFEBlendElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FEBLEND_MODE_DARKEN__elemental2_svg_SVGFEBlendElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_DARKEN__elemental2_svg_SVGFEBlendElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FEBLEND_MODE_LIGHTEN__elemental2_svg_SVGFEBlendElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_LIGHTEN__elemental2_svg_SVGFEBlendElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FEBLEND_MODE_LIGHTEN__elemental2_svg_SVGFEBlendElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_LIGHTEN__elemental2_svg_SVGFEBlendElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FEBLEND_MODE_MULTIPLY__elemental2_svg_SVGFEBlendElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_MULTIPLY__elemental2_svg_SVGFEBlendElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FEBLEND_MODE_MULTIPLY__elemental2_svg_SVGFEBlendElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_MULTIPLY__elemental2_svg_SVGFEBlendElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FEBLEND_MODE_NORMAL__elemental2_svg_SVGFEBlendElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_NORMAL__elemental2_svg_SVGFEBlendElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FEBLEND_MODE_NORMAL__elemental2_svg_SVGFEBlendElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_NORMAL__elemental2_svg_SVGFEBlendElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FEBLEND_MODE_SCREEN__elemental2_svg_SVGFEBlendElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_SCREEN__elemental2_svg_SVGFEBlendElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FEBLEND_MODE_SCREEN__elemental2_svg_SVGFEBlendElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_SCREEN__elemental2_svg_SVGFEBlendElement_$Overlay = value);
  }
  
  /**
   * @return {number}
   * @public
   */
  static get f_SVG_FEBLEND_MODE_UNKNOWN__elemental2_svg_SVGFEBlendElement_$Overlay() {
    return ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_UNKNOWN__elemental2_svg_SVGFEBlendElement_$Overlay);
  }
  
  /**
   * @param {number} value
   * @return {void}
   * @public
   */
  static set f_SVG_FEBLEND_MODE_UNKNOWN__elemental2_svg_SVGFEBlendElement_$Overlay(value) {
    ($Overlay.$clinit(), $Overlay.$f_SVG_FEBLEND_MODE_UNKNOWN__elemental2_svg_SVGFEBlendElement_$Overlay = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
    $Overlay.$f_SVG_FEBLEND_MODE_DARKEN__elemental2_svg_SVGFEBlendElement_$Overlay = SVGFEBlendElement.SVG_FEBLEND_MODE_DARKEN;
    $Overlay.$f_SVG_FEBLEND_MODE_LIGHTEN__elemental2_svg_SVGFEBlendElement_$Overlay = SVGFEBlendElement.SVG_FEBLEND_MODE_LIGHTEN;
    $Overlay.$f_SVG_FEBLEND_MODE_MULTIPLY__elemental2_svg_SVGFEBlendElement_$Overlay = SVGFEBlendElement.SVG_FEBLEND_MODE_MULTIPLY;
    $Overlay.$f_SVG_FEBLEND_MODE_NORMAL__elemental2_svg_SVGFEBlendElement_$Overlay = SVGFEBlendElement.SVG_FEBLEND_MODE_NORMAL;
    $Overlay.$f_SVG_FEBLEND_MODE_SCREEN__elemental2_svg_SVGFEBlendElement_$Overlay = SVGFEBlendElement.SVG_FEBLEND_MODE_SCREEN;
    $Overlay.$f_SVG_FEBLEND_MODE_UNKNOWN__elemental2_svg_SVGFEBlendElement_$Overlay = SVGFEBlendElement.SVG_FEBLEND_MODE_UNKNOWN;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SVGFEBlendElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('SVGFEBlendElement'));


/** @private {number} */
$Overlay.$f_SVG_FEBLEND_MODE_DARKEN__elemental2_svg_SVGFEBlendElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FEBLEND_MODE_LIGHTEN__elemental2_svg_SVGFEBlendElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FEBLEND_MODE_MULTIPLY__elemental2_svg_SVGFEBlendElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FEBLEND_MODE_NORMAL__elemental2_svg_SVGFEBlendElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FEBLEND_MODE_SCREEN__elemental2_svg_SVGFEBlendElement_$Overlay = 0.0;


/** @private {number} */
$Overlay.$f_SVG_FEBLEND_MODE_UNKNOWN__elemental2_svg_SVGFEBlendElement_$Overlay = 0.0;


exports = $Overlay; 
//# sourceMappingURL=SVGFEBlendElement$$Overlay.js.map