package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "SVGPreserveAspectRatio", namespace = JsPackage.GLOBAL)
class SVGPreserveAspectRatio__Constants {
  static double SVG_MEETORSLICE_MEET;
  static double SVG_MEETORSLICE_SLICE;
  static double SVG_MEETORSLICE_UNKNOWN;
  static double SVG_PRESERVEASPECTRATIO_NONE;
  static double SVG_PRESERVEASPECTRATIO_UNKNOWN;
  static double SVG_PRESERVEASPECTRATIO_XMAXYMAX;
  static double SVG_PRESERVEASPECTRATIO_XMAXYMID;
  static double SVG_PRESERVEASPECTRATIO_XMAXYMIN;
  static double SVG_PRESERVEASPECTRATIO_XMIDYMAX;
  static double SVG_PRESERVEASPECTRATIO_XMIDYMID;
  static double SVG_PRESERVEASPECTRATIO_XMIDYMIN;
  static double SVG_PRESERVEASPECTRATIO_XMINYMAX;
  static double SVG_PRESERVEASPECTRATIO_XMINYMID;
  static double SVG_PRESERVEASPECTRATIO_XMINYMIN;
}
