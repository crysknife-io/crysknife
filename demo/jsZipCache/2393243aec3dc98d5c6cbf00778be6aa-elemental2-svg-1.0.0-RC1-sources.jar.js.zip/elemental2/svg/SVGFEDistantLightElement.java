package elemental2.svg;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, namespace = JsPackage.GLOBAL)
public class SVGFEDistantLightElement extends SVGElement {
  public SVGAnimatedNumber azimuth;
  public SVGAnimatedNumber elevation;
}
