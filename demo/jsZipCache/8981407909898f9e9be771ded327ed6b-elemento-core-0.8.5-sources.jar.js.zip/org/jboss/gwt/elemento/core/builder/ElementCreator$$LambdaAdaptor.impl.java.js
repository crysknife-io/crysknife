/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementCreator$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementCreator.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const ElementCreator = goog.require('org.jboss.gwt.elemento.core.builder.ElementCreator$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');


/**
 * @template M_E
 * @implements {ElementCreator}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(?string, Class<M_E>):M_E} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(?string, Class<M_E>):M_E} */
    this.f_$$fn__org_jboss_gwt_elemento_core_builder_ElementCreator_$LambdaAdaptor;
    this.$ctor__org_jboss_gwt_elemento_core_builder_ElementCreator_$LambdaAdaptor__org_jboss_gwt_elemento_core_builder_ElementCreator_$JsFunction(fn);
  }
  
  /**
   * @param {?function(?string, Class<M_E>):M_E} fn
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_builder_ElementCreator_$LambdaAdaptor__org_jboss_gwt_elemento_core_builder_ElementCreator_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_jboss_gwt_elemento_core_builder_ElementCreator_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {?string} arg0
   * @param {Class<M_E>} arg1
   * @return {M_E}
   * @public
   */
  m_create__java_lang_String__java_lang_Class(arg0, arg1) {
    let /** ?function(?string, Class<M_E>):M_E */ $function;
    return ($function = this.f_$$fn__org_jboss_gwt_elemento_core_builder_ElementCreator_$LambdaAdaptor, $function(arg0, arg1));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.ElementCreator$$LambdaAdaptor'));


ElementCreator.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=ElementCreator$$LambdaAdaptor.js.map