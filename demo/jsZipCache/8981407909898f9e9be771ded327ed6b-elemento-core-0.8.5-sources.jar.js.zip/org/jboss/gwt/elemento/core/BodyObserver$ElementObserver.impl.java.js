/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.BodyObserver$ElementObserver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.BodyObserver.ElementObserver$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let ObserverCallback = goog.forwardDeclare('org.jboss.gwt.elemento.core.ObserverCallback$impl');


/**
 * @interface
 */
class ElementObserver {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_attachId__() {
  }
  
  /**
   * @abstract
   * @return {HTMLElement}
   * @public
   */
  m_observedElement__() {
  }
  
  /**
   * @abstract
   * @return {ObserverCallback}
   * @public
   */
  m_callback__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ElementObserver.$clinit = (() =>{
    });
    ElementObserver.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_BodyObserver_ElementObserver = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_BodyObserver_ElementObserver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_BodyObserver_ElementObserver;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(ElementObserver, $Util.$makeClassName('org.jboss.gwt.elemento.core.BodyObserver$ElementObserver'));


ElementObserver.$markImplementor(/** @type {Function} */ (ElementObserver));


exports = ElementObserver; 
//# sourceMappingURL=BodyObserver$ElementObserver.js.map