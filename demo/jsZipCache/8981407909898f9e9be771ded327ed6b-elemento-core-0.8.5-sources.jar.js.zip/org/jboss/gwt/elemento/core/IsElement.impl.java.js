/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.IsElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.IsElement$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_E
 */
class IsElement {
  /**
   * @abstract
   * @return {C_E}
   * @public
   */
  m_asElement__() {
  }
  
  /**
   * @template C_E
   * @param {?function():C_E} fn
   * @return {IsElement<C_E>}
   * @public
   */
  static $adapt(fn) {
    IsElement.$clinit();
    return /**@type {!$LambdaAdaptor<HTMLElement>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    IsElement.$clinit = (() =>{
    });
    IsElement.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_IsElement = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_IsElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_IsElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.jboss.gwt.elemento.core.IsElement.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(IsElement, $Util.$makeClassName('org.jboss.gwt.elemento.core.IsElement'));


IsElement.$markImplementor(/** @type {Function} */ (IsElement));


exports = IsElement; 
//# sourceMappingURL=IsElement.js.map