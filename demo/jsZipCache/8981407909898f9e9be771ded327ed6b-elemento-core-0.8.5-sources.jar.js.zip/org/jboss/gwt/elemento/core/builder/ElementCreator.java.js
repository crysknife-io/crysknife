/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementCreator.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementCreator');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Class = goog.require('java.lang.Class');
const _$LambdaAdaptor = goog.require('org.jboss.gwt.elemento.core.builder.ElementCreator.$LambdaAdaptor');


// Re-exports the implementation.
var ElementCreator = goog.require('org.jboss.gwt.elemento.core.builder.ElementCreator$impl');
exports = ElementCreator;
 