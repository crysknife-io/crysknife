/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.ElementsBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.ElementsBuilder$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HasElements = goog.require('org.jboss.gwt.elemento.core.HasElements$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @implements {HasElements}
  */
class ElementsBuilder extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<HTMLElement>} */
    this.f_elements__org_jboss_gwt_elemento_core_builder_ElementsBuilder_;
  }
  
  /**
   * @return {!ElementsBuilder}
   * @public
   */
  static $create__() {
    ElementsBuilder.$clinit();
    let $instance = new ElementsBuilder();
    $instance.$ctor__org_jboss_gwt_elemento_core_builder_ElementsBuilder__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_builder_ElementsBuilder__() {
    this.$ctor__java_lang_Object__();
    this.f_elements__org_jboss_gwt_elemento_core_builder_ElementsBuilder_ = /**@type {!ArrayList<HTMLElement>} */ (ArrayList.$create__());
  }
  
  /**
   * @param {IsElement} element
   * @return {ElementsBuilder}
   * @public
   */
  m_add__org_jboss_gwt_elemento_core_IsElement(element) {
    return this.m_add__elemental2_dom_HTMLElement(element.m_asElement__());
  }
  
  /**
   * @param {HTMLElement} element
   * @return {ElementsBuilder}
   * @public
   */
  m_add__elemental2_dom_HTMLElement(element) {
    this.f_elements__org_jboss_gwt_elemento_core_builder_ElementsBuilder_.add(element);
    return this;
  }
  
  /**
   * @param {HasElements} elements
   * @return {ElementsBuilder}
   * @public
   */
  m_addAll__org_jboss_gwt_elemento_core_HasElements(elements) {
    return this.m_addAll__java_lang_Iterable(elements.m_asElements__());
  }
  
  /**
   * @param {Array<HTMLElement>} elements
   * @return {ElementsBuilder}
   * @public
   */
  m_addAll__arrayOf_elemental2_dom_HTMLElement(elements) {
    for (let $array = elements, $index = 0; $index < $array.length; $index++) {
      let element = $array[$index];
      this.m_add__elemental2_dom_HTMLElement(element);
    }
    return this;
  }
  
  /**
   * @param {Iterable<HTMLElement>} elements
   * @return {ElementsBuilder}
   * @public
   */
  m_addAll__java_lang_Iterable(elements) {
    for (let $iterator = elements.m_iterator__(); $iterator.m_hasNext__(); ) {
      let element = /**@type {HTMLElement} */ ($Casts.$to($iterator.m_next__(), $Overlay));
      this.m_add__elemental2_dom_HTMLElement(element);
    }
    return this;
  }
  
  /**
   * @param {Array<IsElement>} elements
   * @return {ElementsBuilder}
   * @public
   */
  m_addAll__arrayOf_org_jboss_gwt_elemento_core_IsElement(elements) {
    for (let $array = elements, $index = 0; $index < $array.length; $index++) {
      let element = $array[$index];
      this.m_add__org_jboss_gwt_elemento_core_IsElement(element);
    }
    return this;
  }
  
  /**
   * @override
   * @return {Iterable<HTMLElement>}
   * @public
   */
  m_asElements__() {
    return this.f_elements__org_jboss_gwt_elemento_core_builder_ElementsBuilder_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ElementsBuilder.$clinit = (() =>{
    });
    ElementsBuilder.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ElementsBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ElementsBuilder);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLElement.$Overlay$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ElementsBuilder, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.ElementsBuilder'));


HasElements.$markImplementor(ElementsBuilder);


exports = ElementsBuilder; 
//# sourceMappingURL=ElementsBuilder.js.map