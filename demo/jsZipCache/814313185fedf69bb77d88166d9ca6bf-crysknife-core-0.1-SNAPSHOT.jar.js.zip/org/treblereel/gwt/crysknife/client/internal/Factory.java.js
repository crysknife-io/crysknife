/**
 * @fileoverview transpiled from org.treblereel.gwt.crysknife.client.internal.Factory.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.treblereel.gwt.crysknife.client.internal.Factory');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Provider = goog.require('javax.inject.Provider');
const _$Util = goog.require('nativebootstrap.Util');
const _$LambdaAdaptor = goog.require('org.treblereel.gwt.crysknife.client.internal.Factory.$LambdaAdaptor');


// Re-exports the implementation.
var Factory = goog.require('org.treblereel.gwt.crysknife.client.internal.Factory$impl');
exports = Factory;
 