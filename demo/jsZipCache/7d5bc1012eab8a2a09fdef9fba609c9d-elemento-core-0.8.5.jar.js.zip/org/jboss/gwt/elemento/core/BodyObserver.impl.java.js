/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.BodyObserver.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.BodyObserver$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let MutationObserver_$Overlay = goog.forwardDeclare('elemental2.dom.MutationObserver.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.MutationObserverInit.$Overlay$impl');
let MutationRecord_$Overlay = goog.forwardDeclare('elemental2.dom.MutationRecord.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let JsArrayLike_$Overlay = goog.forwardDeclare('jsinterop.base.JsArrayLike.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $1 = goog.forwardDeclare('org.jboss.gwt.elemento.core.BodyObserver.$1$impl');
let ElementObserver = goog.forwardDeclare('org.jboss.gwt.elemento.core.BodyObserver.ElementObserver$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let ObserverCallback = goog.forwardDeclare('org.jboss.gwt.elemento.core.ObserverCallback$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class BodyObserver extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {void}
   * @public
   */
  static m_startObserving___$p_org_jboss_gwt_elemento_core_BodyObserver() {
    BodyObserver.$clinit();
    let mutationObserver = new MutationObserver(((/** Array<MutationRecord> */ records, /** MutationObserver */ observer) =>{
      for (let $array = records, $index = 0; $index < $array.length; $index++) {
        let record = $array[$index];
        BodyObserver.m_onElementsRemoved__elemental2_dom_MutationRecord_$p_org_jboss_gwt_elemento_core_BodyObserver(record);
        BodyObserver.m_onElementsAppended__elemental2_dom_MutationRecord_$p_org_jboss_gwt_elemento_core_BodyObserver(record);
      }
      return null;
    }));
    let mutationObserverInit = $Overlay.m_create__();
    mutationObserverInit.childList = true;
    mutationObserverInit.subtree = true;
    mutationObserver.observe(DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.body, mutationObserverInit);
    BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_ = true;
  }
  
  /**
   * @param {MutationRecord} record
   * @return {void}
   * @public
   */
  static m_onElementsAppended__elemental2_dom_MutationRecord_$p_org_jboss_gwt_elemento_core_BodyObserver(record) {
    BodyObserver.$clinit();
    let observed = /**@type {!ArrayList<ElementObserver>} */ (ArrayList.$create__());
    for (let $iterator = BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let elementObserver = /**@type {ElementObserver} */ ($Casts.$to($iterator.m_next__(), ElementObserver));
      if ($Equality.$same(elementObserver.m_observedElement__(), null)) {
        observed.add(elementObserver);
      } else {
        if (/**@type {List<Node>} */ (JsArrayLike_$Overlay.m_asList__jsinterop_base_JsArrayLike(record.addedNodes)).contains(elementObserver.m_observedElement__()) || BodyObserver.m_isChildOfAddedNode__elemental2_dom_MutationRecord__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(record, elementObserver.m_attachId__())) {
          elementObserver.m_callback__().m_onObserved__elemental2_dom_MutationRecord(record);
          elementObserver.m_observedElement__().removeAttribute(BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_);
          observed.add(elementObserver);
        }
      }
    }
    BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_.removeAll(observed);
  }
  
  /**
   * @param {MutationRecord} record
   * @param {?string} attachId
   * @return {boolean}
   * @public
   */
  static m_isChildOfAddedNode__elemental2_dom_MutationRecord__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(record, attachId) {
    BodyObserver.$clinit();
    let nodes = /**@type {List<Node>} */ (JsArrayLike_$Overlay.m_asList__jsinterop_base_JsArrayLike(record.addedNodes));
    return BodyObserver.m_isChildOfObservedNode__java_lang_String__java_util_List__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(attachId, nodes, BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {MutationRecord} record
   * @return {void}
   * @public
   */
  static m_onElementsRemoved__elemental2_dom_MutationRecord_$p_org_jboss_gwt_elemento_core_BodyObserver(record) {
    BodyObserver.$clinit();
    let observed = /**@type {!ArrayList<ElementObserver>} */ (ArrayList.$create__());
    for (let $iterator = BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_.m_iterator__(); $iterator.m_hasNext__(); ) {
      let elementObserver = /**@type {ElementObserver} */ ($Casts.$to($iterator.m_next__(), ElementObserver));
      if ($Equality.$same(elementObserver.m_observedElement__(), null)) {
        observed.add(elementObserver);
      } else {
        if (/**@type {List<Node>} */ (JsArrayLike_$Overlay.m_asList__jsinterop_base_JsArrayLike(record.removedNodes)).contains(elementObserver.m_observedElement__()) || BodyObserver.m_isChildOfRemovedNode__elemental2_dom_MutationRecord__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(record, elementObserver.m_attachId__())) {
          elementObserver.m_callback__().m_onObserved__elemental2_dom_MutationRecord(record);
          elementObserver.m_observedElement__().removeAttribute(BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_);
          observed.add(elementObserver);
        }
      }
    }
    BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_.removeAll(observed);
  }
  
  /**
   * @param {MutationRecord} record
   * @param {?string} detachId
   * @return {boolean}
   * @public
   */
  static m_isChildOfRemovedNode__elemental2_dom_MutationRecord__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(record, detachId) {
    BodyObserver.$clinit();
    let nodes = /**@type {List<Node>} */ (JsArrayLike_$Overlay.m_asList__jsinterop_base_JsArrayLike(record.removedNodes));
    return BodyObserver.m_isChildOfObservedNode__java_lang_String__java_util_List__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(detachId, nodes, BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {?string} attachId
   * @param {List<Node>} nodes
   * @param {?string} attachUidKey
   * @return {boolean}
   * @public
   */
  static m_isChildOfObservedNode__java_lang_String__java_util_List__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(attachId, nodes, attachUidKey) {
    BodyObserver.$clinit();
    for (let $iterator = nodes.m_iterator__(); $iterator.m_hasNext__(); ) {
      let node = /**@type {Node} */ ($Casts.$to($iterator.m_next__(), Node_$Overlay));
      let elementNode = /**@type {Node} */ (Js.m_uncheckedCast__java_lang_Object(node));
      if (Node.ELEMENT_NODE == elementNode.nodeType) {
        if (!$Equality.$same(elementNode.querySelector("[" + j_l_String.m_valueOf__java_lang_Object(attachUidKey) + "='" + j_l_String.m_valueOf__java_lang_Object(attachId) + "']"), null)) {
          return true;
        }
      }
    }
    return false;
  }
  
  /**
   * @param {HTMLElement} element
   * @param {ObserverCallback} callback
   * @return {void}
   * @public
   */
  static m_addAttachObserver__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback_$pp_org_jboss_gwt_elemento_core(element, callback) {
    BodyObserver.$clinit();
    if (!BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_) {
      BodyObserver.m_startObserving___$p_org_jboss_gwt_elemento_core_BodyObserver();
    }
    BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_.add(BodyObserver.m_createObserver__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(element, callback, BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_));
  }
  
  /**
   * @param {HTMLElement} element
   * @param {ObserverCallback} callback
   * @return {void}
   * @public
   */
  static m_addDetachObserver__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback_$pp_org_jboss_gwt_elemento_core(element, callback) {
    BodyObserver.$clinit();
    if (!BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_) {
      BodyObserver.m_startObserving___$p_org_jboss_gwt_elemento_core_BodyObserver();
    }
    BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_.add(BodyObserver.m_createObserver__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(element, callback, BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_));
  }
  
  /**
   * @param {HTMLElement} element
   * @param {ObserverCallback} callback
   * @param {?string} idAttributeName
   * @return {ElementObserver}
   * @public
   */
  static m_createObserver__elemental2_dom_HTMLElement__org_jboss_gwt_elemento_core_ObserverCallback__java_lang_String_$p_org_jboss_gwt_elemento_core_BodyObserver(element, callback, idAttributeName) {
    BodyObserver.$clinit();
    let elementId = element.getAttribute(idAttributeName);
    if ($Equality.$same(elementId, null)) {
      Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(element, idAttributeName, Elements.m_createDocumentUniqueId__());
    }
    return $1.$create__elemental2_dom_HTMLElement__java_lang_String__org_jboss_gwt_elemento_core_ObserverCallback(element, idAttributeName, callback);
  }
  
  /**
   * @return {!BodyObserver}
   * @public
   */
  static $create__() {
    BodyObserver.$clinit();
    let $instance = new BodyObserver();
    $instance.$ctor__org_jboss_gwt_elemento_core_BodyObserver__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_BodyObserver__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  static get f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_() {
    return (BodyObserver.$clinit(), BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  static set f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_(value) {
    (BodyObserver.$clinit(), BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_ = value);
  }
  
  /**
   * @return {?string}
   * @public
   */
  static get f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_() {
    return (BodyObserver.$clinit(), BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  static set f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_(value) {
    (BodyObserver.$clinit(), BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_ = value);
  }
  
  /**
   * @return {List<ElementObserver>}
   * @public
   */
  static get f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_() {
    return (BodyObserver.$clinit(), BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {List<ElementObserver>} value
   * @return {void}
   * @public
   */
  static set f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_(value) {
    (BodyObserver.$clinit(), BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_ = value);
  }
  
  /**
   * @return {List<ElementObserver>}
   * @public
   */
  static get f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_() {
    return (BodyObserver.$clinit(), BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {List<ElementObserver>} value
   * @return {void}
   * @public
   */
  static set f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_(value) {
    (BodyObserver.$clinit(), BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_ = value);
  }
  
  /**
   * @return {boolean}
   * @public
   */
  static get f_ready__org_jboss_gwt_elemento_core_BodyObserver_() {
    return (BodyObserver.$clinit(), BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_);
  }
  
  /**
   * @param {boolean} value
   * @return {void}
   * @public
   */
  static set f_ready__org_jboss_gwt_elemento_core_BodyObserver_(value) {
    (BodyObserver.$clinit(), BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    BodyObserver.$clinit = (() =>{
    });
    BodyObserver.$loadModules();
    j_l_Object.$clinit();
    BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_ = "on-attach-uid";
    BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_ = "on-detach-uid";
    BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_ = /**@type {!ArrayList<ElementObserver>} */ (ArrayList.$create__());
    BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_ = /**@type {!ArrayList<ElementObserver>} */ (ArrayList.$create__());
    BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_ = false;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BodyObserver;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BodyObserver);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.MutationObserverInit.$Overlay$impl');
    Node_$Overlay = goog.module.get('elemental2.dom.Node.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    JsArrayLike_$Overlay = goog.module.get('jsinterop.base.JsArrayLike.$Overlay$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $1 = goog.module.get('org.jboss.gwt.elemento.core.BodyObserver.$1$impl');
    ElementObserver = goog.module.get('org.jboss.gwt.elemento.core.BodyObserver.ElementObserver$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(BodyObserver, $Util.$makeClassName('org.jboss.gwt.elemento.core.BodyObserver'));


/** @private {?string} */
BodyObserver.$f_ATTACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_;


/** @private {?string} */
BodyObserver.$f_DETACH_UID_KEY__org_jboss_gwt_elemento_core_BodyObserver_;


/** @private {List<ElementObserver>} */
BodyObserver.$f_detachObservers__org_jboss_gwt_elemento_core_BodyObserver_;


/** @private {List<ElementObserver>} */
BodyObserver.$f_attachObservers__org_jboss_gwt_elemento_core_BodyObserver_;


/** @private {boolean} */
BodyObserver.$f_ready__org_jboss_gwt_elemento_core_BodyObserver_ = false;




exports = BodyObserver; 
//# sourceMappingURL=BodyObserver.js.map