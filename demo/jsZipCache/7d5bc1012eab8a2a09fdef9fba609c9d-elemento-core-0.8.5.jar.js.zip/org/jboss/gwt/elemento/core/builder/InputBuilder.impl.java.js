/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.builder.InputBuilder.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.builder.InputBuilder$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const ElementBuilder = goog.require('org.jboss.gwt.elemento.core.builder.ElementBuilder$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_E
 * @extends {ElementBuilder<C_E, InputBuilder<C_E>>}
  */
class InputBuilder extends ElementBuilder {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_E
   * @param {C_E} element
   * @return {!InputBuilder<C_E>}
   * @public
   */
  static $create__elemental2_dom_HTMLInputElement(element) {
    InputBuilder.$clinit();
    let $instance = new InputBuilder();
    $instance.$ctor__org_jboss_gwt_elemento_core_builder_InputBuilder__elemental2_dom_HTMLInputElement(element);
    return $instance;
  }
  
  /**
   * @param {C_E} element
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_core_builder_InputBuilder__elemental2_dom_HTMLInputElement(element) {
    this.$ctor__org_jboss_gwt_elemento_core_builder_ElementBuilder__elemental2_dom_HTMLElement(element);
  }
  
  /**
   * @override
   * @return {InputBuilder<C_E>}
   * @public
   */
  m_that__() {
    return this;
  }
  
  /**
   * @param {boolean} checked
   * @return {InputBuilder<C_E>}
   * @public
   */
  m_checked__boolean(checked) {
    /**@type {HTMLInputElement} */ ($Casts.$to(this.m_get__(), $Overlay)).checked = checked;
    return this.m_that__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    InputBuilder.$clinit = (() =>{
    });
    InputBuilder.$loadModules();
    ElementBuilder.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof InputBuilder;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, InputBuilder);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(InputBuilder, $Util.$makeClassName('org.jboss.gwt.elemento.core.builder.InputBuilder'));




exports = InputBuilder; 
//# sourceMappingURL=InputBuilder.js.map