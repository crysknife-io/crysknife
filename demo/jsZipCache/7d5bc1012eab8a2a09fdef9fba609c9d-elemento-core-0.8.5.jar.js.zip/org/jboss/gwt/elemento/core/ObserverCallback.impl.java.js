/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.ObserverCallback.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.ObserverCallback$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.MutationRecord.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.jboss.gwt.elemento.core.ObserverCallback.$LambdaAdaptor$impl');


/**
 * @interface
 */
class ObserverCallback {
  /**
   * @abstract
   * @param {MutationRecord} mutationRecord
   * @return {void}
   * @public
   */
  m_onObserved__elemental2_dom_MutationRecord(mutationRecord) {
  }
  
  /**
   * @param {?function(MutationRecord):void} fn
   * @return {ObserverCallback}
   * @public
   */
  static $adapt(fn) {
    ObserverCallback.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ObserverCallback.$clinit = (() =>{
    });
    ObserverCallback.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_ObserverCallback = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_ObserverCallback;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_ObserverCallback;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.jboss.gwt.elemento.core.ObserverCallback.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(ObserverCallback, $Util.$makeClassName('org.jboss.gwt.elemento.core.ObserverCallback'));


ObserverCallback.$markImplementor(/** @type {Function} */ (ObserverCallback));


exports = ObserverCallback; 
//# sourceMappingURL=ObserverCallback.js.map