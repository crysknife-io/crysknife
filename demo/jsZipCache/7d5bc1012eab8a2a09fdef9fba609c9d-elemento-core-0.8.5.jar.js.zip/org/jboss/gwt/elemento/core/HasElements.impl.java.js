/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.core.HasElements.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.core.HasElements$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Iterable = goog.forwardDeclare('java.lang.Iterable$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.jboss.gwt.elemento.core.HasElements.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HasElements {
  /**
   * @abstract
   * @return {Iterable<HTMLElement>}
   * @public
   */
  m_asElements__() {
  }
  
  /**
   * @param {?function():Iterable<HTMLElement>} fn
   * @return {HasElements}
   * @public
   */
  static $adapt(fn) {
    HasElements.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HasElements.$clinit = (() =>{
    });
    HasElements.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_HasElements = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_core_HasElements;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_core_HasElements;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.jboss.gwt.elemento.core.HasElements.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HasElements, $Util.$makeClassName('org.jboss.gwt.elemento.core.HasElements'));


HasElements.$markImplementor(/** @type {Function} */ (HasElements));


exports = HasElements; 
//# sourceMappingURL=HasElements.js.map