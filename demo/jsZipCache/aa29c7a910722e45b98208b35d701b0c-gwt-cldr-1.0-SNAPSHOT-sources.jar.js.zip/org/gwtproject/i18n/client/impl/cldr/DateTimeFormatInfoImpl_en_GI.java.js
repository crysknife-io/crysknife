/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_GI.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_GI');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__en__150 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_150');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__en__GI = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en_GI$impl');
exports = DateTimeFormatInfoImpl__en__GI;
 