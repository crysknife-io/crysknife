/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_el_CY.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_el_CY');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__el = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_el');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__el__CY = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_el_CY$impl');
exports = DateTimeFormatInfoImpl__el__CY;
 