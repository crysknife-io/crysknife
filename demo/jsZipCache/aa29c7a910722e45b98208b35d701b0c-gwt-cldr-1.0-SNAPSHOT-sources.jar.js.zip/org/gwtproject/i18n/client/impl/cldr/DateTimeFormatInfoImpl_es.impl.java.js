/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


class DateTimeFormatInfoImpl__es extends DateTimeFormatInfoImpl {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!DateTimeFormatInfoImpl__es}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__es.$clinit();
    let $instance = new DateTimeFormatInfoImpl__es();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_es__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_es__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_ampms__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["a. m.", "p. m."], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatFull__() {
    return "EEEE, d 'de' MMMM 'de' y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatLong__() {
    return "d 'de' MMMM 'de' y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatMedium__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatShort__() {
    return "d/M/yy";
  }
  
  /**
   * @override
   * @param {?string} timePattern
   * @param {?string} datePattern
   * @return {?string}
   * @public
   */
  m_dateTimeFull__java_lang_String__java_lang_String(timePattern, datePattern) {
    return j_l_String.m_valueOf__java_lang_Object(datePattern) + ", " + j_l_String.m_valueOf__java_lang_Object(timePattern);
  }
  
  /**
   * @override
   * @param {?string} timePattern
   * @param {?string} datePattern
   * @return {?string}
   * @public
   */
  m_dateTimeLong__java_lang_String__java_lang_String(timePattern, datePattern) {
    return j_l_String.m_valueOf__java_lang_Object(datePattern) + ", " + j_l_String.m_valueOf__java_lang_Object(timePattern);
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["antes de Cristo", "despu\u00E9s de Cristo"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["a. C.", "d. C."], j_l_String));
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 0;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatHour24Minute__() {
    return "H:mm";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatHour24MinuteSecond__() {
    return "H:mm:ss";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthAbbrevDay__() {
    return "d MMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullDay__() {
    return "d 'de' MMMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullWeekdayDay__() {
    return "EEEE, d 'de' MMMM";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthNumDay__() {
    return "d/M";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrev__() {
    return "MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrevDay__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFull__() {
    return "MMMM 'de' y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFullDay__() {
    return "d 'de' MMMM 'de' y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNum__() {
    return "M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNumDay__() {
    return "d/M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthWeekdayDay__() {
    return "EEE, d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterFull__() {
    return "QQQQ 'de' y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterShort__() {
    return "Q y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["E", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["ene.", "feb.", "mar.", "abr.", "may.", "jun.", "jul.", "ago.", "sept.", "oct.", "nov.", "dic."], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["1.er trimestre", "2.\u00BA trimestre", "3.er trimestre", "4.\u00BA trimestre"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["T1", "T2", "T3", "T4"], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatFull__() {
    return "H:mm:ss (zzzz)";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatLong__() {
    return "H:mm:ss z";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatMedium__() {
    return "H:mm:ss";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatShort__() {
    return "H:mm";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["domingo", "lunes", "martes", "mi\u00E9rcoles", "jueves", "viernes", "s\u00E1bado"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["D", "L", "M", "X", "J", "V", "S"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["dom.", "lun.", "mar.", "mi\u00E9.", "jue.", "vie.", "s\u00E1b."], j_l_String));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__es.$clinit = (() =>{
    });
    DateTimeFormatInfoImpl__es.$loadModules();
    DateTimeFormatInfoImpl.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__es;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__es);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__es, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es'));




exports = DateTimeFormatInfoImpl__es; 
//# sourceMappingURL=DateTimeFormatInfoImpl_es.js.map