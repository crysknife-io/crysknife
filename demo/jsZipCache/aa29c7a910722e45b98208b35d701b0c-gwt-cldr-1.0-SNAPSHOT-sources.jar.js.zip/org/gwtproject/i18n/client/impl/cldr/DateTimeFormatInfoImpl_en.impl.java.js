/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');


class DateTimeFormatInfoImpl__en extends DateTimeFormatInfoImpl {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!DateTimeFormatInfoImpl__en}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__en.$clinit();
    let $instance = new DateTimeFormatInfoImpl__en();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_en__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatFull__() {
    return "EEEE, MMMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatLong__() {
    return "MMMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatMedium__() {
    return "MMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatShort__() {
    return "M/d/yy";
  }
  
  /**
   * @override
   * @param {?string} timePattern
   * @param {?string} datePattern
   * @return {?string}
   * @public
   */
  m_dateTimeFull__java_lang_String__java_lang_String(timePattern, datePattern) {
    return j_l_String.m_valueOf__java_lang_Object(datePattern) + " 'at' " + j_l_String.m_valueOf__java_lang_Object(timePattern);
  }
  
  /**
   * @override
   * @param {?string} timePattern
   * @param {?string} datePattern
   * @return {?string}
   * @public
   */
  m_dateTimeLong__java_lang_String__java_lang_String(timePattern, datePattern) {
    return j_l_String.m_valueOf__java_lang_Object(datePattern) + " 'at' " + j_l_String.m_valueOf__java_lang_Object(timePattern);
  }
  
  /**
   * @override
   * @param {?string} timePattern
   * @param {?string} datePattern
   * @return {?string}
   * @public
   */
  m_dateTimeMedium__java_lang_String__java_lang_String(timePattern, datePattern) {
    return j_l_String.m_valueOf__java_lang_Object(datePattern) + ", " + j_l_String.m_valueOf__java_lang_Object(timePattern);
  }
  
  /**
   * @override
   * @param {?string} timePattern
   * @param {?string} datePattern
   * @return {?string}
   * @public
   */
  m_dateTimeShort__java_lang_String__java_lang_String(timePattern, datePattern) {
    return j_l_String.m_valueOf__java_lang_Object(datePattern) + ", " + j_l_String.m_valueOf__java_lang_Object(timePattern);
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 0;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullWeekdayDay__() {
    return "EEEE, MMMM d";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthNumDay__() {
    return "M/d";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrev__() {
    return "MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrevDay__() {
    return "MMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFull__() {
    return "MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFullDay__() {
    return "MMMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNum__() {
    return "M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNumDay__() {
    return "M/d/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthWeekdayDay__() {
    return "EEE, MMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterFull__() {
    return "QQQQ y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterShort__() {
    return "Q y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatFull__() {
    return "h:mm:ss a zzzz";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatLong__() {
    return "h:mm:ss a z";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatMedium__() {
    return "h:mm:ss a";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_timeFormatShort__() {
    return "h:mm a";
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__en.$clinit = (() =>{
    });
    DateTimeFormatInfoImpl__en.$loadModules();
    DateTimeFormatInfoImpl.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__en;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__en);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__en, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_en'));




exports = DateTimeFormatInfoImpl__en; 
//# sourceMappingURL=DateTimeFormatInfoImpl_en.js.map