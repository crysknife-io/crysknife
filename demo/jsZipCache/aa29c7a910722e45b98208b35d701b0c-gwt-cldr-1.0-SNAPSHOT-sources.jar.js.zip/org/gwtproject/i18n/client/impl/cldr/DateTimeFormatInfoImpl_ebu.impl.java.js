/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ebu.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ebu$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


class DateTimeFormatInfoImpl__ebu extends DateTimeFormatInfoImpl {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!DateTimeFormatInfoImpl__ebu}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__ebu.$clinit();
    let $instance = new DateTimeFormatInfoImpl__ebu();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ebu__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_ebu__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl__();
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_ampms__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["KI", "UT"], j_l_String));
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatFull__() {
    return "EEEE, d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatLong__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatMedium__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_dateFormatShort__() {
    return "dd/MM/y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Mbere ya Kristo", "Thutha wa Kristo"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_erasShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["MK", "TK"], j_l_String));
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  m_firstDayOfTheWeek__() {
    return 0;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthFullWeekdayDay__() {
    return "EEEE, MMMM d";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatMonthNumDay__() {
    return "M/d";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrev__() {
    return "MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthAbbrevDay__() {
    return "d MMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFull__() {
    return "MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthFullDay__() {
    return "d MMMM y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNum__() {
    return "M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthNumDay__() {
    return "d/M/y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearMonthWeekdayDay__() {
    return "EEE, MMM d, y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterFull__() {
    return "QQQQ y";
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_formatYearQuarterShort__() {
    return "Q y";
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Mweri wa mbere", "Mweri wa ka\u0129ri", "Mweri wa kathat\u0169", "Mweri wa kana", "Mweri wa gatano", "Mweri wa gatantat\u0169", "Mweri wa m\u0169gwanja", "Mweri wa kanana", "Mweri wa kenda", "Mweri wa ik\u0169mi", "Mweri wa ik\u0169mi na \u0169mwe", "Mweri wa ik\u0169mi na Ka\u0129r\u0129"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["M", "K", "K", "K", "G", "G", "M", "K", "K", "I", "I", "I"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_monthsShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Mbe", "Kai", "Kat", "Kan", "Gat", "Gan", "Mug", "Knn", "Ken", "Iku", "Imw", "Igi"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Kuota ya mbere", "Kuota ya Ka\u0129r\u0129", "Kuota ya kathatu", "Kuota ya kana"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_quartersShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["K1", "K2", "K3", "K4"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysFull__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Kiumia", "Njumatatu", "Njumaine", "Njumatano", "Aramithi", "Njumaa", "NJumamothii"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysNarrow__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["K", "N", "N", "N", "A", "M", "N"], j_l_String));
  }
  
  /**
   * @override
   * @return {Array<?string>}
   * @public
   */
  m_weekdaysShort__() {
    return /**@type {!Array<?string>} */ ($Arrays.$init(["Kma", "Tat", "Ine", "Tan", "Arm", "Maa", "NMM"], j_l_String));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__ebu.$clinit = (() =>{
    });
    DateTimeFormatInfoImpl__ebu.$loadModules();
    DateTimeFormatInfoImpl.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__ebu;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__ebu);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__ebu, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ebu'));




exports = DateTimeFormatInfoImpl__ebu; 
//# sourceMappingURL=DateTimeFormatInfoImpl_ebu.js.map