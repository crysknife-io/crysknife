/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es_BR.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es_BR');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__es__419 = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es_419');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__es__BR = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_es_BR$impl');
exports = DateTimeFormatInfoImpl__es__BR;
 