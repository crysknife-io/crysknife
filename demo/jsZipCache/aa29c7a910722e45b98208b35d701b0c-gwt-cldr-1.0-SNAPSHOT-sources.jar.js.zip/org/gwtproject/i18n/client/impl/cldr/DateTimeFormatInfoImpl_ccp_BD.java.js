/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp_BD.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp_BD');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__ccp = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__ccp__BD = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_ccp_BD$impl');
exports = DateTimeFormatInfoImpl__ccp__BD;
 