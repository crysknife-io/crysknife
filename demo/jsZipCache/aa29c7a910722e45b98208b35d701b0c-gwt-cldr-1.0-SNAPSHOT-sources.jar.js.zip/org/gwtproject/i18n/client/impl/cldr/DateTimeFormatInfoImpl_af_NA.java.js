/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af_NA.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af_NA');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _DateTimeFormatInfoImpl__af = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af');


// Re-exports the implementation.
var DateTimeFormatInfoImpl__af__NA = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_af_NA$impl');
exports = DateTimeFormatInfoImpl__af__NA;
 