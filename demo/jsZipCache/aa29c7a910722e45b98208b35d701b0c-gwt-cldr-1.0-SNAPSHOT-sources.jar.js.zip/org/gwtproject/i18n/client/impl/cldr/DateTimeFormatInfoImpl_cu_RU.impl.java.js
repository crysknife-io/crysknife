/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu_RU.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu_RU$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormatInfoImpl__cu = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu$impl');


class DateTimeFormatInfoImpl__cu__RU extends DateTimeFormatInfoImpl__cu {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @return {!DateTimeFormatInfoImpl__cu__RU}
   * @public
   */
  static $create__() {
    DateTimeFormatInfoImpl__cu__RU.$clinit();
    let $instance = new DateTimeFormatInfoImpl__cu__RU();
    $instance.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_cu_RU__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_cu_RU__() {
    this.$ctor__org_gwtproject_i18n_client_impl_cldr_DateTimeFormatInfoImpl_cu__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DateTimeFormatInfoImpl__cu__RU.$clinit = (() =>{
    });
    DateTimeFormatInfoImpl__cu__RU.$loadModules();
    DateTimeFormatInfoImpl__cu.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DateTimeFormatInfoImpl__cu__RU;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DateTimeFormatInfoImpl__cu__RU);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(DateTimeFormatInfoImpl__cu__RU, $Util.$makeClassName('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfoImpl_cu_RU'));




exports = DateTimeFormatInfoImpl__cu__RU; 
//# sourceMappingURL=DateTimeFormatInfoImpl_cu_RU.js.map