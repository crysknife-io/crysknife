/**
 * @fileoverview transpiled from org.gwtproject.i18n.client.DefaultLocalizedNamesBase.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.gwtproject.i18n.client.DefaultLocalizedNamesBase');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _LocalizedNames = goog.require('org.gwtproject.i18n.client.LocalizedNames');
const _j_l_String = goog.require('java.lang.String');
const _HashMap = goog.require('java.util.HashMap');
const _Map = goog.require('java.util.Map');
const _$Equality = goog.require('nativebootstrap.Equality');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DefaultLocalizedNamesBase = goog.require('org.gwtproject.i18n.client.DefaultLocalizedNamesBase$impl');
exports = DefaultLocalizedNamesBase;
 