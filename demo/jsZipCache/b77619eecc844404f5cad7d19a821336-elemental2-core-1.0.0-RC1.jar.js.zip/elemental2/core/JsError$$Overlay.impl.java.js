/**
 * @fileoverview transpiled from elemental2.core.JsError$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsError.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let Function_$Overlay = goog.forwardDeclare('elemental2.core.Function.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.core.JsObject.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class JsError_$Overlay {
  /**
   * @param {*} error
   * @param {Function} constructor
   * @return {void}
   * @public
   */
  static m_captureStackTrace__java_lang_Object__elemental2_core_Function(error, constructor) {
    JsError_$Overlay.$clinit();
    Error.captureStackTrace(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(error)), constructor);
  }
  
  /**
   * @param {*} error
   * @return {void}
   * @public
   */
  static m_captureStackTrace__java_lang_Object(error) {
    JsError_$Overlay.$clinit();
    Error.captureStackTrace(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(error)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JsError_$Overlay.$clinit = (() =>{
    });
    JsError_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Error;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JsError_$Overlay, $Util.$makeClassName('Error'));


exports = JsError_$Overlay; 
//# sourceMappingURL=JsError$$Overlay.js.map