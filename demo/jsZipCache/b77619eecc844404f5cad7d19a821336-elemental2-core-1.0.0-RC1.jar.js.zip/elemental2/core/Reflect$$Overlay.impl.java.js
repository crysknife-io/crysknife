/**
 * @fileoverview transpiled from elemental2.core.Reflect$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Reflect.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let JsObject_$Overlay = goog.forwardDeclare('elemental2.core.JsObject.$Overlay$impl');
let ObjectPropertyDescriptor_$Overlay = goog.forwardDeclare('elemental2.core.ObjectPropertyDescriptor.$Overlay$impl');
let Class = goog.forwardDeclare('java.lang.Class$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsConstructorFn.$Overlay$impl');


class Reflect_$Overlay {
  /**
   * @template M_TARGET
   * @param {Class<?>} targetConstructorFn
   * @param {Array<*>} argList
   * @param {Class<?>} newTargetConstructorFn
   * @return {M_TARGET}
   * @public
   */
  static m_construct__java_lang_Class__arrayOf_java_lang_Object__java_lang_Class(targetConstructorFn, argList, newTargetConstructorFn) {
    Reflect_$Overlay.$clinit();
    return Reflect.construct(/**@type {?function(...*):void} */ (Js.m_asConstructorFn__java_lang_Class(targetConstructorFn)), argList, /**@type {?function(...*):void} */ (Js.m_asConstructorFn__java_lang_Class(newTargetConstructorFn)));
  }
  
  /**
   * @template M_TARGET
   * @param {Class<?>} targetConstructorFn
   * @param {Array<*>} argList
   * @return {M_TARGET}
   * @public
   */
  static m_construct__java_lang_Class__arrayOf_java_lang_Object(targetConstructorFn, argList) {
    Reflect_$Overlay.$clinit();
    return Reflect.construct(/**@type {?function(...*):void} */ (Js.m_asConstructorFn__java_lang_Class(targetConstructorFn)), argList);
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @param {ObjectPropertyDescriptor} attributes
   * @return {boolean}
   * @public
   */
  static m_defineProperty__java_lang_Object__java_lang_String__elemental2_core_ObjectPropertyDescriptor(target, propertyKey, attributes) {
    Reflect_$Overlay.$clinit();
    return Reflect.defineProperty(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey, attributes);
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @return {boolean}
   * @public
   */
  static m_deleteProperty__java_lang_Object__java_lang_String(target, propertyKey) {
    Reflect_$Overlay.$clinit();
    return Reflect.deleteProperty(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey);
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @param {*} receiver
   * @return {*}
   * @public
   */
  static m_get__java_lang_Object__java_lang_String__java_lang_Object(target, propertyKey, receiver) {
    Reflect_$Overlay.$clinit();
    return Reflect.get(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(receiver)));
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @return {*}
   * @public
   */
  static m_get__java_lang_Object__java_lang_String(target, propertyKey) {
    Reflect_$Overlay.$clinit();
    return Reflect.get(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey);
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @return {ObjectPropertyDescriptor}
   * @public
   */
  static m_getOwnPropertyDescriptor__java_lang_Object__java_lang_String(target, propertyKey) {
    Reflect_$Overlay.$clinit();
    return Reflect.getOwnPropertyDescriptor(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey);
  }
  
  /**
   * @param {*} target
   * @return {Object}
   * @public
   */
  static m_getPrototypeOf__java_lang_Object(target) {
    Reflect_$Overlay.$clinit();
    return Reflect.getPrototypeOf(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)));
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @return {boolean}
   * @public
   */
  static m_has__java_lang_Object__java_lang_String(target, propertyKey) {
    Reflect_$Overlay.$clinit();
    return Reflect.has(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey);
  }
  
  /**
   * @param {*} target
   * @return {boolean}
   * @public
   */
  static m_isExtensible__java_lang_Object(target) {
    Reflect_$Overlay.$clinit();
    return Reflect.isExtensible(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)));
  }
  
  /**
   * @param {*} target
   * @return {Array<*>}
   * @public
   */
  static m_ownKeys__java_lang_Object(target) {
    Reflect_$Overlay.$clinit();
    return Reflect.ownKeys(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)));
  }
  
  /**
   * @param {*} target
   * @return {boolean}
   * @public
   */
  static m_preventExtensions__java_lang_Object(target) {
    Reflect_$Overlay.$clinit();
    return Reflect.preventExtensions(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)));
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @param {*} value
   * @param {*} receiver
   * @return {boolean}
   * @public
   */
  static m_set__java_lang_Object__java_lang_String__java_lang_Object__java_lang_Object(target, propertyKey, value, receiver) {
    Reflect_$Overlay.$clinit();
    return Reflect.set(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey, value, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(receiver)));
  }
  
  /**
   * @param {*} target
   * @param {?string} propertyKey
   * @param {*} value
   * @return {boolean}
   * @public
   */
  static m_set__java_lang_Object__java_lang_String__java_lang_Object(target, propertyKey, value) {
    Reflect_$Overlay.$clinit();
    return Reflect.set(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), propertyKey, value);
  }
  
  /**
   * @param {*} target
   * @param {*} proto
   * @return {boolean}
   * @public
   */
  static m_setPrototypeOf__java_lang_Object__java_lang_Object(target, proto) {
    Reflect_$Overlay.$clinit();
    return Reflect.setPrototypeOf(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(proto)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Reflect_$Overlay.$clinit = (() =>{
    });
    Reflect_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Reflect;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(Reflect_$Overlay, $Util.$makeClassName('Reflect'));


exports = Reflect_$Overlay; 
//# sourceMappingURL=Reflect$$Overlay.js.map