/**
 * @fileoverview transpiled from elemental2.core.JsSet$ConstructorIterableUnionType$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.JsSet.ConstructorIterableUnionType.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.JsIterable.$Overlay');
const _j_l_Object = goog.require('java.lang.Object');
const _Js = goog.require('jsinterop.base.Js');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var ConstructorIterableUnionType_$Overlay = goog.require('elemental2.core.JsSet.ConstructorIterableUnionType.$Overlay$impl');
exports = ConstructorIterableUnionType_$Overlay;
 