/**
 * @fileoverview transpiled from elemental2.core.Function$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.Function.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.core.JsObject.$Overlay$impl');
let $InternalPreconditions = goog.forwardDeclare('javaemul.internal.InternalPreconditions$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');


class Function_$Overlay {
  /**
   * @param {Function} $thisArg
   * @param {*} selfObj
   * @param {Array<*>} var_args
   * @return {Function}
   * @public
   */
  static m_bind__elemental2_core_Function__java_lang_Object__arrayOf_java_lang_Object($thisArg, selfObj, var_args) {
    Function_$Overlay.$clinit();
    return $thisArg.bind(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(selfObj)), ...$InternalPreconditions.m_checkNotNull__java_lang_Object(var_args));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Function_$Overlay.$clinit = (() =>{
    });
    Function_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Function;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $InternalPreconditions = goog.module.get('javaemul.internal.InternalPreconditions$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(Function_$Overlay, $Util.$makeClassName('Function'));


exports = Function_$Overlay; 
//# sourceMappingURL=Function$$Overlay.js.map