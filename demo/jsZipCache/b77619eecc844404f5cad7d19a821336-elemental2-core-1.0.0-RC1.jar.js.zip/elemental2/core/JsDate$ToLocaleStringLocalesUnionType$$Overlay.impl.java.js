/**
 * @fileoverview transpiled from elemental2.core.JsDate$ToLocaleStringLocalesUnionType$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsDate.ToLocaleStringLocalesUnionType.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_Object = goog.forwardDeclare('java.lang.Object$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class $Overlay {
  /**
   * @param {*} o
   * @return {?}
   * @public
   */
  static m_of__java_lang_Object(o) {
    $Overlay.$clinit();
    return /**@type {?} */ ($Casts.$to(Js.m_cast__java_lang_Object(o), $Overlay));
  }
  
  /**
   * @param {?} $thisArg
   * @return {?string}
   * @public
   */
  static m_asString__elemental2_core_JsDate_ToLocaleStringLocalesUnionType($thisArg) {
    $Overlay.$clinit();
    return Js.m_asString__java_lang_Object($thisArg);
  }
  
  /**
   * @param {?} $thisArg
   * @return {Array<?string>}
   * @public
   */
  static m_asStringArray__elemental2_core_JsDate_ToLocaleStringLocalesUnionType($thisArg) {
    $Overlay.$clinit();
    return /**@type {Array<?string>} */ ($Arrays.$castTo(Js.m_cast__java_lang_Object($thisArg), j_l_String, 1));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isString__elemental2_core_JsDate_ToLocaleStringLocalesUnionType($thisArg) {
    $Overlay.$clinit();
    return j_l_String.$isInstance(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)));
  }
  
  /**
   * @param {?} $thisArg
   * @return {boolean}
   * @public
   */
  static m_isStringArray__elemental2_core_JsDate_ToLocaleStringLocalesUnionType($thisArg) {
    $Overlay.$clinit();
    return $Arrays.$instanceIsOfType(/**@type {*} */ ($Casts.$to($thisArg, j_l_Object)), j_l_Object, 1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return true;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_Object = goog.module.get('java.lang.Object$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Js = goog.module.get('jsinterop.base.Js$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};



exports = $Overlay; 
//# sourceMappingURL=JsDate$ToLocaleStringLocalesUnionType$$Overlay.js.map