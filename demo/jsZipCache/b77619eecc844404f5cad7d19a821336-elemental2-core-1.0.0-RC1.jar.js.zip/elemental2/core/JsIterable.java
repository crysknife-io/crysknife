package elemental2.core;

import jsinterop.annotations.JsPackage;
import jsinterop.annotations.JsType;

@JsType(isNative = true, name = "Iterable", namespace = JsPackage.GLOBAL)
public interface JsIterable<VALUE> {}
