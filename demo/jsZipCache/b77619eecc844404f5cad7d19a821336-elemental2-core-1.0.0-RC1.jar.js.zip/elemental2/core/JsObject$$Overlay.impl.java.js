/**
 * @fileoverview transpiled from elemental2.core.JsObject$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.JsObject.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let ObjectPropertyDescriptor_$Overlay = goog.forwardDeclare('elemental2.core.ObjectPropertyDescriptor.$Overlay$impl');
let Js = goog.forwardDeclare('jsinterop.base.Js$impl');
let $Overlay = goog.forwardDeclare('jsinterop.base.JsPropertyMap.$Overlay$impl');


class JsObject_$Overlay {
  /**
   * @param {*} target
   * @param {Array<*>} var_args
   * @return {Object}
   * @public
   */
  static m_assign__java_lang_Object__arrayOf_java_lang_Object(target, var_args) {
    JsObject_$Overlay.$clinit();
    return Object.assign(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(target)), /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(var_args)));
  }
  
  /**
   * @param {*} proto
   * @param {*} properties
   * @return {Object}
   * @public
   */
  static m_create__java_lang_Object__java_lang_Object(proto, properties) {
    JsObject_$Overlay.$clinit();
    return Object.create(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(proto)), /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(properties)));
  }
  
  /**
   * @param {*} proto
   * @return {Object}
   * @public
   */
  static m_create__java_lang_Object(proto) {
    JsObject_$Overlay.$clinit();
    return Object.create(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(proto)));
  }
  
  /**
   * @param {*} obj
   * @param {*} props
   * @return {Object}
   * @public
   */
  static m_defineProperties__java_lang_Object__java_lang_Object(obj, props) {
    JsObject_$Overlay.$clinit();
    return Object.defineProperties(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)), /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(props)));
  }
  
  /**
   * @param {*} obj
   * @param {?string} prop
   * @param {*} descriptor
   * @return {Object}
   * @public
   */
  static m_defineProperty__java_lang_Object__java_lang_String__java_lang_Object(obj, prop, descriptor) {
    JsObject_$Overlay.$clinit();
    return Object.defineProperty(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)), prop, /**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(descriptor)));
  }
  
  /**
   * @param {*} obj
   * @return {Object<string, ObjectPropertyDescriptor>}
   * @public
   */
  static m_getOwnPropertyDescriptors__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.getOwnPropertyDescriptors(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {Array<?string>}
   * @public
   */
  static m_getOwnPropertyNames__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.getOwnPropertyNames(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {Array<*>}
   * @public
   */
  static m_getOwnPropertySymbols__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.getOwnPropertySymbols(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {Object}
   * @public
   */
  static m_getPrototypeOf__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.getPrototypeOf(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {boolean}
   * @public
   */
  static m_isExtensible__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.isExtensible(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {boolean}
   * @public
   */
  static m_isFrozen__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.isFrozen(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {boolean}
   * @public
   */
  static m_isSealed__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.isSealed(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @return {Array<?string>}
   * @public
   */
  static m_keys__java_lang_Object(obj) {
    JsObject_$Overlay.$clinit();
    return Object.keys(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)));
  }
  
  /**
   * @param {*} obj
   * @param {*} proto
   * @return {Object}
   * @public
   */
  static m_setPrototypeOf__java_lang_Object__java_lang_Object(obj, proto) {
    JsObject_$Overlay.$clinit();
    return Object.setPrototypeOf(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(obj)), proto);
  }
  
  /**
   * @param {Object} $thisArg
   * @param {*} other
   * @return {boolean}
   * @public
   */
  static m_isPrototypeOf__elemental2_core_JsObject__java_lang_Object($thisArg, other) {
    JsObject_$Overlay.$clinit();
    return $thisArg.isPrototypeOf(/**@type {Object} */ (Js.m_uncheckedCast__java_lang_Object(other)));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    JsObject_$Overlay.$clinit = (() =>{
    });
    JsObject_$Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Object;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Js = goog.module.get('jsinterop.base.Js$impl');
  }
  
  
};

$Util.$setClassMetadata(JsObject_$Overlay, $Util.$makeClassName('Object'));


exports = JsObject_$Overlay; 
//# sourceMappingURL=JsObject$$Overlay.js.map