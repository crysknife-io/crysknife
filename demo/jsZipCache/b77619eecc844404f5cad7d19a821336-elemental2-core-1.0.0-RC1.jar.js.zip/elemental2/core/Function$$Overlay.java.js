/**
 * @fileoverview transpiled from elemental2.core.Function$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.Function.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.core.JsObject.$Overlay');
const _$InternalPreconditions = goog.require('javaemul.internal.InternalPreconditions');
const _Js = goog.require('jsinterop.base.Js');


// Re-exports the implementation.
var Function_$Overlay = goog.require('elemental2.core.Function.$Overlay$impl');
exports = Function_$Overlay;
 