/**
 * @fileoverview transpiled from elemental2.core.Reflect$$Overlay.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('elemental2.core.Reflect.$Overlay');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _JsObject_$Overlay = goog.require('elemental2.core.JsObject.$Overlay');
const _ObjectPropertyDescriptor_$Overlay = goog.require('elemental2.core.ObjectPropertyDescriptor.$Overlay');
const _Class = goog.require('java.lang.Class');
const _Js = goog.require('jsinterop.base.Js');
const _$Overlay = goog.require('jsinterop.base.JsConstructorFn.$Overlay');


// Re-exports the implementation.
var Reflect_$Overlay = goog.require('elemental2.core.Reflect.$Overlay$impl');
exports = Reflect_$Overlay;
 