/**
 * @fileoverview transpiled from elemental2.core.ReferenceError$$Overlay.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('elemental2.core.ReferenceError.$Overlay$impl');


const $Util = goog.require('nativebootstrap.Util$impl');


class $Overlay {
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $Overlay.$clinit = (() =>{
    });
    $Overlay.$loadModules();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ReferenceError;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($Overlay, $Util.$makeClassName('ReferenceError'));


exports = $Overlay; 
//# sourceMappingURL=ReferenceError$$Overlay.js.map