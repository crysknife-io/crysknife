/**
 * @fileoverview transpiled from org.treblereel.gwt.crysknife.client.internal.Factory$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.treblereel.gwt.crysknife.client.internal.Factory.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _Factory = goog.require('org.treblereel.gwt.crysknife.client.internal.Factory');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.treblereel.gwt.crysknife.client.internal.Factory.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 