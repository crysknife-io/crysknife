/**
 * @fileoverview transpiled from org.dominokit.samples.Project.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.Project$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');


class Project extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_name__org_dominokit_samples_Project_;
    /** @public {?string} */
    this.f_icon__org_dominokit_samples_Project_;
    /** @public {?string} */
    this.f_color__org_dominokit_samples_Project_;
  }
  
  /**
   * @return {!Project}
   * @public
   */
  static $create__() {
    Project.$clinit();
    let $instance = new Project();
    $instance.$ctor__org_dominokit_samples_Project__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_Project__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_samples_Project_;
  }
  
  /**
   * @param {?string} name
   * @return {void}
   * @public
   */
  m_setName__java_lang_String(name) {
    this.f_name__org_dominokit_samples_Project_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getIcon__() {
    return this.f_icon__org_dominokit_samples_Project_;
  }
  
  /**
   * @param {?string} icon
   * @return {void}
   * @public
   */
  m_setIcon__java_lang_String(icon) {
    this.f_icon__org_dominokit_samples_Project_ = icon;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getColor__() {
    return this.f_color__org_dominokit_samples_Project_;
  }
  
  /**
   * @param {?string} color
   * @return {void}
   * @public
   */
  m_setColor__java_lang_String(color) {
    this.f_color__org_dominokit_samples_Project_ = color;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Project.$clinit = (() =>{
    });
    Project.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Project;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Project);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(Project, $Util.$makeClassName('org.dominokit.samples.Project'));




exports = Project; 
//# sourceMappingURL=Project.js.map