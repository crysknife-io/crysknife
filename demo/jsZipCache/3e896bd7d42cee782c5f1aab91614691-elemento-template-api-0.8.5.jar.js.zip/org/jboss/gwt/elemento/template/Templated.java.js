/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.Templated.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.template.Templated');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _Annotation = goog.require('java.lang.annotation.Annotation');
const _$Util = goog.require('nativebootstrap.Util');
const _Injectable = goog.require('org.jboss.gwt.elemento.template.Templated.Injectable');


// Re-exports the implementation.
var Templated = goog.require('org.jboss.gwt.elemento.template.Templated$impl');
exports = Templated;
 