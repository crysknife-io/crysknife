/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.Templated.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.template.Templated$impl');


const Annotation = goog.require('java.lang.annotation.Annotation$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let Injectable = goog.forwardDeclare('org.jboss.gwt.elemento.template.Templated.Injectable$impl');


/**
 * @interface
 * @extends {Annotation}
 */
class Templated {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_value__() {
  }
  
  /**
   * @abstract
   * @return {Injectable}
   * @public
   */
  m_injectable__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Templated.$clinit = (() =>{
    });
    Templated.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    Annotation.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_template_Templated = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_template_Templated;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_template_Templated;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(Templated, $Util.$makeClassName('org.jboss.gwt.elemento.template.Templated'));


Templated.$markImplementor(/** @type {Function} */ (Templated));


exports = Templated; 
//# sourceMappingURL=Templated.js.map