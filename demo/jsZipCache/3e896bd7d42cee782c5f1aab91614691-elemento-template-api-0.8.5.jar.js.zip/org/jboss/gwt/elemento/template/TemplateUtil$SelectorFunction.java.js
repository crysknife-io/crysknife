/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.TemplateUtil$SelectorFunction.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _$Overlay = goog.require('elemental2.dom.Element.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$LambdaAdaptor = goog.require('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction.$LambdaAdaptor');


// Re-exports the implementation.
var SelectorFunction = goog.require('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction$impl');
exports = SelectorFunction;
 