/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.TemplateUtil$SelectorFunction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction.$LambdaAdaptor$impl');


/**
 * @interface
 */
class SelectorFunction {
  /**
   * @abstract
   * @param {HTMLElement} context
   * @param {?string} identifier
   * @return {Element}
   * @public
   */
  m_select__elemental2_dom_HTMLElement__java_lang_String(context, identifier) {
  }
  
  /**
   * @param {?function(HTMLElement, ?string):Element} fn
   * @return {SelectorFunction}
   * @public
   */
  static $adapt(fn) {
    SelectorFunction.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SelectorFunction.$clinit = (() =>{
    });
    SelectorFunction.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(SelectorFunction, $Util.$makeClassName('org.jboss.gwt.elemento.template.TemplateUtil$SelectorFunction'));


SelectorFunction.$markImplementor(/** @type {Function} */ (SelectorFunction));


exports = SelectorFunction; 
//# sourceMappingURL=TemplateUtil$SelectorFunction.js.map