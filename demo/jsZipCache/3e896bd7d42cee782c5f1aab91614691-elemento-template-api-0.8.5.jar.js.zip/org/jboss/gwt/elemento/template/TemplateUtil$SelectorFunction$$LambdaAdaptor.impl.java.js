/**
 * @fileoverview transpiled from org.jboss.gwt.elemento.template.TemplateUtil$SelectorFunction$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const SelectorFunction = goog.require('org.jboss.gwt.elemento.template.TemplateUtil.SelectorFunction$impl');

let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


/**
 * @implements {SelectorFunction}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(HTMLElement, ?string):Element} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(HTMLElement, ?string):Element} */
    this.f_$$fn__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$LambdaAdaptor;
    this.$ctor__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$LambdaAdaptor__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$JsFunction(fn);
  }
  
  /**
   * @param {?function(HTMLElement, ?string):Element} fn
   * @return {void}
   * @public
   */
  $ctor__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$LambdaAdaptor__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {HTMLElement} arg0
   * @param {?string} arg1
   * @return {Element}
   * @public
   */
  m_select__elemental2_dom_HTMLElement__java_lang_String(arg0, arg1) {
    let /** ?function(HTMLElement, ?string):Element */ $function;
    return ($function = this.f_$$fn__org_jboss_gwt_elemento_template_TemplateUtil_SelectorFunction_$LambdaAdaptor, $function(arg0, arg1));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.jboss.gwt.elemento.template.TemplateUtil$SelectorFunction$$LambdaAdaptor'));


SelectorFunction.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=TemplateUtil$SelectorFunction$$LambdaAdaptor.js.map