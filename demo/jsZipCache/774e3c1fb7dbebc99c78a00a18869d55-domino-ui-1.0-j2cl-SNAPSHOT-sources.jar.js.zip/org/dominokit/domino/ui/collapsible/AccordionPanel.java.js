/**
 * @fileoverview transpiled from org.dominokit.domino.ui.collapsible.AccordionPanel.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.collapsible.AccordionPanel');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _IsCollapsible = goog.require('org.dominokit.domino.ui.utils.IsCollapsible');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLHeadingElement_$Overlay = goog.require('elemental2.dom.HTMLHeadingElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var AccordionPanel = goog.require('org.dominokit.domino.ui.collapsible.AccordionPanel$impl');
exports = AccordionPanel;
 