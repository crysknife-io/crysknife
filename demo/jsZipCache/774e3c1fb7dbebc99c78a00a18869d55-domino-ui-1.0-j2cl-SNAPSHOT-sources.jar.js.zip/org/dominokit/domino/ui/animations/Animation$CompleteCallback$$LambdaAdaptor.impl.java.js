/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Animation$CompleteCallback$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.animations.Animation.CompleteCallback.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CompleteCallback = goog.require('org.dominokit.domino.ui.animations.Animation.CompleteCallback$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');


/**
 * @implements {CompleteCallback}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(HTMLElement):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(HTMLElement):void} */
    this.f_$$fn__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$LambdaAdaptor__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$JsFunction(fn);
  }
  
  /**
   * @param {?function(HTMLElement):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$LambdaAdaptor__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {HTMLElement} arg0
   * @return {void}
   * @public
   */
  m_onComplete__elemental2_dom_HTMLElement(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_animations_Animation_CompleteCallback_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.animations.Animation$CompleteCallback$$LambdaAdaptor'));


CompleteCallback.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Animation$CompleteCallback$$LambdaAdaptor.js.map