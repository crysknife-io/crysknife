/**
 * @fileoverview transpiled from org.dominokit.domino.ui.animations.Transition.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.animations.Transition$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Transition>}
  */
class Transition extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_animations_Transition_;
    /** @public {?string} */
    this.f_name__org_dominokit_domino_ui_animations_Transition_;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @param {?string} name
   * @return {!Transition}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String__java_lang_String($name, $ordinal, style, name) {
    let $instance = new Transition();
    $instance.$ctor__org_dominokit_domino_ui_animations_Transition__java_lang_String__int__java_lang_String__java_lang_String($name, $ordinal, style, name);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @param {?string} name
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_animations_Transition__java_lang_String__int__java_lang_String__java_lang_String($name, $ordinal, style, name) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_animations_Transition_ = style;
    this.f_name__org_dominokit_domino_ui_animations_Transition_ = name;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_animations_Transition_;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getName__() {
    return this.f_name__org_dominokit_domino_ui_animations_Transition_;
  }
  
  /**
   * @param {string} name
   * @return {!Transition}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Transition.$clinit();
    if ($Equality.$same(Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_, null)) {
      Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_ = $Enums.createMapFromValues(Transition.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_);
  }
  
  /**
   * @return {!Array<!Transition>}
   * @public
   */
  static m_values__() {
    Transition.$clinit();
    return /**@type {!Array<Transition>} */ ($Arrays.$init([Transition.$f_BOUNCE__org_dominokit_domino_ui_animations_Transition, Transition.$f_FLASH__org_dominokit_domino_ui_animations_Transition, Transition.$f_PULSE__org_dominokit_domino_ui_animations_Transition, Transition.$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition, Transition.$f_SHAKE__org_dominokit_domino_ui_animations_Transition, Transition.$f_SWING__org_dominokit_domino_ui_animations_Transition, Transition.$f_TADA__org_dominokit_domino_ui_animations_Transition, Transition.$f_WOBBLE__org_dominokit_domino_ui_animations_Transition, Transition.$f_JELLO__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition, Transition.$f_FLIP__org_dominokit_domino_ui_animations_Transition, Transition.$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition, Transition.$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition, Transition.$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition, Transition.$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition, Transition.$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition, Transition.$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, Transition.$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition, Transition.$f_HINGE__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition, Transition.$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition, Transition.$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition], Transition));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Transition} */ ($Casts.$to(arg0, Transition)));
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FLASH__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FLASH__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FLASH__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FLASH__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_PULSE__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_PULSE__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_PULSE__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_PULSE__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SHAKE__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SHAKE__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SHAKE__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SHAKE__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SWING__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SWING__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SWING__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SWING__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_TADA__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_TADA__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_TADA__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_TADA__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_WOBBLE__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_WOBBLE__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_WOBBLE__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_WOBBLE__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_JELLO__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_JELLO__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_JELLO__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_JELLO__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FLIP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FLIP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FLIP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FLIP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_HINGE__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_HINGE__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_HINGE__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_HINGE__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROLL_IN__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROLL_IN__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {!Transition}
   * @public
   */
  static get f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition() {
    return (Transition.$clinit(), Transition.$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition);
  }
  
  /**
   * @param {!Transition} value
   * @return {void}
   * @public
   */
  static set f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition(value) {
    (Transition.$clinit(), Transition.$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition = value);
  }
  
  /**
   * @return {Map<?string, !Transition>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_() {
    return (Transition.$clinit(), Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_);
  }
  
  /**
   * @param {Map<?string, !Transition>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_(value) {
    (Transition.$clinit(), Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Transition.$clinit = (() =>{
    });
    Transition.$loadModules();
    Enum.$clinit();
    Transition.$f_BOUNCE__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE"), Transition.$ordinal$f_BOUNCE__org_dominokit_domino_ui_animations_Transition, "bounce", "BOUNCE");
    Transition.$f_FLASH__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FLASH"), Transition.$ordinal$f_FLASH__org_dominokit_domino_ui_animations_Transition, "flash", "FLASH");
    Transition.$f_PULSE__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("PULSE"), Transition.$ordinal$f_PULSE__org_dominokit_domino_ui_animations_Transition, "pulse", "PULSE");
    Transition.$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("RUBBER_BAND"), Transition.$ordinal$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition, "rubberBand", "RUBBER BAND");
    Transition.$f_SHAKE__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SHAKE"), Transition.$ordinal$f_SHAKE__org_dominokit_domino_ui_animations_Transition, "shake", "SHAKE");
    Transition.$f_SWING__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SWING"), Transition.$ordinal$f_SWING__org_dominokit_domino_ui_animations_Transition, "swing", "SWING");
    Transition.$f_TADA__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("TADA"), Transition.$ordinal$f_TADA__org_dominokit_domino_ui_animations_Transition, "tada", "TADA");
    Transition.$f_WOBBLE__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("WOBBLE"), Transition.$ordinal$f_WOBBLE__org_dominokit_domino_ui_animations_Transition, "wobble", "WOBBLE");
    Transition.$f_JELLO__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("JELLO"), Transition.$ordinal$f_JELLO__org_dominokit_domino_ui_animations_Transition, "jello", "JELLO");
    Transition.$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_IN"), Transition.$ordinal$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition, "bounceIn", "BOUNCE IN");
    Transition.$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_IN_DOWN"), Transition.$ordinal$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition, "bounceInDown", "BOUNCE IN DOWN");
    Transition.$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_IN_LEFT"), Transition.$ordinal$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition, "bounceInLeft", "BOUNCE IN LEFT");
    Transition.$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_IN_RIGHT"), Transition.$ordinal$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, "bounceInRight", "BOUNCE IN RIGHT");
    Transition.$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_IN_UP"), Transition.$ordinal$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition, "bounceInUp", "BOUNCE IN UP");
    Transition.$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_OUT"), Transition.$ordinal$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition, "bounceOut", "BOUNCE OUT");
    Transition.$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_OUT_DOWN"), Transition.$ordinal$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, "bounceOutDown", "BOUNCE OUT DOWN");
    Transition.$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_OUT_LEFT"), Transition.$ordinal$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, "bounceOutLeft", "BOUNCE OUT LEFT");
    Transition.$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_OUT_RIGHT"), Transition.$ordinal$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, "bounceOutRight", "BOUNCE OUT RIGHT");
    Transition.$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("BOUNCE_OUT_UP"), Transition.$ordinal$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition, "bounceOutUp", "BOUNCE OUT UP");
    Transition.$f_FADE_IN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN"), Transition.$ordinal$f_FADE_IN__org_dominokit_domino_ui_animations_Transition, "fadeIn", "FADE IN");
    Transition.$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_DOWN"), Transition.$ordinal$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition, "fadeInDown", "FADE IN DOWN");
    Transition.$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_DOWN_BIG"), Transition.$ordinal$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition, "fadeInDownBig", "FADE IN DOWN BIG");
    Transition.$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_LEFT"), Transition.$ordinal$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition, "fadeInLeft", "FADE IN LEFT");
    Transition.$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_LEFT_BIG"), Transition.$ordinal$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition, "fadeInLeftBig", "FADE IN LEFT BIG");
    Transition.$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_RIGHT"), Transition.$ordinal$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, "fadeInRight", "FADE IN RIGHT");
    Transition.$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_RIGHT_BIG"), Transition.$ordinal$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition, "fadeInRightBig", "FADE IN RIGHT BIG");
    Transition.$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_UP"), Transition.$ordinal$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition, "fadeInUp", "FADE IN UP");
    Transition.$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_IN_UP_BIG"), Transition.$ordinal$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition, "fadeInUpBig", "FADE IN UP BIG");
    Transition.$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT"), Transition.$ordinal$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition, "fadeOut", "FADE OUT");
    Transition.$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_DOWN"), Transition.$ordinal$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, "fadeOutDown", "FADE OUT DOWN");
    Transition.$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_DOWN_BIG"), Transition.$ordinal$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition, "fadeOutDownBig", "FADE OUT DOWN BIG");
    Transition.$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_LEFT"), Transition.$ordinal$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, "fadeOutLeft", "FADE OUT LEFT");
    Transition.$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_LEFT_BIG"), Transition.$ordinal$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition, "fadeOutLeftBig", "FADE OUT LEFT BIG");
    Transition.$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_RIGHT"), Transition.$ordinal$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, "fadeOutRight", "FADE OUT RIGHT");
    Transition.$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_RIGHT_BIG"), Transition.$ordinal$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition, "fadeOutRightBig", "FADE OUT RIGHT BIG");
    Transition.$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_UP"), Transition.$ordinal$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition, "fadeOutUp", "FADE OUT UP");
    Transition.$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FADE_OUT_UP_BIG"), Transition.$ordinal$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition, "fadeOutUpBig", "FADE OUT UP BIG");
    Transition.$f_FLIP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FLIP"), Transition.$ordinal$f_FLIP__org_dominokit_domino_ui_animations_Transition, "flip", "FLIP");
    Transition.$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FLIP_IN_X"), Transition.$ordinal$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition, "flipInX", "FLIP IN X");
    Transition.$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FLIP_IN_Y"), Transition.$ordinal$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition, "flipInY", "FLIP IN Y");
    Transition.$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FLIP_OUT_X"), Transition.$ordinal$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition, "flipOutX", "FLIP OUT X");
    Transition.$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("FLIP_OUT_Y"), Transition.$ordinal$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition, "flipOutY", "FLIP OUT Y");
    Transition.$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("LIGHT_SPEED_IN"), Transition.$ordinal$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition, "lightSpeedIn", "LIGHT SPEED IN");
    Transition.$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("LIGHT_SPEED_OUT"), Transition.$ordinal$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition, "lightSpeedOut", "LIGHT SPEED OUT");
    Transition.$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_IN"), Transition.$ordinal$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition, "rotateIn", "ROTATE IN");
    Transition.$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_IN_DOWN_LEFT"), Transition.$ordinal$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition, "rotateInDownLeft", "ROTATE IN DOWN LEFT");
    Transition.$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_IN_DOWN_RIGHT"), Transition.$ordinal$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition, "rotateInDownRight", "ROTATE IN DOWN RIGHT");
    Transition.$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_IN_UP_LEFT"), Transition.$ordinal$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition, "rotateInUpLeft", "ROTATE IN UP LEFT");
    Transition.$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_IN_UP_RIGHT"), Transition.$ordinal$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition, "rotateInUpRight", "ROTATE IN UP RIGHT");
    Transition.$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_OUT"), Transition.$ordinal$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition, "rotateOut", "ROTATE OUT");
    Transition.$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_OUT_DOWN_LEFT"), Transition.$ordinal$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition, "rotateOutDownLeft", "ROTATE OUT DOWN LEFT");
    Transition.$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_OUT_DOWN_RIGHT"), Transition.$ordinal$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition, "rotateOutDownRight", "ROTATE OUT DOWN RIGHT");
    Transition.$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_OUT_UP_LEFT"), Transition.$ordinal$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition, "rotateOutUpLeft", "ROTATE OUT UP LEFT");
    Transition.$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROTATE_OUT_UP_RIGHT"), Transition.$ordinal$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition, "rotateOutUpRight", "ROTATE OUT UP RIGHT");
    Transition.$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_IN_UP"), Transition.$ordinal$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition, "slideInUp", "SLIDE IN UP");
    Transition.$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_IN_DOWN"), Transition.$ordinal$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition, "slideInDown", "SLIDE IN DOWN");
    Transition.$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_IN_LEFT"), Transition.$ordinal$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition, "slideInLeft", "SLIDE IN LEFT");
    Transition.$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_IN_RIGHT"), Transition.$ordinal$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, "slideInRight", "SLIDE IN RIGHT");
    Transition.$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_OUT_UP"), Transition.$ordinal$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition, "slideOutUp", "SLIDE OUT UP");
    Transition.$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_OUT_DOWN"), Transition.$ordinal$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, "slideOutDown", "SLIDE OUT DOWN");
    Transition.$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_OUT_LEFT"), Transition.$ordinal$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, "slideOutLeft", "SLIDE OUT LEFT");
    Transition.$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("SLIDE_OUT_RIGHT"), Transition.$ordinal$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, "slideOutRight", "SLIDE OUT RIGHT");
    Transition.$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_IN"), Transition.$ordinal$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition, "zoomIn", "ZOOM IN");
    Transition.$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_IN_DOWN"), Transition.$ordinal$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition, "zoomInDown", "ZOOM IN DOWN");
    Transition.$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_IN_LEFT"), Transition.$ordinal$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition, "zoomInLeft", "ZOOM IN LEFT");
    Transition.$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_IN_RIGHT"), Transition.$ordinal$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition, "zoomInRight", "ZOOM IN RIGHT");
    Transition.$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_IN_UP"), Transition.$ordinal$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition, "zoomInUp", "ZOOM IN UP");
    Transition.$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_OUT"), Transition.$ordinal$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition, "zoomOut", "ZOOM OUT");
    Transition.$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_OUT_DOWN"), Transition.$ordinal$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition, "zoomOutDown", "ZOOM OUT DOWN");
    Transition.$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_OUT_LEFT"), Transition.$ordinal$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition, "zoomOutLeft", "ZOOM OUT LEFT");
    Transition.$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_OUT_RIGHT"), Transition.$ordinal$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition, "zoomOutRight", "ZOOM OUT RIGHT");
    Transition.$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ZOOM_OUT_UP"), Transition.$ordinal$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition, "zoomOutUp", "ZOOM OUT UP");
    Transition.$f_HINGE__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("HINGE"), Transition.$ordinal$f_HINGE__org_dominokit_domino_ui_animations_Transition, "hinge", "HINGE");
    Transition.$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROLL_IN"), Transition.$ordinal$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition, "rollIn", "ROLL IN");
    Transition.$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("ROLL_OUT"), Transition.$ordinal$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition, "rollOut", "ROLL OUT");
    Transition.$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition = Transition.$create__java_lang_String__int__java_lang_String__java_lang_String($Util.$makeEnumName("COLLAPSE_UP"), Transition.$ordinal$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition, "collapseUp", "COLLAPSE UP");
    Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Transition;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Transition);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(Transition, $Util.$makeClassName('org.dominokit.domino.ui.animations.Transition'));


/** @private {!Transition} */
Transition.$f_BOUNCE__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FLASH__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_PULSE__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SHAKE__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SWING__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_TADA__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_WOBBLE__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_JELLO__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FLIP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_HINGE__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition;


/** @private {!Transition} */
Transition.$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition;


/** @private {Map<?string, !Transition>} */
Transition.$f_namesToValuesMap__org_dominokit_domino_ui_animations_Transition_;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE__org_dominokit_domino_ui_animations_Transition = 0;


/** @public {number} @const */
Transition.$ordinal$f_FLASH__org_dominokit_domino_ui_animations_Transition = 1;


/** @public {number} @const */
Transition.$ordinal$f_PULSE__org_dominokit_domino_ui_animations_Transition = 2;


/** @public {number} @const */
Transition.$ordinal$f_RUBBER_BAND__org_dominokit_domino_ui_animations_Transition = 3;


/** @public {number} @const */
Transition.$ordinal$f_SHAKE__org_dominokit_domino_ui_animations_Transition = 4;


/** @public {number} @const */
Transition.$ordinal$f_SWING__org_dominokit_domino_ui_animations_Transition = 5;


/** @public {number} @const */
Transition.$ordinal$f_TADA__org_dominokit_domino_ui_animations_Transition = 6;


/** @public {number} @const */
Transition.$ordinal$f_WOBBLE__org_dominokit_domino_ui_animations_Transition = 7;


/** @public {number} @const */
Transition.$ordinal$f_JELLO__org_dominokit_domino_ui_animations_Transition = 8;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_IN__org_dominokit_domino_ui_animations_Transition = 9;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = 10;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = 11;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = 12;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_IN_UP__org_dominokit_domino_ui_animations_Transition = 13;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_OUT__org_dominokit_domino_ui_animations_Transition = 14;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = 15;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = 16;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = 17;


/** @public {number} @const */
Transition.$ordinal$f_BOUNCE_OUT_UP__org_dominokit_domino_ui_animations_Transition = 18;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN__org_dominokit_domino_ui_animations_Transition = 19;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = 20;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_DOWN_BIG__org_dominokit_domino_ui_animations_Transition = 21;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = 22;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_LEFT_BIG__org_dominokit_domino_ui_animations_Transition = 23;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = 24;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition = 25;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_UP__org_dominokit_domino_ui_animations_Transition = 26;


/** @public {number} @const */
Transition.$ordinal$f_FADE_IN_UP_BIG__org_dominokit_domino_ui_animations_Transition = 27;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT__org_dominokit_domino_ui_animations_Transition = 28;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = 29;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_DOWN_BIG__org_dominokit_domino_ui_animations_Transition = 30;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = 31;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_LEFT_BIG__org_dominokit_domino_ui_animations_Transition = 32;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = 33;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_RIGHT_BIG__org_dominokit_domino_ui_animations_Transition = 34;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_UP__org_dominokit_domino_ui_animations_Transition = 35;


/** @public {number} @const */
Transition.$ordinal$f_FADE_OUT_UP_BIG__org_dominokit_domino_ui_animations_Transition = 36;


/** @public {number} @const */
Transition.$ordinal$f_FLIP__org_dominokit_domino_ui_animations_Transition = 37;


/** @public {number} @const */
Transition.$ordinal$f_FLIP_IN_X__org_dominokit_domino_ui_animations_Transition = 38;


/** @public {number} @const */
Transition.$ordinal$f_FLIP_IN_Y__org_dominokit_domino_ui_animations_Transition = 39;


/** @public {number} @const */
Transition.$ordinal$f_FLIP_OUT_X__org_dominokit_domino_ui_animations_Transition = 40;


/** @public {number} @const */
Transition.$ordinal$f_FLIP_OUT_Y__org_dominokit_domino_ui_animations_Transition = 41;


/** @public {number} @const */
Transition.$ordinal$f_LIGHT_SPEED_IN__org_dominokit_domino_ui_animations_Transition = 42;


/** @public {number} @const */
Transition.$ordinal$f_LIGHT_SPEED_OUT__org_dominokit_domino_ui_animations_Transition = 43;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_IN__org_dominokit_domino_ui_animations_Transition = 44;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_IN_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition = 45;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_IN_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition = 46;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_IN_UP_LEFT__org_dominokit_domino_ui_animations_Transition = 47;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_IN_UP_RIGHT__org_dominokit_domino_ui_animations_Transition = 48;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_OUT__org_dominokit_domino_ui_animations_Transition = 49;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_OUT_DOWN_LEFT__org_dominokit_domino_ui_animations_Transition = 50;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_OUT_DOWN_RIGHT__org_dominokit_domino_ui_animations_Transition = 51;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_OUT_UP_LEFT__org_dominokit_domino_ui_animations_Transition = 52;


/** @public {number} @const */
Transition.$ordinal$f_ROTATE_OUT_UP_RIGHT__org_dominokit_domino_ui_animations_Transition = 53;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_IN_UP__org_dominokit_domino_ui_animations_Transition = 54;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_IN_DOWN__org_dominokit_domino_ui_animations_Transition = 55;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_IN_LEFT__org_dominokit_domino_ui_animations_Transition = 56;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = 57;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_OUT_UP__org_dominokit_domino_ui_animations_Transition = 58;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = 59;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = 60;


/** @public {number} @const */
Transition.$ordinal$f_SLIDE_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = 61;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_IN__org_dominokit_domino_ui_animations_Transition = 62;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_IN_DOWN__org_dominokit_domino_ui_animations_Transition = 63;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_IN_LEFT__org_dominokit_domino_ui_animations_Transition = 64;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_IN_RIGHT__org_dominokit_domino_ui_animations_Transition = 65;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_IN_UP__org_dominokit_domino_ui_animations_Transition = 66;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_OUT__org_dominokit_domino_ui_animations_Transition = 67;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_OUT_DOWN__org_dominokit_domino_ui_animations_Transition = 68;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_OUT_LEFT__org_dominokit_domino_ui_animations_Transition = 69;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_OUT_RIGHT__org_dominokit_domino_ui_animations_Transition = 70;


/** @public {number} @const */
Transition.$ordinal$f_ZOOM_OUT_UP__org_dominokit_domino_ui_animations_Transition = 71;


/** @public {number} @const */
Transition.$ordinal$f_HINGE__org_dominokit_domino_ui_animations_Transition = 72;


/** @public {number} @const */
Transition.$ordinal$f_ROLL_IN__org_dominokit_domino_ui_animations_Transition = 73;


/** @public {number} @const */
Transition.$ordinal$f_ROLL_OUT__org_dominokit_domino_ui_animations_Transition = 74;


/** @public {number} @const */
Transition.$ordinal$f_COLLAPSE_UP__org_dominokit_domino_ui_animations_Transition = 75;




exports = Transition; 
//# sourceMappingURL=Transition.js.map