/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _InternalHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth.InternalHandler');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasValue = goog.require('org.dominokit.domino.ui.utils.HasValue');
const _IsEditor = goog.require('org.gwtproject.editor.client.IsEditor');
const _LeafValueEditor = goog.require('org.gwtproject.editor.client.LeafValueEditor');
const _JsDate_$Overlay = goog.require('elemental2.core.JsDate.$Overlay');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLAnchorElement_$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _Double = goog.require('java.lang.Double');
const _Integer = goog.require('java.lang.Integer');
const _j_l_String = goog.require('java.lang.String');
const _ArrayList = goog.require('java.util.ArrayList');
const _j_u_Date = goog.require('java.util.Date');
const _List = goog.require('java.util.List');
const _Objects = goog.require('java.util.Objects');
const _Consumer = goog.require('java.util.function.Consumer');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _$LambdaAdaptor$37 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$37');
const _$LambdaAdaptor$38 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$38');
const _$LambdaAdaptor$39 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$39');
const _$LambdaAdaptor$40 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$40');
const _$LambdaAdaptor$41 = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.$LambdaAdaptor$41');
const _BackgroundHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler');
const _DateDayClickedHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler');
const _DateSelectionHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateSelectionHandler');
const _DatePickerElement = goog.require('org.dominokit.domino.ui.datepicker.DatePickerElement');
const _DatePickerMonth = goog.require('org.dominokit.domino.ui.datepicker.DatePickerMonth');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Column = goog.require('org.dominokit.domino.ui.grid.Column');
const _Row = goog.require('org.dominokit.domino.ui.grid.Row');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ModalDialog = goog.require('org.dominokit.domino.ui.modals.ModalDialog');
const _PickerHandler = goog.require('org.dominokit.domino.ui.pickers.PickerHandler');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _WavesSupport = goog.require('org.dominokit.domino.ui.style.WavesSupport');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _DateTimeFormatInfo__factory = goog.require('org.gwtproject.i18n.client.impl.cldr.DateTimeFormatInfo_factory');
const _DateTimeFormatInfo = goog.require('org.gwtproject.i18n.shared.DateTimeFormatInfo');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _EventType = goog.require('org.jboss.gwt.elemento.core.EventType');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Primitives = goog.require('vmbootstrap.Primitives');


// Re-exports the implementation.
var DatePicker = goog.require('org.dominokit.domino.ui.datepicker.DatePicker$impl');
exports = DatePicker;
 