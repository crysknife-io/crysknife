/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$BackgroundHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const BackgroundHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');

let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');


/**
 * @implements {BackgroundHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(ColorScheme, ColorScheme):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(ColorScheme, ColorScheme):void} */
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$LambdaAdaptor__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$JsFunction(fn);
  }
  
  /**
   * @param {?function(ColorScheme, ColorScheme):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$LambdaAdaptor__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {ColorScheme} arg0
   * @param {ColorScheme} arg1
   * @return {void}
   * @public
   */
  m_onBackgroundChanged__org_dominokit_domino_ui_style_ColorScheme__org_dominokit_domino_ui_style_ColorScheme(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$BackgroundHandler$$LambdaAdaptor'));


BackgroundHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DatePicker$BackgroundHandler$$LambdaAdaptor.js.map