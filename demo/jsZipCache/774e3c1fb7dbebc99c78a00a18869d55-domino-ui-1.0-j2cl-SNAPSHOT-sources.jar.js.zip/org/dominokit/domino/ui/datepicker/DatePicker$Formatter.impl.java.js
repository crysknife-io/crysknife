/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$Formatter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.Formatter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DateTimeFormat = goog.require('org.gwtproject.i18n.shared.DateTimeFormat$impl');

let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');


class Formatter extends DateTimeFormat {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Formatter(String)'.
   * @param {?string} pattern
   * @return {!Formatter}
   * @public
   */
  static $create__java_lang_String(pattern) {
    Formatter.$clinit();
    let $instance = new Formatter();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker_Formatter__java_lang_String(pattern);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Formatter(String)'.
   * @param {?string} pattern
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker_Formatter__java_lang_String(pattern) {
    this.$ctor__org_gwtproject_i18n_shared_DateTimeFormat__java_lang_String(pattern);
  }
  
  /**
   * Factory method corresponding to constructor 'Formatter(String, DateTimeFormatInfo)'.
   * @param {?string} pattern
   * @param {DateTimeFormatInfo} dtfi
   * @return {!Formatter}
   * @public
   */
  static $create__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(pattern, dtfi) {
    Formatter.$clinit();
    let $instance = new Formatter();
    $instance.$ctor__org_dominokit_domino_ui_datepicker_DatePicker_Formatter__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(pattern, dtfi);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Formatter(String, DateTimeFormatInfo)'.
   * @param {?string} pattern
   * @param {DateTimeFormatInfo} dtfi
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker_Formatter__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(pattern, dtfi) {
    this.$ctor__org_gwtproject_i18n_shared_DateTimeFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(pattern, dtfi);
  }
  
  /**
   * @param {?string} pattern
   * @param {DateTimeFormatInfo} dateTimeFormatInfo
   * @return {DateTimeFormat}
   * @public
   */
  static m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(pattern, dateTimeFormatInfo) {
    Formatter.$clinit();
    return DateTimeFormat.m_getFormat__java_lang_String__org_gwtproject_i18n_shared_DateTimeFormatInfo(pattern, dateTimeFormatInfo);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Formatter.$clinit = (() =>{
    });
    Formatter.$loadModules();
    DateTimeFormat.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Formatter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Formatter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(Formatter, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$Formatter'));




exports = Formatter; 
//# sourceMappingURL=DatePicker$Formatter.js.map