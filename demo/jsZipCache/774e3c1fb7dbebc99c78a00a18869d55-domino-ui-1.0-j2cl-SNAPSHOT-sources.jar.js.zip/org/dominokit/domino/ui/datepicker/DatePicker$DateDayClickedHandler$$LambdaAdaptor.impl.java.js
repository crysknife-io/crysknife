/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$DateDayClickedHandler$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DateDayClickedHandler = goog.require('org.dominokit.domino.ui.datepicker.DatePicker.DateDayClickedHandler$impl');

let Date = goog.forwardDeclare('java.util.Date$impl');
let DateTimeFormatInfo = goog.forwardDeclare('org.gwtproject.i18n.shared.DateTimeFormatInfo$impl');


/**
 * @implements {DateDayClickedHandler}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(Date, DateTimeFormatInfo):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(Date, DateTimeFormatInfo):void} */
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$LambdaAdaptor__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$JsFunction(fn);
  }
  
  /**
   * @param {?function(Date, DateTimeFormatInfo):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$LambdaAdaptor__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {Date} arg0
   * @param {DateTimeFormatInfo} arg1
   * @return {void}
   * @public
   */
  m_onDateDayClicked__java_util_Date__org_gwtproject_i18n_shared_DateTimeFormatInfo(arg0, arg1) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datepicker_DatePicker_DateDayClickedHandler_$LambdaAdaptor;
      $function(arg0, arg1);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$DateDayClickedHandler$$LambdaAdaptor'));


DateDayClickedHandler.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=DatePicker$DateDayClickedHandler$$LambdaAdaptor.js.map