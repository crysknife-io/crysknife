/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datepicker.DatePicker$BackgroundHandler.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler.$LambdaAdaptor$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');


/**
 * @interface
 */
class BackgroundHandler {
  /**
   * @abstract
   * @param {ColorScheme} oldColorScheme
   * @param {ColorScheme} newColorScheme
   * @return {void}
   * @public
   */
  m_onBackgroundChanged__org_dominokit_domino_ui_style_ColorScheme__org_dominokit_domino_ui_style_ColorScheme(oldColorScheme, newColorScheme) {
  }
  
  /**
   * @param {?function(ColorScheme, ColorScheme):void} fn
   * @return {BackgroundHandler}
   * @public
   */
  static $adapt(fn) {
    BackgroundHandler.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    BackgroundHandler.$clinit = (() =>{
    });
    BackgroundHandler.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datepicker_DatePicker_BackgroundHandler;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datepicker.DatePicker.BackgroundHandler.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(BackgroundHandler, $Util.$makeClassName('org.dominokit.domino.ui.datepicker.DatePicker$BackgroundHandler'));


BackgroundHandler.$markImplementor(/** @type {Function} */ (BackgroundHandler));


exports = BackgroundHandler; 
//# sourceMappingURL=DatePicker$BackgroundHandler.js.map