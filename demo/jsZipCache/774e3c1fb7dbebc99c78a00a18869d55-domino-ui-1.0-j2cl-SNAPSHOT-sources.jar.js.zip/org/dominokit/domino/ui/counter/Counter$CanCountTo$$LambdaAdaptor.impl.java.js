/**
 * @fileoverview transpiled from org.dominokit.domino.ui.counter.Counter$CanCountTo$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.counter.Counter.CanCountTo.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const CanCountTo = goog.require('org.dominokit.domino.ui.counter.Counter.CanCountTo$impl');

let HasInterval = goog.forwardDeclare('org.dominokit.domino.ui.counter.Counter.HasInterval$impl');


/**
 * @implements {CanCountTo}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(number):HasInterval} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(number):HasInterval} */
    this.f_$$fn__org_dominokit_domino_ui_counter_Counter_CanCountTo_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_counter_Counter_CanCountTo_$LambdaAdaptor__org_dominokit_domino_ui_counter_Counter_CanCountTo_$JsFunction(fn);
  }
  
  /**
   * @param {?function(number):HasInterval} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_counter_Counter_CanCountTo_$LambdaAdaptor__org_dominokit_domino_ui_counter_Counter_CanCountTo_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_counter_Counter_CanCountTo_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {number} arg0
   * @return {HasInterval}
   * @public
   */
  m_countTo__int(arg0) {
    let /** ?function(number):HasInterval */ $function;
    return ($function = this.f_$$fn__org_dominokit_domino_ui_counter_Counter_CanCountTo_$LambdaAdaptor, $function(arg0));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.counter.Counter$CanCountTo$$LambdaAdaptor'));


CanCountTo.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=Counter$CanCountTo$$LambdaAdaptor.js.map