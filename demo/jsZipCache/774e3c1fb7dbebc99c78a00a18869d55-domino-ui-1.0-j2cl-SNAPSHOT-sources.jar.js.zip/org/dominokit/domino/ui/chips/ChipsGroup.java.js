/**
 * @fileoverview transpiled from org.dominokit.domino.ui.chips.ChipsGroup.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.chips.ChipsGroup');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasSelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _ArrayList = goog.require('java.util.ArrayList');
const _List = goog.require('java.util.List');
const _Consumer = goog.require('java.util.function.Consumer');
const _Predicate = goog.require('java.util.function.Predicate');
const _Chip = goog.require('org.dominokit.domino.ui.chips.Chip');
const _ColorScheme = goog.require('org.dominokit.domino.ui.style.ColorScheme');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Casts = goog.require('vmbootstrap.Casts');
const _$Objects = goog.require('vmbootstrap.Objects');


// Re-exports the implementation.
var ChipsGroup = goog.require('org.dominokit.domino.ui.chips.ChipsGroup$impl');
exports = ChipsGroup;
 