/**
 * @fileoverview transpiled from org.dominokit.domino.ui.chips.Chip.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.chips.Chip$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasDeselectionHandler = goog.require('org.dominokit.domino.ui.utils.HasDeselectionHandler$impl');
const HasRemoveHandler = goog.require('org.dominokit.domino.ui.utils.HasRemoveHandler$impl');
const HasSelectionHandler = goog.require('org.dominokit.domino.ui.utils.HasSelectionHandler$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');

let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let $LambdaAdaptor$16 = goog.forwardDeclare('org.dominokit.domino.ui.chips.Chip.$LambdaAdaptor$16$impl');
let $LambdaAdaptor$17 = goog.forwardDeclare('org.dominokit.domino.ui.chips.Chip.$LambdaAdaptor$17$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let ColorScheme = goog.forwardDeclare('org.dominokit.domino.ui.style.ColorScheme$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let ElementUtil = goog.forwardDeclare('org.dominokit.domino.ui.utils.ElementUtil$impl');
let DeselectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasDeselectionHandler.DeselectionHandler$impl');
let RemoveHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasRemoveHandler.RemoveHandler$impl');
let SelectionHandler = goog.forwardDeclare('org.dominokit.domino.ui.utils.HasSelectionHandler.SelectionHandler$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, Chip>}
 * @implements {HasSelectionHandler<Chip, ?string>}
 * @implements {HasDeselectionHandler<Chip>}
 * @implements {Switchable<Chip>}
 * @implements {HasRemoveHandler<Chip>}
  */
class Chip extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_element__org_dominokit_domino_ui_chips_Chip_;
    /** @public {HTMLDivElement} */
    this.f_textContainer__org_dominokit_domino_ui_chips_Chip_;
    /** @public {HTMLDivElement} */
    this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_;
    /** @public {HTMLDivElement} */
    this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_;
    /** @public {ColorScheme} */
    this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_chips_Chip_;
    /** @public {Color} */
    this.f_borderColor__org_dominokit_domino_ui_chips_Chip_;
    /** @public {DominoElement<HTMLElement>} */
    this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_;
    /** @public {List<SelectionHandler<?string>>} */
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_Chip_;
    /** @public {List<DeselectionHandler>} */
    this.f_deselectionHandlers__org_dominokit_domino_ui_chips_Chip_;
    /** @public {List<RemoveHandler>} */
    this.f_removeHandlers__org_dominokit_domino_ui_chips_Chip_;
    /** @public {boolean} */
    this.f_selected__org_dominokit_domino_ui_chips_Chip_ = false;
    /** @public {boolean} */
    this.f_enabled__org_dominokit_domino_ui_chips_Chip_ = false;
    /** @public {HTMLElement} */
    this.f_leftAddon__org_dominokit_domino_ui_chips_Chip_;
    /** @public {boolean} */
    this.f_selectable__org_dominokit_domino_ui_chips_Chip_ = false;
    /** @public {Color} */
    this.f_leftBackground__org_dominokit_domino_ui_chips_Chip_;
  }
  
  /**
   * @param {?string} value
   * @return {!Chip}
   * @public
   */
  static $create__java_lang_String(value) {
    Chip.$clinit();
    let $instance = new Chip();
    $instance.$ctor__org_dominokit_domino_ui_chips_Chip__java_lang_String(value);
    return $instance;
  }
  
  /**
   * @param {?string} value
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_chips_Chip__java_lang_String(value) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_chips_Chip();
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_appendChild__elemental2_dom_Node(this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_);
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_appendChild__elemental2_dom_Node(this.f_textContainer__org_dominokit_domino_ui_chips_Chip_);
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_appendChild__elemental2_dom_Node(this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_);
    this.m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_);
    this.m_setRemoveIcon__org_jboss_gwt_elemento_core_IsElement(this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_);
    this.m_setRemovable__boolean(false);
    this.m_setBorderColor__org_dominokit_domino_ui_style_Color(Color.f_INDIGO__org_dominokit_domino_ui_style_Color);
    this.m_setValue__java_lang_String(value);
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_addEventListener__java_lang_String__elemental2_dom_EventListener("click", new $LambdaAdaptor$16(((/** Event */ evt) =>{
      if (this.f_selectable__org_dominokit_domino_ui_chips_Chip_) {
        this.m_toggleSelect__();
      }
      evt.stopPropagation();
    })));
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {Chip}
   * @public
   */
  static m_create__() {
    Chip.$clinit();
    return Chip.m_create__java_lang_String("");
  }
  
  /**
   * @param {?string} value
   * @return {Chip}
   * @public
   */
  static m_create__java_lang_String(value) {
    Chip.$clinit();
    return Chip.$create__java_lang_String(value);
  }
  
  /**
   * @return {Chip}
   * @public
   */
  m_select__() {
    this.f_selected__org_dominokit_domino_ui_chips_Chip_ = true;
    /**@type {Style<HTMLDivElement, DominoElement<HTMLDivElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_element__org_dominokit_domino_ui_chips_Chip_)).m_replaceCss__java_lang_String__java_lang_String(this.m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip(), this.m_getDarkerColor___$p_org_dominokit_domino_ui_chips_Chip());
    /**@type {Style<HTMLElement, DominoElement<HTMLElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_)).m_add__java_lang_String(this.m_getDarkerColor___$p_org_dominokit_domino_ui_chips_Chip());
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_Chip_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectionHandler<?string> */ selectionHandler) =>{
      selectionHandler.m_onSelection__java_lang_Object(this.m_getValue__());
    })));
    return this;
  }
  
  /**
   * @return {Chip}
   * @public
   */
  m_deselect__() {
    this.f_selected__org_dominokit_domino_ui_chips_Chip_ = false;
    /**@type {Style<HTMLDivElement, DominoElement<HTMLDivElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_element__org_dominokit_domino_ui_chips_Chip_)).m_replaceCss__java_lang_String__java_lang_String(this.m_getDarkerColor___$p_org_dominokit_domino_ui_chips_Chip(), this.m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip());
    /**@type {Style<HTMLElement, DominoElement<HTMLElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_)).m_remove__java_lang_String(this.m_getDarkerColor___$p_org_dominokit_domino_ui_chips_Chip());
    this.f_deselectionHandlers__org_dominokit_domino_ui_chips_Chip_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DeselectionHandler */ arg0) =>{
      arg0.m_onDeselection__();
    })));
    return this;
  }
  
  /**
   * @return {Chip}
   * @public
   */
  m_toggleSelect__() {
    if (this.f_selected__org_dominokit_domino_ui_chips_Chip_) {
      this.m_deselect__();
    } else {
      this.m_select__();
    }
    return this;
  }
  
  /**
   * @param {HTMLElement} removeIcon
   * @return {Chip}
   * @public
   */
  m_setRemoveIcon__elemental2_dom_HTMLElement(removeIcon) {
    this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_ = /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(removeIcon));
    ElementUtil.m_clear__elemental2_dom_Element(this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_);
    this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_.appendChild(removeIcon);
    removeIcon.addEventListener("click", new $LambdaAdaptor$17(((/** Event */ evt) =>{
      this.m_remove__();
      evt.stopPropagation();
    })));
    return this;
  }
  
  /**
   * @override
   * @return {Chip}
   * @public
   */
  m_remove__() {
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_remove__();
    this.f_removeHandlers__org_dominokit_domino_ui_chips_Chip_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** RemoveHandler */ arg0) =>{
      arg0.m_onRemove__();
    })));
    return this;
  }
  
  /**
   * @param {IsElement} removeIcon
   * @return {Chip}
   * @public
   */
  m_setRemoveIcon__org_jboss_gwt_elemento_core_IsElement(removeIcon) {
    return this.m_setRemoveIcon__elemental2_dom_HTMLElement(removeIcon.m_asElement__());
  }
  
  /**
   * @param {ColorScheme} colorScheme
   * @return {Chip}
   * @public
   */
  m_setColorScheme__org_dominokit_domino_ui_style_ColorScheme(colorScheme) {
    this.m_removeCurrentBackground__();
    this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_ = colorScheme;
    this.f_color__org_dominokit_domino_ui_chips_Chip_ = colorScheme.m_color__();
    this.m_applyColor__();
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_applyColor__() {
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_style__().m_add__java_lang_String(this.f_color__org_dominokit_domino_ui_chips_Chip_.m_getBackground__());
    this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_.m_style__().m_add__java_lang_String(this.f_color__org_dominokit_domino_ui_chips_Chip_.m_getBackground__());
    this.m_setBorderColor__org_dominokit_domino_ui_style_Color(this.f_color__org_dominokit_domino_ui_chips_Chip_);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_removeCurrentBackground__() {
    if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_)) {
      this.f_element__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(this.m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip());
      this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(this.m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip());
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_color__org_dominokit_domino_ui_chips_Chip_)) {
      this.f_element__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(this.f_color__org_dominokit_domino_ui_chips_Chip_.m_getBackground__());
      this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(this.f_color__org_dominokit_domino_ui_chips_Chip_.m_getBackground__());
    }
  }
  
  /**
   * @param {Color} color
   * @return {Chip}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_)) {
      this.f_element__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(this.m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip());
      this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(this.m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip());
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_color__org_dominokit_domino_ui_chips_Chip_)) {
      this.f_element__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(color.m_getBackground__());
      this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_.m_style__().m_remove__java_lang_String(color.m_getBackground__());
    }
    this.f_color__org_dominokit_domino_ui_chips_Chip_ = color;
    this.m_applyColor__();
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_hasColor___$p_org_dominokit_domino_ui_chips_Chip() {
    return Objects.m_nonNull__java_lang_Object(this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_) || Objects.m_nonNull__java_lang_Object(this.f_color__org_dominokit_domino_ui_chips_Chip_);
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getDarkerColor___$p_org_dominokit_domino_ui_chips_Chip() {
    return this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_.m_darker_4__().m_getBackground__();
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getBackgroundStyle___$p_org_dominokit_domino_ui_chips_Chip() {
    return this.f_color__org_dominokit_domino_ui_chips_Chip_.m_getBackground__();
  }
  
  /**
   * @param {boolean} removable
   * @return {Chip}
   * @public
   */
  m_setRemovable__boolean(removable) {
    if (removable) {
      /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_)).m_setDisplay__java_lang_String("block");
    } else {
      /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_)).m_setDisplay__java_lang_String("none");
    }
    return this;
  }
  
  /**
   * @param {?string} value
   * @return {Chip}
   * @public
   */
  m_setValue__java_lang_String(value) {
    this.f_textContainer__org_dominokit_domino_ui_chips_Chip_.textContent = value;
    return this;
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Chip}
   * @public
   */
  m_setLeftIcon__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    this.m_setLeftAddon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_chips_Chip(icon.m_asElement__());
    return this;
  }
  
  /**
   * @param {HTMLImageElement} imageElement
   * @return {Chip}
   * @public
   */
  m_setLeftImg__elemental2_dom_HTMLImageElement(imageElement) {
    this.m_setLeftAddon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_chips_Chip(imageElement);
    return this;
  }
  
  /**
   * @param {IsElement<HTMLImageElement>} imageElement
   * @return {Chip}
   * @public
   */
  m_setLeftImg__org_jboss_gwt_elemento_core_IsElement(imageElement) {
    return this.m_setLeftImg__elemental2_dom_HTMLImageElement(/**@type {HTMLImageElement} */ ($Casts.$to(imageElement.m_asElement__(), $Overlay)));
  }
  
  /**
   * @param {?string} text
   * @return {Chip}
   * @public
   */
  m_setLeftLetter__java_lang_String(text) {
    this.m_setLeftAddon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_chips_Chip(/**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_textContent__java_lang_String(text), HtmlContentBuilder)).m_asElement__());
    return this;
  }
  
  /**
   * @param {HTMLElement} leftAddon
   * @return {void}
   * @public
   */
  m_setLeftAddon__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_chips_Chip(leftAddon) {
    this.f_leftAddon__org_dominokit_domino_ui_chips_Chip_ = leftAddon;
    ElementUtil.m_clear__elemental2_dom_Element(this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_);
    this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_.appendChild(leftAddon);
    this.m_updateLeftAddonBackground___$p_org_dominokit_domino_ui_chips_Chip();
  }
  
  /**
   * @param {Color} leftBackground
   * @return {Chip}
   * @public
   */
  m_setLeftBackground__org_dominokit_domino_ui_style_Color(leftBackground) {
    this.f_leftBackground__org_dominokit_domino_ui_chips_Chip_ = leftBackground;
    this.m_updateLeftAddonBackground___$p_org_dominokit_domino_ui_chips_Chip();
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_updateLeftAddonBackground___$p_org_dominokit_domino_ui_chips_Chip() {
    if (Objects.m_nonNull__java_lang_Object(this.f_leftAddon__org_dominokit_domino_ui_chips_Chip_) && Objects.m_nonNull__java_lang_Object(this.f_leftBackground__org_dominokit_domino_ui_chips_Chip_)) {
      /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_leftAddon__org_dominokit_domino_ui_chips_Chip_)).m_add__java_lang_String(this.f_leftBackground__org_dominokit_domino_ui_chips_Chip_.m_getBackground__());
    }
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_chips_Chip_.m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @override
   * @param {SelectionHandler<?string>} selectionHandler
   * @return {Chip}
   * @public
   */
  m_addSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(selectionHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_Chip_.add(selectionHandler);
    return this;
  }
  
  /**
   * @override
   * @param {DeselectionHandler} deselectionHandler
   * @return {Chip}
   * @public
   */
  m_addDeselectionHandler__org_dominokit_domino_ui_utils_HasDeselectionHandler_DeselectionHandler(deselectionHandler) {
    this.f_deselectionHandlers__org_dominokit_domino_ui_chips_Chip_.add(deselectionHandler);
    return this;
  }
  
  /**
   * @override
   * @param {SelectionHandler<?string>} selectionHandler
   * @return {Chip}
   * @public
   */
  m_removeSelectionHandler__org_dominokit_domino_ui_utils_HasSelectionHandler_SelectionHandler(selectionHandler) {
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_Chip_.remove(selectionHandler);
    return this;
  }
  
  /**
   * @override
   * @return {Chip}
   * @public
   */
  m_enable__() {
    this.f_enabled__org_dominokit_domino_ui_chips_Chip_ = true;
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_removeAttribute__java_lang_String("disabled");
    this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_.removeAttribute("disabled");
    return this;
  }
  
  /**
   * @override
   * @return {Chip}
   * @public
   */
  m_disable__() {
    this.f_enabled__org_dominokit_domino_ui_chips_Chip_ = false;
    this.f_element__org_dominokit_domino_ui_chips_Chip_.m_setAttribute__java_lang_String__java_lang_String("disabled", "disabled");
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_, "disabled", "disabled");
    return this;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return this.f_enabled__org_dominokit_domino_ui_chips_Chip_;
  }
  
  /**
   * @override
   * @param {RemoveHandler} removeHandler
   * @return {Chip}
   * @public
   */
  m_addRemoveHandler__org_dominokit_domino_ui_utils_HasRemoveHandler_RemoveHandler(removeHandler) {
    this.f_removeHandlers__org_dominokit_domino_ui_chips_Chip_.add(removeHandler);
    return this;
  }
  
  /**
   * @param {boolean} selectable
   * @return {Chip}
   * @public
   */
  m_setSelectable__boolean(selectable) {
    this.f_selectable__org_dominokit_domino_ui_chips_Chip_ = selectable;
    return this;
  }
  
  /**
   * @param {Color} borderColor
   * @return {Chip}
   * @public
   */
  m_setBorderColor__org_dominokit_domino_ui_style_Color(borderColor) {
    if (Objects.m_nonNull__java_lang_Object(this.f_borderColor__org_dominokit_domino_ui_chips_Chip_)) {
      /**@type {Style<HTMLDivElement, DominoElement<HTMLDivElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_element__org_dominokit_domino_ui_chips_Chip_)).m_removeProperty__java_lang_String("border-color");
    }
    this.f_borderColor__org_dominokit_domino_ui_chips_Chip_ = borderColor;
    /**@type {Style<HTMLDivElement, DominoElement<HTMLDivElement>>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_element__org_dominokit_domino_ui_chips_Chip_)).m_setBorderColor__java_lang_String(borderColor.m_getHex__());
    return this;
  }
  
  /**
   * @return {Chip}
   * @public
   */
  m_removeLeftAddon__() {
    ElementUtil.m_clear__elemental2_dom_Element(this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_);
    return this;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return this.f_textContainer__org_dominokit_domino_ui_chips_Chip_.textContent;
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getTextContainer__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_textContainer__org_dominokit_domino_ui_chips_Chip_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getLeftAddonContainer__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getRemoveIconContainer__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_));
  }
  
  /**
   * @return {DominoElement<HTMLElement>}
   * @public
   */
  m_getRemoveIcon__() {
    return /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_));
  }
  
  /**
   * @return {DominoElement<HTMLElement>}
   * @public
   */
  m_getLeftAddon__() {
    return /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_leftAddon__org_dominokit_domino_ui_chips_Chip_));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_chips_Chip() {
    this.f_element__org_dominokit_domino_ui_chips_Chip_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["chip"], j_l_String)))));
    this.f_textContainer__org_dominokit_domino_ui_chips_Chip_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["chip-value"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_leftAddonContainer__org_dominokit_domino_ui_chips_Chip_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["chip-addon"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_removeIconContainer__org_dominokit_domino_ui_chips_Chip_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["chip-remove"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_colorScheme__org_dominokit_domino_ui_chips_Chip_ = ColorScheme.f_INDIGO__org_dominokit_domino_ui_style_ColorScheme;
    this.f_color__org_dominokit_domino_ui_chips_Chip_ = Color.f_INDIGO__org_dominokit_domino_ui_style_Color;
    this.f_removeIcon__org_dominokit_domino_ui_chips_Chip_ = /**@type {DominoElement<HTMLElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(Icons.f_ALL__org_dominokit_domino_ui_icons_Icons.m_close__().m_asElement__()));
    this.f_selectionHandlers__org_dominokit_domino_ui_chips_Chip_ = /**@type {!ArrayList<SelectionHandler<?string>>} */ (ArrayList.$create__());
    this.f_deselectionHandlers__org_dominokit_domino_ui_chips_Chip_ = /**@type {!ArrayList<DeselectionHandler>} */ (ArrayList.$create__());
    this.f_removeHandlers__org_dominokit_domino_ui_chips_Chip_ = /**@type {!ArrayList<RemoveHandler>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Chip.$clinit = (() =>{
    });
    Chip.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Chip;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Chip);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLImageElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    $LambdaAdaptor$16 = goog.module.get('org.dominokit.domino.ui.chips.Chip.$LambdaAdaptor$16$impl');
    $LambdaAdaptor$17 = goog.module.get('org.dominokit.domino.ui.chips.Chip.$LambdaAdaptor$17$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    Color = goog.module.get('org.dominokit.domino.ui.style.Color$impl');
    ColorScheme = goog.module.get('org.dominokit.domino.ui.style.ColorScheme$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    ElementUtil = goog.module.get('org.dominokit.domino.ui.utils.ElementUtil$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Chip, $Util.$makeClassName('org.dominokit.domino.ui.chips.Chip'));


HasSelectionHandler.$markImplementor(Chip);
HasDeselectionHandler.$markImplementor(Chip);
Switchable.$markImplementor(Chip);
HasRemoveHandler.$markImplementor(Chip);


exports = Chip; 
//# sourceMappingURL=Chip.js.map