/**
 * @fileoverview transpiled from org.dominokit.domino.ui.alerts.AlertLink.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.alerts.AlertLink$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');


/**
 * @extends {BaseDominoElement<HTMLAnchorElement, AlertLink>}
  */
class AlertLink extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLAnchorElement} */
    this.f_element__org_dominokit_domino_ui_alerts_AlertLink_;
  }
  
  /**
   * @param {HTMLAnchorElement} element
   * @return {!AlertLink}
   * @public
   */
  static $create__elemental2_dom_HTMLAnchorElement(element) {
    AlertLink.$clinit();
    let $instance = new AlertLink();
    $instance.$ctor__org_dominokit_domino_ui_alerts_AlertLink__elemental2_dom_HTMLAnchorElement(element);
    return $instance;
  }
  
  /**
   * @param {HTMLAnchorElement} element
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_alerts_AlertLink__elemental2_dom_HTMLAnchorElement(element) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.f_element__org_dominokit_domino_ui_alerts_AlertLink_ = element;
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    this.m_style__().m_add__java_lang_String(Styles.f_alert_link__org_dominokit_domino_ui_style_Styles);
  }
  
  /**
   * @param {HTMLAnchorElement} element
   * @return {AlertLink}
   * @public
   */
  static m_create__elemental2_dom_HTMLAnchorElement(element) {
    AlertLink.$clinit();
    return AlertLink.$create__elemental2_dom_HTMLAnchorElement(element);
  }
  
  /**
   * @override
   * @return {HTMLAnchorElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_alerts_AlertLink_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    AlertLink.$clinit = (() =>{
    });
    AlertLink.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof AlertLink;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, AlertLink);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
  }
  
  
};

$Util.$setClassMetadata(AlertLink, $Util.$makeClassName('org.dominokit.domino.ui.alerts.AlertLink'));




exports = AlertLink; 
//# sourceMappingURL=AlertLink.js.map