/**
 * @fileoverview transpiled from org.dominokit.domino.ui.alerts.Alert.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.alerts.Alert');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _Event_$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLAnchorElement.$Overlay');
const _HTMLButtonElement_$Overlay = goog.require('elemental2.dom.HTMLButtonElement.$Overlay');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Strong = goog.require('org.dominokit.domino.ui.Typography.Strong');
const _$LambdaAdaptor$1 = goog.require('org.dominokit.domino.ui.alerts.Alert.$LambdaAdaptor$1');
const _AlertType = goog.require('org.dominokit.domino.ui.alerts.Alert.AlertType');
const _AlertLink = goog.require('org.dominokit.domino.ui.alerts.AlertLink');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _Styles = goog.require('org.dominokit.domino.ui.style.Styles');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var Alert = goog.require('org.dominokit.domino.ui.alerts.Alert$impl');
exports = Alert;
 