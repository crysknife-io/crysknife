/**
 * @fileoverview transpiled from org.dominokit.domino.ui.Typography.Strong.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.Typography.Strong$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');


/**
 * @extends {BaseDominoElement<HTMLElement, Strong>}
  */
class Strong extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_element__org_dominokit_domino_ui_Typography_Strong_;
  }
  
  /**
   * @param {?string} text
   * @return {!Strong}
   * @public
   */
  static $create__java_lang_String(text) {
    Strong.$clinit();
    let $instance = new Strong();
    $instance.$ctor__org_dominokit_domino_ui_Typography_Strong__java_lang_String(text);
    return $instance;
  }
  
  /**
   * @param {?string} text
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_Typography_Strong__java_lang_String(text) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_Typography_Strong();
    this.f_element__org_dominokit_domino_ui_Typography_Strong_.textContent = text;
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {?string} text
   * @return {Strong}
   * @public
   */
  static m_of__java_lang_String(text) {
    Strong.$clinit();
    return Strong.$create__java_lang_String(text);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_Typography_Strong_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_Typography_Strong() {
    this.f_element__org_dominokit_domino_ui_Typography_Strong_ = Elements.m_strong__().m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Strong.$clinit = (() =>{
    });
    Strong.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Strong;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Strong);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
  }
  
  
};

$Util.$setClassMetadata(Strong, $Util.$makeClassName('org.dominokit.domino.ui.Typography.Strong'));




exports = Strong; 
//# sourceMappingURL=Strong.js.map