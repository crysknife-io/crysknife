/**
 * @fileoverview transpiled from org.dominokit.domino.ui.cards.HeaderAction.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.cards.HeaderAction$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let EventListener_$Overlay = goog.forwardDeclare('elemental2.dom.EventListener.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let StyleEditor = goog.forwardDeclare('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLLIElement, HeaderAction>}
  */
class HeaderAction extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLLIElement} */
    this.f_element__org_dominokit_domino_ui_cards_HeaderAction_;
    /** @public {HTMLAnchorElement} */
    this.f_anchorElement__org_dominokit_domino_ui_cards_HeaderAction_;
    /** @public {BaseIcon<?>} */
    this.f_icon__org_dominokit_domino_ui_cards_HeaderAction_;
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {EventListener} eventListener
   * @return {HeaderAction}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(icon, eventListener) {
    HeaderAction.$clinit();
    return HeaderAction.$create__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(icon, eventListener);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {HeaderAction}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    HeaderAction.$clinit();
    return HeaderAction.$create__org_dominokit_domino_ui_icons_BaseIcon(icon);
  }
  
  /**
   * Factory method corresponding to constructor 'HeaderAction(BaseIcon)'.
   * @param {BaseIcon<?>} icon
   * @return {!HeaderAction}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    HeaderAction.$clinit();
    let $instance = new HeaderAction();
    $instance.$ctor__org_dominokit_domino_ui_cards_HeaderAction__org_dominokit_domino_ui_icons_BaseIcon(icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HeaderAction(BaseIcon)'.
   * @param {BaseIcon<?>} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_cards_HeaderAction__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_cards_HeaderAction();
    this.f_icon__org_dominokit_domino_ui_cards_HeaderAction_ = icon;
    /**@type {BaseIcon} */ ($Casts.$to(this.f_icon__org_dominokit_domino_ui_cards_HeaderAction_.m_withWaves__(), BaseIcon)).m_styler__org_dominokit_domino_ui_utils_BaseDominoElement_StyleEditor(StyleEditor.$adapt(((/** Style<HTMLElement, BaseIcon> */ style) =>{
      style.m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_pull_right__org_dominokit_domino_ui_style_Styles, "action-icon"], j_l_String)));
    })));
    this.f_anchorElement__org_dominokit_domino_ui_cards_HeaderAction_.appendChild(this.f_icon__org_dominokit_domino_ui_cards_HeaderAction_.m_asElement__());
    this.f_element__org_dominokit_domino_ui_cards_HeaderAction_.appendChild(this.f_anchorElement__org_dominokit_domino_ui_cards_HeaderAction_);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * Factory method corresponding to constructor 'HeaderAction(BaseIcon, EventListener)'.
   * @param {BaseIcon<?>} icon
   * @param {EventListener} eventListener
   * @return {!HeaderAction}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(icon, eventListener) {
    HeaderAction.$clinit();
    let $instance = new HeaderAction();
    $instance.$ctor__org_dominokit_domino_ui_cards_HeaderAction__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(icon, eventListener);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'HeaderAction(BaseIcon, EventListener)'.
   * @param {BaseIcon<?>} icon
   * @param {EventListener} eventListener
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_cards_HeaderAction__org_dominokit_domino_ui_icons_BaseIcon__elemental2_dom_EventListener(icon, eventListener) {
    this.$ctor__org_dominokit_domino_ui_cards_HeaderAction__org_dominokit_domino_ui_icons_BaseIcon(icon);
    this.f_anchorElement__org_dominokit_domino_ui_cards_HeaderAction_.addEventListener("click", eventListener);
  }
  
  /**
   * @override
   * @return {HTMLLIElement}
   * @public
   */
  m_asElement__() {
    return this.f_element__org_dominokit_domino_ui_cards_HeaderAction_;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.f_anchorElement__org_dominokit_domino_ui_cards_HeaderAction_;
  }
  
  /**
   * @return {BaseIcon<?>}
   * @public
   */
  m_getIcon__() {
    return this.f_icon__org_dominokit_domino_ui_cards_HeaderAction_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_cards_HeaderAction() {
    this.f_element__org_dominokit_domino_ui_cards_HeaderAction_ = /**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), $Overlay));
    this.f_anchorElement__org_dominokit_domino_ui_cards_HeaderAction_ = /**@type {HTMLAnchorElement} */ ($Casts.$to(Elements.m_a__().m_asElement__(), HTMLAnchorElement_$Overlay));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HeaderAction.$clinit = (() =>{
    });
    HeaderAction.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof HeaderAction;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, HeaderAction);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLAnchorElement_$Overlay = goog.module.get('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    BaseIcon = goog.module.get('org.dominokit.domino.ui.icons.BaseIcon$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    StyleEditor = goog.module.get('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(HeaderAction, $Util.$makeClassName('org.dominokit.domino.ui.cards.HeaderAction'));




exports = HeaderAction; 
//# sourceMappingURL=HeaderAction.js.map