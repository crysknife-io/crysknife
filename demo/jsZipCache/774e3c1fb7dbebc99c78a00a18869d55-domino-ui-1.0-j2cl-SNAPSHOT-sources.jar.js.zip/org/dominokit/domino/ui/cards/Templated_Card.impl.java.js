/**
 * @fileoverview transpiled from org.dominokit.domino.ui.cards.Templated_Card.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.cards.Templated_Card$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const Card = goog.require('org.dominokit.domino.ui.cards.Card$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let Element_$Overlay = goog.forwardDeclare('elemental2.dom.Element.$Overlay$impl');
let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLUListElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLUListElement.$Overlay$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let TemplateUtil = goog.forwardDeclare('org.jboss.gwt.elemento.template.TemplateUtil$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Templated__Card extends Card {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLDivElement} */
    this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_;
  }
  
  /**
   * @return {!Templated__Card}
   * @public
   */
  static $create__() {
    Templated__Card.$clinit();
    let $instance = new Templated__Card();
    $instance.$ctor__org_dominokit_domino_ui_cards_Templated_Card__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_cards_Templated_Card__() {
    this.$ctor__org_dominokit_domino_ui_cards_Card__();
    this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_ = /**@type {HTMLDivElement} */ ($Casts.$to($Overlay.f_document__elemental2_dom_DomGlobal_$Overlay.createElement("div"), HTMLDivElement_$Overlay));
    Element_$Overlay.m_setAttribute__elemental2_dom_Element__java_lang_String__java_lang_String(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "class", "card");
    this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_.innerHTML = "<div data-element=\"header\" class=\"header\">  <h2 data-element=\"headerTitle\"> <small data-element=\"headerDescription\"></small> </h2>  <ul data-element=\"headerBar\" class=\"header-dropdown m-r--5\">  </ul> </div> <div data-element=\"body\" class=\"body\"> </div>";
    if ($Equality.$same(this.f_header__org_dominokit_domino_ui_cards_Card, null)) {
      this.f_header__org_dominokit_domino_ui_cards_Card = /**@type {HTMLDivElement} */ ($Casts.$to(TemplateUtil.m_resolveElementAs__elemental2_dom_HTMLElement__java_lang_String(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "header"), HTMLDivElement_$Overlay));
    } else {
      TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "header", this.f_header__org_dominokit_domino_ui_cards_Card);
    }
    if ($Equality.$same(this.f_headerTitle__org_dominokit_domino_ui_cards_Card, null)) {
      this.f_headerTitle__org_dominokit_domino_ui_cards_Card = TemplateUtil.m_resolveElement__elemental2_dom_HTMLElement__java_lang_String(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "headerTitle");
    } else {
      TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "headerTitle", this.f_headerTitle__org_dominokit_domino_ui_cards_Card);
    }
    if ($Equality.$same(this.f_headerDescription__org_dominokit_domino_ui_cards_Card, null)) {
      this.f_headerDescription__org_dominokit_domino_ui_cards_Card = TemplateUtil.m_resolveElement__elemental2_dom_HTMLElement__java_lang_String(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "headerDescription");
    } else {
      TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "headerDescription", this.f_headerDescription__org_dominokit_domino_ui_cards_Card);
    }
    if ($Equality.$same(this.f_headerBar__org_dominokit_domino_ui_cards_Card, null)) {
      this.f_headerBar__org_dominokit_domino_ui_cards_Card = /**@type {HTMLUListElement} */ ($Casts.$to(TemplateUtil.m_resolveElementAs__elemental2_dom_HTMLElement__java_lang_String(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "headerBar"), HTMLUListElement_$Overlay));
    } else {
      TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "headerBar", this.f_headerBar__org_dominokit_domino_ui_cards_Card);
    }
    if ($Equality.$same(this.f_body__org_dominokit_domino_ui_cards_Card, null)) {
      this.f_body__org_dominokit_domino_ui_cards_Card = /**@type {HTMLDivElement} */ ($Casts.$to(TemplateUtil.m_resolveElementAs__elemental2_dom_HTMLElement__java_lang_String(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "body"), HTMLDivElement_$Overlay));
    } else {
      TemplateUtil.m_replaceElement__elemental2_dom_HTMLElement__java_lang_String__elemental2_dom_HTMLElement(this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_, "body", this.f_body__org_dominokit_domino_ui_cards_Card);
    }
    this.m_init___$pp_org_dominokit_domino_ui_cards();
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_templated_card_root_element__org_dominokit_domino_ui_cards_Templated_Card_;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Templated__Card.$clinit = (() =>{
    });
    Templated__Card.$loadModules();
    Card.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Templated__Card;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Templated__Card);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Element_$Overlay = goog.module.get('elemental2.dom.Element.$Overlay$impl');
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLUListElement_$Overlay = goog.module.get('elemental2.dom.HTMLUListElement.$Overlay$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    TemplateUtil = goog.module.get('org.jboss.gwt.elemento.template.TemplateUtil$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Templated__Card, $Util.$makeClassName('org.dominokit.domino.ui.cards.Templated_Card'));




exports = Templated__Card; 
//# sourceMappingURL=Templated_Card.js.map