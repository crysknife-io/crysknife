/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.HeaderElement.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.HeaderElement$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.HeaderElement.$LambdaAdaptor$impl');


/**
 * @interface
 */
class HeaderElement {
  /**
   * @abstract
   * @param {?string} columnTitle
   * @return {Node}
   * @public
   */
  m_asElement__java_lang_String(columnTitle) {
  }
  
  /**
   * @param {?function(?string):Node} fn
   * @return {HeaderElement}
   * @public
   */
  static $adapt(fn) {
    HeaderElement.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HeaderElement.$clinit = (() =>{
    });
    HeaderElement.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_HeaderElement = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_HeaderElement;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_HeaderElement;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.HeaderElement.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(HeaderElement, $Util.$makeClassName('org.dominokit.domino.ui.datatable.HeaderElement'));


HeaderElement.$markImplementor(/** @type {Function} */ (HeaderElement));


exports = HeaderElement; 
//# sourceMappingURL=HeaderElement.js.map