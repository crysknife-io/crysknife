/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.DecimalHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.DecimalHeaderFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DelayedHeaderFilterInput = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let BigDecimalBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.BigDecimalBox$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {DelayedHeaderFilterInput<BigDecimalBox, C_T>}
  */
class DecimalHeaderFilter extends DelayedHeaderFilterInput {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {BigDecimalBox} */
    this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_;
  }
  
  /**
   * @template C_T
   * @return {!DecimalHeaderFilter<C_T>}
   * @public
   */
  static $create__() {
    DecimalHeaderFilter.$clinit();
    let $instance = new DecimalHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput__();
  }
  
  /**
   * @template M_T
   * @return {DecimalHeaderFilter<M_T>}
   * @public
   */
  static m_create__() {
    DecimalHeaderFilter.$clinit();
    return /**@type {!DecimalHeaderFilter<*>} */ (DecimalHeaderFilter.$create__());
  }
  
  /**
   * @override
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
    return /**@type {HTMLInputElement} */ ($Casts.$to(this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {BigDecimalBox}
   * @public
   */
  m_createValueBox__() {
    this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_ = BigDecimalBox.m_create__();
    return this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_isEmpty__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return j_l_String.m_valueOf__java_lang_Object(this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_getValue__()) + "";
  }
  
  /**
   * @override
   * @return {FilterTypes}
   * @public
   */
  m_getType__() {
    return FilterTypes.f_DECIMAL__org_dominokit_domino_ui_datatable_model_FilterTypes;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_pauseChangeHandlers__();
    this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_clear__();
    /**@type {HTMLInputElement} */ ($Casts.$to(this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay)).value = "";
    this.f_decimalBox__org_dominokit_domino_ui_datatable_plugins_filter_header_DecimalHeaderFilter_.m_resumeChangeHandlers__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DecimalHeaderFilter.$clinit = (() =>{
    });
    DecimalHeaderFilter.$loadModules();
    DelayedHeaderFilterInput.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DecimalHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DecimalHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    BigDecimalBox = goog.module.get('org.dominokit.domino.ui.forms.BigDecimalBox$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DecimalHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.DecimalHeaderFilter'));




exports = DecimalHeaderFilter; 
//# sourceMappingURL=DecimalHeaderFilter.js.map