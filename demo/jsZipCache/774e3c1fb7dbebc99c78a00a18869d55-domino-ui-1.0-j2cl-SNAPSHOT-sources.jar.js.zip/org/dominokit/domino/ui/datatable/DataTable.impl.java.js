/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const HasSelectionSupport = goog.require('org.dominokit.domino.ui.utils.HasSelectionSupport$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLTableElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let j_u_function_Function = goog.forwardDeclare('java.util.function.Function$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let Stream = goog.forwardDeclare('java.util.stream.Stream$impl');
let LocalRowFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter$impl');
let SelectionChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');
let TableConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableConfig$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableDataUpdatedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let TableEventListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');
let SearchContext = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
let DataTablePlugin = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');
let DataChangedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.DataChangedEvent$impl');
let DataStore = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.DataStore$impl');
let StoreDataChangeListener = goog.forwardDeclare('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {BaseDominoElement<HTMLDivElement, DataTable<C_T>>}
 * @implements {HasSelectionSupport<TableRow<C_T>>}
  */
class DataTable extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DataStore<C_T>} */
    this.f_dataStore__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_element__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {DominoElement<HTMLTableElement>} */
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {TableConfig<C_T>} */
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {DominoElement<HTMLTableSectionElement>} */
    this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {DominoElement<HTMLTableSectionElement>} */
    this.f_thead__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {List<C_T>} */
    this.f_data__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {boolean} */
    this.f_selectable__org_dominokit_domino_ui_datatable_DataTable_ = false;
    /** @public {List<TableRow<C_T>>} */
    this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {List<SelectionChangeListener<C_T>>} */
    this.f_selectionChangeListeners__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {boolean} */
    this.f_condensed__org_dominokit_domino_ui_datatable_DataTable_ = false;
    /** @public {boolean} */
    this.f_hoverable__org_dominokit_domino_ui_datatable_DataTable_ = false;
    /** @public {boolean} */
    this.f_striped__org_dominokit_domino_ui_datatable_DataTable_ = false;
    /** @public {boolean} */
    this.f_bordered__org_dominokit_domino_ui_datatable_DataTable_ = false;
    /** @public {Map<?string, List<TableEventListener>>} */
    this.f_events__org_dominokit_domino_ui_datatable_DataTable_;
    /** @public {SearchContext<C_T>} */
    this.f_searchContext__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @template C_T
   * @param {TableConfig<C_T>} tableConfig
   * @param {DataStore<C_T>} dataStore
   * @return {!DataTable<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, dataStore) {
    DataTable.$clinit();
    let $instance = new DataTable();
    $instance.$ctor__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, dataStore);
    return $instance;
  }
  
  /**
   * @param {TableConfig<C_T>} tableConfig
   * @param {DataStore<C_T>} dataStore
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableConfig__org_dominokit_domino_ui_datatable_store_DataStore(tableConfig, dataStore) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_datatable_DataTable();
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_ = tableConfig;
    this.f_events__org_dominokit_domino_ui_datatable_DataTable_.put(DataTable.f_ANY__org_dominokit_domino_ui_datatable_DataTable, /**@type {!ArrayList<TableEventListener>} */ (ArrayList.$create__()));
    this.f_dataStore__org_dominokit_domino_ui_datatable_DataTable_ = dataStore;
    this.m_addTableEventListner__java_lang_String__org_dominokit_domino_ui_datatable_events_TableEventListener(DataTable.f_ANY__org_dominokit_domino_ui_datatable_DataTable, dataStore);
    this.f_dataStore__org_dominokit_domino_ui_datatable_DataTable_.m_onDataChanged__org_dominokit_domino_ui_datatable_store_StoreDataChangeListener(/**@type {StoreDataChangeListener<C_T>} */ (StoreDataChangeListener.$adapt(((/** DataChangedEvent<*> */ dataChangedEvent) =>{
      if (dataChangedEvent.m_isAppend__()) {
        this.m_appendData__java_util_List(dataChangedEvent.m_getNewData__());
      } else {
        this.m_setData__java_util_List(dataChangedEvent.m_getNewData__());
      }
      this.m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(/**@type {!TableDataUpdatedEvent<*>} */ (TableDataUpdatedEvent.$create__java_util_List__int(this.f_data__org_dominokit_domino_ui_datatable_DataTable_, dataChangedEvent.m_getTotalCount__())));
    }))));
    this.m_init___$p_org_dominokit_domino_ui_datatable_DataTable();
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_init___$p_org_dominokit_domino_ui_datatable_DataTable() {
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_getPlugins__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin) =>{
      this.m_addTableEventListner__java_lang_String__org_dominokit_domino_ui_datatable_events_TableEventListener("*", plugin);
      plugin.m_init__org_dominokit_domino_ui_datatable_DataTable(this);
      plugin.m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(this);
    })));
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_onBeforeHeaders__org_dominokit_domino_ui_datatable_DataTable_$pp_org_dominokit_domino_ui_datatable(this);
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_drawHeaders__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_utils_DominoElement(this, this.f_thead__org_dominokit_domino_ui_datatable_DataTable_);
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_onAfterHeaders__org_dominokit_domino_ui_datatable_DataTable(this);
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_);
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_getPlugins__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin$1$) =>{
      plugin$1$.m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(this);
    })));
    this.f_element__org_dominokit_domino_ui_datatable_DataTable_.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_);
    this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_getPlugins__().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** DataTablePlugin<*> */ plugin$2$) =>{
      plugin$2$.m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(this);
    })));
    if (!this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_isLazyLoad__()) {
      this.f_dataStore__org_dominokit_domino_ui_datatable_DataTable_.m_load__();
    }
    if (this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_isFixed__()) {
      this.f_element__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_setPosition__java_lang_String("relative").m_setOverFlowY__java_lang_String("hidden");
      this.f_thead__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_setDisplay__java_lang_String("block");
      this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_add__java_lang_String("tbody-fixed").m_setMaxHeight__java_lang_String(this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_getFixedBodyHeight__());
    }
    super.m_init__org_jboss_gwt_elemento_core_IsElement(this);
    return this;
  }
  
  /**
   * @return {void}
   * @public
   */
  m_load__() {
    this.f_dataStore__org_dominokit_domino_ui_datatable_DataTable_.m_load__();
  }
  
  /**
   * @param {List<C_T>} data
   * @return {void}
   * @public
   */
  m_setData__java_util_List(data) {
    this.f_data__org_dominokit_domino_ui_datatable_DataTable_ = data;
    this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.clear();
    this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_.m_clearElement__();
    if (Objects.m_nonNull__java_lang_Object(data) && !data.isEmpty()) {
      this.m_addRows__java_util_List__int_$p_org_dominokit_domino_ui_datatable_DataTable(data, 0);
    }
    /**@type {HTMLTableSectionElement} */ ($Casts.$to(this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_.m_asElement__(), $Overlay)).scrollTop = 0.0;
  }
  
  /**
   * @param {List<C_T>} newData
   * @return {void}
   * @public
   */
  m_appendData__java_util_List(newData) {
    if (Objects.m_nonNull__java_lang_Object(this.f_data__org_dominokit_domino_ui_datatable_DataTable_)) {
      this.m_addRows__java_util_List__int_$p_org_dominokit_domino_ui_datatable_DataTable(newData, this.f_data__org_dominokit_domino_ui_datatable_DataTable_.size());
      this.f_data__org_dominokit_domino_ui_datatable_DataTable_.addAll(newData);
    } else {
      this.m_setData__java_util_List(newData);
    }
  }
  
  /**
   * @param {List<C_T>} data
   * @param {number} initialIndex
   * @return {void}
   * @public
   */
  m_addRows__java_util_List__int_$p_org_dominokit_domino_ui_datatable_DataTable(data, initialIndex) {
    for (let index = 0; index < data.size(); index++) {
      let tableRow = /**@type {!TableRow<C_T>} */ (TableRow.$create__java_lang_Object__int(data.getAtIndex(index), initialIndex + index));
      this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_drawRecord__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, tableRow);
      this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.add(tableRow);
    }
  }
  
  /**
   * @return {Collection<C_T>}
   * @public
   */
  m_getData__() {
    return this.f_data__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @override
   * @return {DataTable<C_T>}
   * @public
   */
  m_expand__() {
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_remove__java_lang_String("table-condensed");
    this.f_condensed__org_dominokit_domino_ui_datatable_DataTable_ = false;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_condense__() {
    this.m_expand__();
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_add__java_lang_String("table-condensed");
    this.f_condensed__org_dominokit_domino_ui_datatable_DataTable_ = true;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_noHover__() {
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_remove__java_lang_String("table-hover");
    this.f_hoverable__org_dominokit_domino_ui_datatable_DataTable_ = false;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_hovered__() {
    this.m_noHover__();
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_add__java_lang_String("table-hover");
    this.f_hoverable__org_dominokit_domino_ui_datatable_DataTable_ = true;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_noBorder__() {
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_remove__java_lang_String("table-bordered");
    this.f_bordered__org_dominokit_domino_ui_datatable_DataTable_ = false;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_bordered__() {
    this.m_noBorder__();
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_add__java_lang_String("table-bordered");
    this.f_bordered__org_dominokit_domino_ui_datatable_DataTable_ = true;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_noStripes__() {
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_remove__java_lang_String("table-striped");
    this.f_striped__org_dominokit_domino_ui_datatable_DataTable_ = false;
    return this;
  }
  
  /**
   * @return {DataTable<C_T>}
   * @public
   */
  m_striped__() {
    this.m_noStripes__();
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_.m_style__().m_add__java_lang_String("table-striped");
    this.f_striped__org_dominokit_domino_ui_datatable_DataTable_ = true;
    return this;
  }
  
  /**
   * @return {DominoElement<HTMLTableElement>}
   * @public
   */
  m_tableElement__() {
    return this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {DominoElement<HTMLTableSectionElement>}
   * @public
   */
  m_bodyElement__() {
    return this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {DominoElement<HTMLTableSectionElement>}
   * @public
   */
  m_headerElement__() {
    return this.f_thead__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {TableConfig<C_T>}
   * @public
   */
  m_getTableConfig__() {
    return this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isCondensed__() {
    return this.f_condensed__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isHoverable__() {
    return this.f_hoverable__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isStriped__() {
    return this.f_striped__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isBordered__() {
    return this.f_bordered__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @param {LocalRowFilter<C_T>} rowFilter
   * @return {void}
   * @public
   */
  m_filterRows__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter(rowFilter) {
    this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<*> */ tableRow) =>{
      if (rowFilter.m_filter__org_dominokit_domino_ui_datatable_TableRow(tableRow)) {
        tableRow.m_style__().m_removeProperty__java_lang_String("display");
        tableRow.m_removeFlag__java_lang_String("data-table-row-filtered");
        tableRow.m_fireUpdate__();
      } else {
        tableRow.m_style__().m_setDisplay__java_lang_String("none");
        tableRow.m_setFlag__java_lang_String__java_lang_String("data-table-row-filtered", "true");
        tableRow.m_deselect__();
        tableRow.m_fireUpdate__();
      }
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_clearRowFilters__() {
    this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** TableRow<*> */ tableRow) =>{
      return Objects.m_nonNull__java_lang_Object(tableRow.m_getFlag__java_lang_String("data-table-row-filtered"));
    }))).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<*> */ tableRow$1$) =>{
      tableRow$1$.m_style__().m_removeProperty__java_lang_String("display");
      tableRow$1$.m_removeFlag__java_lang_String("data-table-row-filtered");
      tableRow$1$.m_fireUpdate__();
    })));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return /**@type {HTMLDivElement} */ ($Casts.$to(this.f_element__org_dominokit_domino_ui_datatable_DataTable_.m_asElement__(), HTMLDivElement_$Overlay));
  }
  
  /**
   * @override
   * @return {List<TableRow<C_T>>}
   * @public
   */
  m_getSelectedItems__() {
    return /**@type {List<TableRow<C_T>>} */ ($Casts.$to(this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** TableRow<*> */ arg0) =>{
      return arg0.m_isSelected__();
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<TableRow<C_T>, ?, List<TableRow<C_T>>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {List<C_T>}
   * @public
   */
  m_getSelectedRecords__() {
    return /**@type {List<C_T>} */ ($Casts.$to(/**@type {Stream<C_T>} */ (this.m_getSelectedItems__().m_stream__().m_map__java_util_function_Function(j_u_function_Function.$adapt(((/** TableRow<*> */ arg0) =>{
      return arg0.m_getRecord__();
    })))).m_collect__java_util_stream_Collector(/**@type {Collector<C_T, ?, List<C_T>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @override
   * @return {List<TableRow<C_T>>}
   * @public
   */
  m_getItems__() {
    return this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @param {TableRow<C_T>} source
   * @return {void}
   * @public
   */
  m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(source) {
    this.f_selectionChangeListeners__org_dominokit_domino_ui_datatable_DataTable_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** SelectionChangeListener<*> */ selectionChangeListener) =>{
      selectionChangeListener.m_onSelectionChanged__java_util_List__java_util_List(this.m_getSelectedItems__(), this.m_getSelectedRecords__());
    })));
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_selectAll__() {
    if (this.f_tableConfig__org_dominokit_domino_ui_datatable_DataTable_.m_isMultiSelect__() && !this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.isEmpty()) {
      this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<*> */ arg0) =>{
        arg0.m_select__();
      })));
      this.m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(/**@type {TableRow<C_T>} */ ($Casts.$to(this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.getAtIndex(0), TableRow)));
    }
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_deselectAll__() {
    if (!this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.isEmpty()) {
      this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** TableRow<*> */ arg0) =>{
        return arg0.m_isSelected__();
      }))).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableRow<*> */ arg0$1$) =>{
        arg0$1$.m_deselect__();
      })));
      this.m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(/**@type {TableRow<C_T>} */ ($Casts.$to(this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_.getAtIndex(0), TableRow)));
    }
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isSelectable__() {
    return this.f_selectable__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * @param {SelectionChangeListener<C_T>} selectionChangeListener
   * @return {void}
   * @public
   */
  m_addSelectionListener__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener(selectionChangeListener) {
    this.f_selectionChangeListeners__org_dominokit_domino_ui_datatable_DataTable_.add(selectionChangeListener);
  }
  
  /**
   * @param {SelectionChangeListener<C_T>} selectionChangeListener
   * @return {void}
   * @public
   */
  m_removeSelectionListener__org_dominokit_domino_ui_datatable_DataTable_SelectionChangeListener(selectionChangeListener) {
    this.f_selectionChangeListeners__org_dominokit_domino_ui_datatable_DataTable_.remove(selectionChangeListener);
  }
  
  /**
   * @param {?string} type
   * @param {TableEventListener} listener
   * @return {void}
   * @public
   */
  m_addTableEventListner__java_lang_String__org_dominokit_domino_ui_datatable_events_TableEventListener(type, listener) {
    if (!this.f_events__org_dominokit_domino_ui_datatable_DataTable_.containsKey(type)) {
      this.f_events__org_dominokit_domino_ui_datatable_DataTable_.put(type, /**@type {!ArrayList<TableEventListener>} */ (ArrayList.$create__()));
    }
    /**@type {List<TableEventListener>} */ ($Casts.$to(this.f_events__org_dominokit_domino_ui_datatable_DataTable_.get(type), List)).add(listener);
  }
  
  /**
   * @param {?string} type
   * @param {TableEventListener} listener
   * @return {void}
   * @public
   */
  m_removeTableListener__java_lang_String__org_dominokit_domino_ui_datatable_events_TableEventListener(type, listener) {
    if (this.f_events__org_dominokit_domino_ui_datatable_DataTable_.containsKey(type)) {
      /**@type {List<TableEventListener>} */ ($Casts.$to(this.f_events__org_dominokit_domino_ui_datatable_DataTable_.get(type), List)).remove(listener);
    }
  }
  
  /**
   * @param {TableEvent} tableEvent
   * @return {void}
   * @public
   */
  m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(tableEvent) {
    if (this.f_events__org_dominokit_domino_ui_datatable_DataTable_.containsKey(tableEvent.m_getType__())) {
      /**@type {List<TableEventListener>} */ ($Casts.$to(this.f_events__org_dominokit_domino_ui_datatable_DataTable_.get(tableEvent.m_getType__()), List)).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableEventListener */ listener) =>{
        listener.m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(tableEvent);
      })));
    }
    /**@type {List<TableEventListener>} */ ($Casts.$to(this.f_events__org_dominokit_domino_ui_datatable_DataTable_.get(DataTable.f_ANY__org_dominokit_domino_ui_datatable_DataTable), List)).m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** TableEventListener */ listener$1$) =>{
      listener$1$.m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(tableEvent);
    })));
  }
  
  /**
   * @return {SearchContext}
   * @public
   */
  m_getSearchContext__() {
    return this.f_searchContext__org_dominokit_domino_ui_datatable_DataTable_;
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {void}
   * @public
   */
  m_onSelectionChange__java_lang_Object(arg0) {
    this.m_onSelectionChange__org_dominokit_domino_ui_datatable_TableRow(/**@type {TableRow<C_T>} */ ($Casts.$to(arg0, TableRow)));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_DataTable() {
    this.f_element__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["table-responsive"], j_l_String)))));
    this.f_tableElement__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {DominoElement<HTMLTableElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_table__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["table", "table-hover", "table-striped"], j_l_String)))));
    this.f_tbody__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {DominoElement<HTMLTableSectionElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_tbody__()));
    this.f_thead__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {DominoElement<HTMLTableSectionElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_thead__()));
    this.f_data__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {!ArrayList<C_T>} */ (ArrayList.$create__());
    this.f_selectable__org_dominokit_domino_ui_datatable_DataTable_ = true;
    this.f_tableRows__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {!ArrayList<TableRow<C_T>>} */ (ArrayList.$create__());
    this.f_selectionChangeListeners__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {!ArrayList<SelectionChangeListener<C_T>>} */ (ArrayList.$create__());
    this.f_condensed__org_dominokit_domino_ui_datatable_DataTable_ = false;
    this.f_hoverable__org_dominokit_domino_ui_datatable_DataTable_ = true;
    this.f_striped__org_dominokit_domino_ui_datatable_DataTable_ = true;
    this.f_bordered__org_dominokit_domino_ui_datatable_DataTable_ = false;
    this.f_events__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {!HashMap<?string, List<TableEventListener>>} */ (HashMap.$create__());
    this.f_searchContext__org_dominokit_domino_ui_datatable_DataTable_ = /**@type {!SearchContext<C_T>} */ (SearchContext.$create__org_dominokit_domino_ui_datatable_DataTable(this));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DataTable.$clinit = (() =>{
    });
    DataTable.$loadModules();
    BaseDominoElement.$clinit();
    HasSelectionSupport.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DataTable;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DataTable);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLTableSectionElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    List = goog.module.get('java.util.List$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    j_u_function_Function = goog.module.get('java.util.function.Function$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    TableRow = goog.module.get('org.dominokit.domino.ui.datatable.TableRow$impl');
    TableDataUpdatedEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.TableDataUpdatedEvent$impl');
    SearchContext = goog.module.get('org.dominokit.domino.ui.datatable.model.SearchContext$impl');
    StoreDataChangeListener = goog.module.get('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DataTable, $Util.$makeClassName('org.dominokit.domino.ui.datatable.DataTable'));


/** @public {?string} @const */
DataTable.f_ANY__org_dominokit_domino_ui_datatable_DataTable = "*";


HasSelectionSupport.$markImplementor(DataTable);


exports = DataTable; 
//# sourceMappingURL=DataTable.js.map