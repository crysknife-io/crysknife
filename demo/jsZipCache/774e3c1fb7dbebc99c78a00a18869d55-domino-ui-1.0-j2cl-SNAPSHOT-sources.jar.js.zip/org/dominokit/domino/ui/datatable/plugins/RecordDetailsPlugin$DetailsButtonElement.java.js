/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$DetailsButtonElement.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _RowMetaObject = goog.require('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject');
const _IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement');
const _$Overlay = goog.require('elemental2.dom.Event.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _RecordDetailsPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin');
const _$LambdaAdaptor$30 = goog.require('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement.$LambdaAdaptor$30');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var DetailsButtonElement = goog.require('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement$impl');
exports = DetailsButtonElement;
 