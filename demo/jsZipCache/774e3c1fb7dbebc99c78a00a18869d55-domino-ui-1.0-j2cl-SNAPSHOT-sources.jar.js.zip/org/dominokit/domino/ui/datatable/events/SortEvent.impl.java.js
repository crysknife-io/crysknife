/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.SortEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.SortEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');

let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let SortDirection = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortDirection$impl');


/**
 * @template C_T
 * @implements {TableEvent}
  */
class SortEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {SortDirection} */
    this.f_sortDirection__org_dominokit_domino_ui_datatable_events_SortEvent_;
    /** @public {ColumnConfig<C_T>} */
    this.f_columnConfig__org_dominokit_domino_ui_datatable_events_SortEvent_;
  }
  
  /**
   * @template C_T
   * @param {SortDirection} sortDirection
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {!SortEvent<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_plugins_SortDirection__org_dominokit_domino_ui_datatable_ColumnConfig(sortDirection, columnConfig) {
    SortEvent.$clinit();
    let $instance = new SortEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_SortEvent__org_dominokit_domino_ui_datatable_plugins_SortDirection__org_dominokit_domino_ui_datatable_ColumnConfig(sortDirection, columnConfig);
    return $instance;
  }
  
  /**
   * @param {SortDirection} sortDirection
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_SortEvent__org_dominokit_domino_ui_datatable_plugins_SortDirection__org_dominokit_domino_ui_datatable_ColumnConfig(sortDirection, columnConfig) {
    this.$ctor__java_lang_Object__();
    this.f_sortDirection__org_dominokit_domino_ui_datatable_events_SortEvent_ = sortDirection;
    this.f_columnConfig__org_dominokit_domino_ui_datatable_events_SortEvent_ = columnConfig;
  }
  
  /**
   * @return {SortDirection}
   * @public
   */
  m_getSortDirection__() {
    return this.f_sortDirection__org_dominokit_domino_ui_datatable_events_SortEvent_;
  }
  
  /**
   * @return {ColumnConfig<C_T>}
   * @public
   */
  m_getColumnConfig__() {
    return this.f_columnConfig__org_dominokit_domino_ui_datatable_events_SortEvent_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return SortEvent.f_SORT_EVENT__org_dominokit_domino_ui_datatable_events_SortEvent;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SortEvent.$clinit = (() =>{
    });
    SortEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SortEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SortEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(SortEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.SortEvent'));


/** @public {?string} @const */
SortEvent.f_SORT_EVENT__org_dominokit_domino_ui_datatable_events_SortEvent = "table-sort";


TableEvent.$markImplementor(SortEvent);


exports = SortEvent; 
//# sourceMappingURL=SortEvent.js.map