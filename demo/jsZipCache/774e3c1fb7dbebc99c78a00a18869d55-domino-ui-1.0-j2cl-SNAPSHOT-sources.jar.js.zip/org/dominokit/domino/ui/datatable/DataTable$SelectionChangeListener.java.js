/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable$SelectionChangeListener.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _List = goog.require('java.util.List');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener.$LambdaAdaptor');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');


// Re-exports the implementation.
var SelectionChangeListener = goog.require('org.dominokit.domino.ui.datatable.DataTable.SelectionChangeListener$impl');
exports = SelectionChangeListener;
 