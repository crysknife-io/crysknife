/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.IntegerHeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.IntegerHeaderFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const DelayedHeaderFilterInput = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLInputElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let IntegerBox = goog.forwardDeclare('org.dominokit.domino.ui.forms.IntegerBox$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @extends {DelayedHeaderFilterInput<IntegerBox, C_T>}
  */
class IntegerHeaderFilter extends DelayedHeaderFilterInput {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {IntegerBox} */
    this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_;
  }
  
  /**
   * @template C_T
   * @return {!IntegerHeaderFilter<C_T>}
   * @public
   */
  static $create__() {
    IntegerHeaderFilter.$clinit();
    let $instance = new IntegerHeaderFilter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter__() {
    this.$ctor__org_dominokit_domino_ui_datatable_plugins_filter_header_DelayedHeaderFilterInput__();
  }
  
  /**
   * @template M_T
   * @return {IntegerHeaderFilter<M_T>}
   * @public
   */
  static m_create__() {
    IntegerHeaderFilter.$clinit();
    return /**@type {!IntegerHeaderFilter<*>} */ (IntegerHeaderFilter.$create__());
  }
  
  /**
   * @override
   * @return {HTMLInputElement}
   * @public
   */
  m_getInputElement__() {
    return /**@type {HTMLInputElement} */ ($Casts.$to(this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay));
  }
  
  /**
   * @override
   * @return {IntegerBox}
   * @public
   */
  m_createValueBox__() {
    this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_ = IntegerBox.m_create__();
    return this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_;
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEmpty__() {
    return this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_isEmpty__();
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getValue__() {
    return j_l_String.m_valueOf__java_lang_Object(this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_getValue__()) + "";
  }
  
  /**
   * @override
   * @return {FilterTypes}
   * @public
   */
  m_getType__() {
    return FilterTypes.f_INTEGER__org_dominokit_domino_ui_datatable_model_FilterTypes;
  }
  
  /**
   * @override
   * @return {void}
   * @public
   */
  m_clear__() {
    this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_pauseChangeHandlers__();
    this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_clear__();
    /**@type {HTMLInputElement} */ ($Casts.$to(this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_getInputElement__().m_asElement__(), $Overlay)).value = "";
    this.f_integerBox__org_dominokit_domino_ui_datatable_plugins_filter_header_IntegerHeaderFilter_.m_resumeChangeHandlers__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    IntegerHeaderFilter.$clinit = (() =>{
    });
    IntegerHeaderFilter.$loadModules();
    DelayedHeaderFilterInput.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof IntegerHeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, IntegerHeaderFilter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLInputElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    IntegerBox = goog.module.get('org.dominokit.domino.ui.forms.IntegerBox$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(IntegerHeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.filter.header.IntegerHeaderFilter'));




exports = IntegerHeaderFilter; 
//# sourceMappingURL=IntegerHeaderFilter.js.map