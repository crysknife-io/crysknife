/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.SearchFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.store.SearchFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _SearchEvent = goog.require('org.dominokit.domino.ui.datatable.events.SearchEvent');
const _$LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter.$LambdaAdaptor');


// Re-exports the implementation.
var SearchFilter = goog.require('org.dominokit.domino.ui.datatable.store.SearchFilter$impl');
exports = SearchFilter;
 