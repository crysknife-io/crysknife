/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.SearchContext.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.model.SearchContext$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let Collection = goog.forwardDeclare('java.util.Collection$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Predicate = goog.forwardDeclare('java.util.function.Predicate$impl');
let Collector = goog.forwardDeclare('java.util.stream.Collector$impl');
let Collectors = goog.forwardDeclare('java.util.stream.Collectors$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let SearchClearedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');
let SearchEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let Filter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Filter$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Objects = goog.forwardDeclare('vmbootstrap.Objects$impl');


/**
 * @template C_T
  */
class SearchContext extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {List<Filter>} */
    this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_;
    /** @public {DataTable<C_T>} */
    this.f_dataTable__org_dominokit_domino_ui_datatable_model_SearchContext_;
  }
  
  /**
   * @template C_T
   * @param {DataTable<C_T>} dataTable
   * @return {!SearchContext<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    SearchContext.$clinit();
    let $instance = new SearchContext();
    $instance.$ctor__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_DataTable(dataTable);
    return $instance;
  }
  
  /**
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_model_SearchContext();
    this.f_dataTable__org_dominokit_domino_ui_datatable_model_SearchContext_ = dataTable;
  }
  
  /**
   * @param {Filter} filter
   * @return {SearchContext}
   * @public
   */
  m_add__org_dominokit_domino_ui_datatable_model_Filter(filter) {
    if (this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.contains(filter)) {
      this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.remove(filter);
    }
    this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.add(filter);
    return this;
  }
  
  /**
   * @param {Filter} filter
   * @return {SearchContext}
   * @public
   */
  m_remove__org_dominokit_domino_ui_datatable_model_Filter(filter) {
    return this.m_remove__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(filter.m_getFieldName__(), filter.m_getCategory__());
  }
  
  /**
   * @param {?string} fieldName
   * @return {SearchContext}
   * @public
   */
  m_remove__java_lang_String(fieldName) {
    this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.removeAll(/**@type {Collection<*>} */ ($Casts.$to(this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ filter) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(filter.m_getFieldName__(), fieldName);
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Filter, ?, List<Filter>>} */ (Collectors.m_toList__())), Collection)));
    return this;
  }
  
  /**
   * @param {?string} fieldName
   * @param {Category} category
   * @return {SearchContext}
   * @public
   */
  m_remove__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(fieldName, category) {
    this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.removeAll(/**@type {Collection<*>} */ ($Casts.$to(this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ filter) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(filter.m_getFieldName__(), fieldName) && $Objects.m_equals__java_lang_Object__java_lang_Object(filter.m_getCategory__(), category);
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Filter, ?, List<Filter>>} */ (Collectors.m_toList__())), Collection)));
    return this;
  }
  
  /**
   * @param {Category} category
   * @return {SearchContext}
   * @public
   */
  m_removeByCategory__org_dominokit_domino_ui_datatable_model_Category(category) {
    let collect = /**@type {List<Filter>} */ ($Casts.$to(this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ filter) =>{
      return $Objects.m_equals__java_lang_Object__java_lang_Object(filter.m_getCategory__(), category);
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Filter, ?, List<Filter>>} */ (Collectors.m_toList__())), List));
    if (!collect.isEmpty()) {
      this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.removeAll(collect);
    }
    return this;
  }
  
  /**
   * @return {SearchContext}
   * @public
   */
  m_clear__() {
    this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.clear();
    this.f_dataTable__org_dominokit_domino_ui_datatable_model_SearchContext_.m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(SearchClearedEvent.$create__());
    return this;
  }
  
  /**
   * @param {?string} fieldName
   * @return {List<Filter>}
   * @public
   */
  m_get__java_lang_String(fieldName) {
    return /**@type {List<Filter>} */ ($Casts.$to(this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.m_stream__().m_filter__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ filter) =>{
      return j_l_String.m_equals__java_lang_String__java_lang_Object(filter.m_getFieldName__(), fieldName);
    }))).m_collect__java_util_stream_Collector(/**@type {Collector<Filter, ?, List<Filter>>} */ (Collectors.m_toList__())), List));
  }
  
  /**
   * @return {List<Filter>}
   * @public
   */
  m_listAll__() {
    return /**@type {!ArrayList<Filter>} */ (ArrayList.$create__java_util_Collection(this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_));
  }
  
  /**
   * @param {Filter} filter
   * @return {boolean}
   * @public
   */
  m_contains__org_dominokit_domino_ui_datatable_model_Filter(filter) {
    return this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_.m_stream__().m_anyMatch__java_util_function_Predicate(Predicate.$adapt(((/** Filter */ f) =>{
      return f.equals(filter);
    })));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_fireSearchEvent__() {
    this.f_dataTable__org_dominokit_domino_ui_datatable_model_SearchContext_.m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(SearchEvent.$create__java_util_List(this.m_listAll__()));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_model_SearchContext() {
    this.f_filters__org_dominokit_domino_ui_datatable_model_SearchContext_ = /**@type {!ArrayList<Filter>} */ (ArrayList.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SearchContext.$clinit = (() =>{
    });
    SearchContext.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SearchContext;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SearchContext);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Collection = goog.module.get('java.util.Collection$impl');
    List = goog.module.get('java.util.List$impl');
    Predicate = goog.module.get('java.util.function.Predicate$impl');
    Collectors = goog.module.get('java.util.stream.Collectors$impl');
    SearchClearedEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');
    SearchEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SearchEvent$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Objects = goog.module.get('vmbootstrap.Objects$impl');
  }
  
  
};

$Util.$setClassMetadata(SearchContext, $Util.$makeClassName('org.dominokit.domino.ui.datatable.model.SearchContext'));




exports = SearchContext; 
//# sourceMappingURL=SearchContext.js.map