/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.store.DataStore.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.store.DataStore');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener');
const _StoreDataChangeListener = goog.require('org.dominokit.domino.ui.datatable.store.StoreDataChangeListener');


// Re-exports the implementation.
var DataStore = goog.require('org.dominokit.domino.ui.datatable.store.DataStore$impl');
exports = DataStore;
 