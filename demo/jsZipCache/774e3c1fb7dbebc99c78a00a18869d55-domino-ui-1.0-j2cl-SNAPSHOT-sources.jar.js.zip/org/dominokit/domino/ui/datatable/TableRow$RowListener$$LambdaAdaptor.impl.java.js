/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableRow$RowListener$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.TableRow.RowListener.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const RowListener = goog.require('org.dominokit.domino.ui.datatable.TableRow.RowListener$impl');

let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @template C_RowListener_T
 * @implements {RowListener<C_RowListener_T>}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(TableRow<C_RowListener_T>):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(TableRow<C_RowListener_T>):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_TableRow_RowListener_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_TableRow_RowListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_TableRow_RowListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(TableRow<C_RowListener_T>):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_TableRow_RowListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_TableRow_RowListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_TableRow_RowListener_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {TableRow<C_RowListener_T>} arg0
   * @return {void}
   * @public
   */
  m_onChange__org_dominokit_domino_ui_datatable_TableRow(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_TableRow_RowListener_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.TableRow$RowListener$$LambdaAdaptor'));


RowListener.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=TableRow$RowListener$$LambdaAdaptor.js.map