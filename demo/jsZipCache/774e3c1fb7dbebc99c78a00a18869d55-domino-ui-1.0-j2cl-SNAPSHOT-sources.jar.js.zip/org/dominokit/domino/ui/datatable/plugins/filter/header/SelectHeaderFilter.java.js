/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.SelectHeaderFilter.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.SelectHeaderFilter');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _FilterTypes = goog.require('org.dominokit.domino.ui.datatable.model.FilterTypes');
const _SearchContext = goog.require('org.dominokit.domino.ui.datatable.model.SearchContext');
const _Select = goog.require('org.dominokit.domino.ui.forms.Select');
const _SelectionHandler = goog.require('org.dominokit.domino.ui.forms.Select.SelectionHandler');
const _SelectOption = goog.require('org.dominokit.domino.ui.forms.SelectOption');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var SelectHeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.SelectHeaderFilter$impl');
exports = SelectHeaderFilter;
 