/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.TableEventListener$$LambdaAdaptor.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.TableEventListener.$LambdaAdaptor$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEventListener = goog.require('org.dominokit.domino.ui.datatable.events.TableEventListener$impl');

let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');


/**
 * @implements {TableEventListener}
  */
class $LambdaAdaptor extends j_l_Object {
  /**
   * @param {?function(TableEvent):void} fn
   * @public
   */
  constructor(fn) {
    $LambdaAdaptor.$clinit();
    super();
    /** @public {?function(TableEvent):void} */
    this.f_$$fn__org_dominokit_domino_ui_datatable_events_TableEventListener_$LambdaAdaptor;
    this.$ctor__org_dominokit_domino_ui_datatable_events_TableEventListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_events_TableEventListener_$JsFunction(fn);
  }
  
  /**
   * @param {?function(TableEvent):void} fn
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_TableEventListener_$LambdaAdaptor__org_dominokit_domino_ui_datatable_events_TableEventListener_$JsFunction(fn) {
    this.$ctor__java_lang_Object__();
    this.f_$$fn__org_dominokit_domino_ui_datatable_events_TableEventListener_$LambdaAdaptor = fn;
  }
  
  /**
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    {
      let $function = this.f_$$fn__org_dominokit_domino_ui_datatable_events_TableEventListener_$LambdaAdaptor;
      $function(arg0);
    }
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    $LambdaAdaptor.$clinit = (() =>{
    });
    $LambdaAdaptor.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof $LambdaAdaptor;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, $LambdaAdaptor);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata($LambdaAdaptor, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.TableEventListener$$LambdaAdaptor'));


TableEventListener.$markImplementor($LambdaAdaptor);


exports = $LambdaAdaptor; 
//# sourceMappingURL=TableEventListener$$LambdaAdaptor.js.map