/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin$HeaderFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const IsElement = goog.require('org.jboss.gwt.elemento.core.IsElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let SearchContext = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.SearchContext$impl');


/**
 * @interface
 * @template C_HeaderFilter_T
 * @extends {IsElement<HTMLElement>}
 */
class HeaderFilter {
  /**
   * @abstract
   * @param {SearchContext<C_HeaderFilter_T>} searchContext
   * @param {ColumnConfig<C_HeaderFilter_T>} columnConfig
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_ColumnConfig(searchContext, columnConfig) {
  }
  
  /**
   * @abstract
   * @return {void}
   * @public
   */
  m_clear__() {
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    HeaderFilter.$clinit = (() =>{
    });
    HeaderFilter.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    IsElement.$markImplementor(classConstructor);
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter;
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadataForInterface(HeaderFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin$HeaderFilter'));


HeaderFilter.$markImplementor(/** @type {Function} */ (HeaderFilter));


exports = HeaderFilter; 
//# sourceMappingURL=ColumnHeaderFilterPlugin$HeaderFilter.js.map