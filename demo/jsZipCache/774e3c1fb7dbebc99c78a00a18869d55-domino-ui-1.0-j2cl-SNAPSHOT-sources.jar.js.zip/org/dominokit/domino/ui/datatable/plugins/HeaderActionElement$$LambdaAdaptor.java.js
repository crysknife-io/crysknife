/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$$LambdaAdaptor.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.$LambdaAdaptor');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement');
const _$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');


// Re-exports the implementation.
var $LambdaAdaptor = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement.$LambdaAdaptor$impl');
exports = $LambdaAdaptor;
 