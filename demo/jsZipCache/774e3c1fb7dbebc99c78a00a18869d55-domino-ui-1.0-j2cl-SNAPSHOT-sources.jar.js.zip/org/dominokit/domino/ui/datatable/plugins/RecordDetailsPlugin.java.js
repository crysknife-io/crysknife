/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin');
const _HTMLDivElement_$Overlay = goog.require('elemental2.dom.HTMLDivElement.$Overlay');
const _HTMLTableCellElement_$Overlay = goog.require('elemental2.dom.HTMLTableCellElement.$Overlay');
const _HTMLTableRowElement_$Overlay = goog.require('elemental2.dom.HTMLTableRowElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLTableSectionElement.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _CellRenderer = goog.require('org.dominokit.domino.ui.datatable.CellRenderer');
const _CellInfo = goog.require('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _DataTable = goog.require('org.dominokit.domino.ui.datatable.DataTable');
const _HeaderElement = goog.require('org.dominokit.domino.ui.datatable.HeaderElement');
const _TableRow = goog.require('org.dominokit.domino.ui.datatable.TableRow');
const _ExpandRecordEvent = goog.require('org.dominokit.domino.ui.datatable.events.ExpandRecordEvent');
const _TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent');
const _DetailsButtonElement = goog.require('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin.DetailsButtonElement');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Icons = goog.require('org.dominokit.domino.ui.icons.Icons');
const _ElementUtil = goog.require('org.dominokit.domino.ui.utils.ElementUtil');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _HtmlContentBuilder = goog.require('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var RecordDetailsPlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.RecordDetailsPlugin$impl');
exports = RecordDetailsPlugin;
 