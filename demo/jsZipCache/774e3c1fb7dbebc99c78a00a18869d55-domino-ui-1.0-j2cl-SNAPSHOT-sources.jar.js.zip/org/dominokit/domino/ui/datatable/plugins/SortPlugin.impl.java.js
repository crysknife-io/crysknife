/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.SortPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.SortPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let SortEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SortEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$32 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortPlugin.$LambdaAdaptor$32$impl');
let SortContainer = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.SortPlugin.SortContainer$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Styles = goog.forwardDeclare('org.dominokit.domino.ui.style.Styles$impl');
let EventType = goog.forwardDeclare('org.jboss.gwt.elemento.core.EventType$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class SortPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {SortContainer<C_T>} */
    this.f_currentContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin_;
  }
  
  /**
   * @template C_T
   * @return {!SortPlugin<C_T>}
   * @public
   */
  static $create__() {
    SortPlugin.$clinit();
    let $instance = new SortPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_SortPlugin__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_SortPlugin__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @param {ColumnConfig<C_T>} column
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(dataTable, column) {
    if (column.m_isSortable__()) {
      let sortContainer = /**@type {!SortContainer<C_T>} */ (SortContainer.$create__org_dominokit_domino_ui_datatable_plugins_SortPlugin__java_lang_String(this, column.m_getName__()));
      column.m_getHeadElement__().m_style__().m_add__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([Styles.f_cursor_pointer__org_dominokit_domino_ui_style_Styles, Styles.f_disable_selection__org_dominokit_domino_ui_style_Styles], j_l_String)));
      column.f_contextMenu__org_dominokit_domino_ui_datatable_ColumnConfig.appendChild(sortContainer.f_sortElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_);
      /**@type {Style<HTMLDivElement, IsElement<HTMLDivElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(column.f_contextMenu__org_dominokit_domino_ui_datatable_ColumnConfig)).m_setDisplay__java_lang_String("block");
      column.m_getHeadElement__().m_addEventListener__java_lang_String__elemental2_dom_EventListener(EventType.f_click__org_jboss_gwt_elemento_core_EventType.m_getName__(), new $LambdaAdaptor$32(((/** Event */ evt) =>{
        /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(sortContainer.f_sortElement__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_)).m_setProperty__java_lang_String__java_lang_String("right", "15px").m_setProperty__java_lang_String__java_lang_String("list-style", "none");
        sortContainer.m_clear__();
        if (Objects.m_isNull__java_lang_Object(this.f_currentContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin_)) {
          sortContainer.m_update__boolean(false);
        } else {
          this.f_currentContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin_.m_clear__();
          sortContainer.m_update__boolean(j_l_String.m_equals__java_lang_String__java_lang_Object(this.f_currentContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin_.f_columnName__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_, sortContainer.f_columnName__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_));
        }
        this.f_currentContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin_ = sortContainer;
        dataTable.m_fireTableEvent__org_dominokit_domino_ui_datatable_events_TableEvent(/**@type {!SortEvent<*>} */ (SortEvent.$create__org_dominokit_domino_ui_datatable_plugins_SortDirection__org_dominokit_domino_ui_datatable_ColumnConfig(this.f_currentContainer__org_dominokit_domino_ui_datatable_plugins_SortPlugin_.f_sortDirection__org_dominokit_domino_ui_datatable_plugins_SortPlugin_SortContainer_, column)));
      })));
    }
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    SortPlugin.$clinit = (() =>{
    });
    SortPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof SortPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, SortPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    SortEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SortEvent$impl');
    $LambdaAdaptor$32 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SortPlugin.$LambdaAdaptor$32$impl');
    SortContainer = goog.module.get('org.dominokit.domino.ui.datatable.plugins.SortPlugin.SortContainer$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Styles = goog.module.get('org.dominokit.domino.ui.style.Styles$impl');
    EventType = goog.module.get('org.jboss.gwt.elemento.core.EventType$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
  }
  
  
};

$Util.$setClassMetadata(SortPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.SortPlugin'));


DataTablePlugin.$markImplementor(SortPlugin);


exports = SortPlugin; 
//# sourceMappingURL=SortPlugin.js.map