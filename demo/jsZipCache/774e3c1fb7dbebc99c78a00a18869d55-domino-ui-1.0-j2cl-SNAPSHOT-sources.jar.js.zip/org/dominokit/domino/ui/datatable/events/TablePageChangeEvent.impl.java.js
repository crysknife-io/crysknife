/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.events.TablePageChangeEvent.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const TableEvent = goog.require('org.dominokit.domino.ui.datatable.events.TableEvent$impl');

let HasPagination = goog.forwardDeclare('org.dominokit.domino.ui.pagination.HasPagination$impl');


/**
 * @implements {TableEvent}
  */
class TablePageChangeEvent extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {number} */
    this.f_page__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent_ = 0;
    /** @public {HasPagination} */
    this.f_pagination__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent_;
  }
  
  /**
   * @param {number} page
   * @param {HasPagination} pagination
   * @return {!TablePageChangeEvent}
   * @public
   */
  static $create__int__org_dominokit_domino_ui_pagination_HasPagination(page, pagination) {
    TablePageChangeEvent.$clinit();
    let $instance = new TablePageChangeEvent();
    $instance.$ctor__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent__int__org_dominokit_domino_ui_pagination_HasPagination(page, pagination);
    return $instance;
  }
  
  /**
   * @param {number} page
   * @param {HasPagination} pagination
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent__int__org_dominokit_domino_ui_pagination_HasPagination(page, pagination) {
    this.$ctor__java_lang_Object__();
    this.f_page__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent_ = page;
    this.f_pagination__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent_ = pagination;
  }
  
  /**
   * @return {number}
   * @public
   */
  m_getPage__() {
    return this.f_page__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent_;
  }
  
  /**
   * @return {HasPagination}
   * @public
   */
  m_getPagination__() {
    return this.f_pagination__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent_;
  }
  
  /**
   * @override
   * @return {?string}
   * @public
   */
  m_getType__() {
    return TablePageChangeEvent.f_PAGINATION_EVENT__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    TablePageChangeEvent.$clinit = (() =>{
    });
    TablePageChangeEvent.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof TablePageChangeEvent;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, TablePageChangeEvent);
  }
  
  /**
   * @public
   */
  static $loadModules() {
  }
  
  
};

$Util.$setClassMetadata(TablePageChangeEvent, $Util.$makeClassName('org.dominokit.domino.ui.datatable.events.TablePageChangeEvent'));


/** @public {?string} @const */
TablePageChangeEvent.f_PAGINATION_EVENT__org_dominokit_domino_ui_datatable_events_TablePageChangeEvent = "table-page-change";


TableEvent.$markImplementor(TablePageChangeEvent);


exports = TablePageChangeEvent; 
//# sourceMappingURL=TablePageChangeEvent.js.map