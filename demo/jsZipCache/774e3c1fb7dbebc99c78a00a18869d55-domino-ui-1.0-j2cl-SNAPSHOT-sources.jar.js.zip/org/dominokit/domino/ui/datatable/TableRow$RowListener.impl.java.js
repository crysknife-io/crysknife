/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableRow$RowListener.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.TableRow.RowListener$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow.RowListener.$LambdaAdaptor$impl');


/**
 * @interface
 * @template C_RowListener_T
 */
class RowListener {
  /**
   * @abstract
   * @param {TableRow<C_RowListener_T>} tableRow
   * @return {void}
   * @public
   */
  m_onChange__org_dominokit_domino_ui_datatable_TableRow(tableRow) {
  }
  
  /**
   * @template C_RowListener_T
   * @param {?function(TableRow<C_RowListener_T>):void} fn
   * @return {RowListener<C_RowListener_T>}
   * @public
   */
  static $adapt(fn) {
    RowListener.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RowListener.$clinit = (() =>{
    });
    RowListener.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_TableRow_RowListener = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_TableRow_RowListener;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_TableRow_RowListener;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.TableRow.RowListener.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RowListener, $Util.$makeClassName('org.dominokit.domino.ui.datatable.TableRow$RowListener'));


RowListener.$markImplementor(/** @type {Function} */ (RowListener));


exports = RowListener; 
//# sourceMappingURL=TableRow$RowListener.js.map