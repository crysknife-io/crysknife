/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Document.$Overlay$impl');
let DomGlobal_$Overlay = goog.forwardDeclare('elemental2.dom.DomGlobal.$Overlay$impl');
let HTMLTableCellElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let CellRenderer = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer$impl');
let CellInfo = goog.forwardDeclare('org.dominokit.domino.ui.datatable.CellRenderer.CellInfo$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let CellStyler = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let MarkerColor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin.MarkerColor$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class RowMarkerPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {MarkerColor<C_T>} */
    this.f_markerColor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_;
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    dataTable.m_getTableConfig__().m_insertColumnFirst__org_dominokit_domino_ui_datatable_ColumnConfig(/**@type {ColumnConfig<C_T>} */ (ColumnConfig.m_create__java_lang_String("data-table-marker-cm")).m_setSortable__boolean(false).m_maxWidth__java_lang_String("3px").m_styleHeader__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(/**@type {CellStyler<C_T>} */ (CellStyler.$adapt(((/** HTMLTableCellElement */ element) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element)).m_setPadding__java_lang_String__boolean("0px", true).m_setWidth__java_lang_String__boolean("3px", true);
    })))).m_styleCell__org_dominokit_domino_ui_datatable_ColumnConfig_CellStyler(/**@type {CellStyler<C_T>} */ (CellStyler.$adapt(((/** HTMLTableCellElement */ element$1$) =>{
      /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element$1$)).m_setPadding__java_lang_String__boolean("0px", true).m_setWidth__java_lang_String__boolean("3px", true);
    })))).m_setCellRenderer__org_dominokit_domino_ui_datatable_CellRenderer(/**@type {CellRenderer<C_T>} */ (CellRenderer.$adapt(((/** CellInfo<*> */ cell) =>{
      let colorScheme = this.f_markerColor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_.m_getColorScheme__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell);
      if (Objects.m_nonNull__java_lang_Object(colorScheme)) {
        /**@type {Style<HTMLTableCellElement, IsElement<HTMLTableCellElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(cell.m_getElement__())).m_add__java_lang_String(this.f_markerColor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_.m_getColorScheme__org_dominokit_domino_ui_datatable_CellRenderer_CellInfo(cell).m_color__().m_getBackground__());
      }
      return $Overlay.m_createTextNode__elemental2_dom_Document__java_lang_String(DomGlobal_$Overlay.f_document__elemental2_dom_DomGlobal_$Overlay, "");
    })))));
  }
  
  /**
   * @template C_T
   * @param {MarkerColor<C_T>} markerColor
   * @return {!RowMarkerPlugin<C_T>}
   * @public
   */
  static $create__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor(markerColor) {
    RowMarkerPlugin.$clinit();
    let $instance = new RowMarkerPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor(markerColor);
    return $instance;
  }
  
  /**
   * @param {MarkerColor<C_T>} markerColor
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_MarkerColor(markerColor) {
    this.$ctor__java_lang_Object__();
    this.f_markerColor__org_dominokit_domino_ui_datatable_plugins_RowMarkerPlugin_ = markerColor;
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    DataTablePlugin.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RowMarkerPlugin.$clinit = (() =>{
    });
    RowMarkerPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof RowMarkerPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, RowMarkerPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.Document.$Overlay$impl');
    DomGlobal_$Overlay = goog.module.get('elemental2.dom.DomGlobal.$Overlay$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    CellRenderer = goog.module.get('org.dominokit.domino.ui.datatable.CellRenderer$impl');
    ColumnConfig = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
    CellStyler = goog.module.get('org.dominokit.domino.ui.datatable.ColumnConfig.CellStyler$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
  }
  
  
};

$Util.$setClassMetadata(RowMarkerPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.RowMarkerPlugin'));


DataTablePlugin.$markImplementor(RowMarkerPlugin);


exports = RowMarkerPlugin; 
//# sourceMappingURL=RowMarkerPlugin.js.map