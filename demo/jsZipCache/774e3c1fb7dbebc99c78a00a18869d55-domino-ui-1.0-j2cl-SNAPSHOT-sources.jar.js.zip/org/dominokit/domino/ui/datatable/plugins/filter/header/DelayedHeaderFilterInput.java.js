/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _j_l_Object = goog.require('java.lang.Object');
const _$Util = goog.require('nativebootstrap.Util');
const _HeaderFilter = goog.require('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _$Overlay = goog.require('elemental2.dom.HTMLInputElement.$Overlay');
const _Objects = goog.require('java.util.Objects');
const _ColumnConfig = goog.require('org.dominokit.domino.ui.datatable.ColumnConfig');
const _Category = goog.require('org.dominokit.domino.ui.datatable.model.Category');
const _Filter = goog.require('org.dominokit.domino.ui.datatable.model.Filter');
const _FilterTypes = goog.require('org.dominokit.domino.ui.datatable.model.FilterTypes');
const _SearchContext = goog.require('org.dominokit.domino.ui.datatable.model.SearchContext');
const _ValueBox = goog.require('org.dominokit.domino.ui.forms.ValueBox');
const _Style = goog.require('org.dominokit.domino.ui.style.Style');
const _StyleEditor = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement.StyleEditor');
const _DelayedTextInput = goog.require('org.dominokit.domino.ui.utils.DelayedTextInput');
const _DelayedAction = goog.require('org.dominokit.domino.ui.utils.DelayedTextInput.DelayedAction');


// Re-exports the implementation.
var DelayedHeaderFilterInput = goog.require('org.dominokit.domino.ui.datatable.plugins.filter.header.DelayedHeaderFilterInput$impl');
exports = DelayedHeaderFilterInput;
 