/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$ClearSearch.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.ClearSearch$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const HeaderActionElement = goog.require('org.dominokit.domino.ui.datatable.plugins.HeaderActionElement$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let HTMLAnchorElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLAnchorElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let $LambdaAdaptor$25 = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.ClearSearch.$LambdaAdaptor$25$impl');
let Icons = goog.forwardDeclare('org.dominokit.domino.ui.icons.Icons$impl');
let MdiIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.MdiIcon$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_ClearSearch_T
 * @implements {HeaderActionElement<C_ClearSearch_T>}
  */
class ClearSearch extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @template C_ClearSearch_T
   * @return {!ClearSearch<C_ClearSearch_T>}
   * @public
   */
  static $create__() {
    ClearSearch.$clinit();
    let $instance = new ClearSearch();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ClearSearch__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_HeaderBarPlugin_ClearSearch__() {
    this.$ctor__java_lang_Object__();
  }
  
  /**
   * @override
   * @param {DataTable<C_ClearSearch_T>} dataTable
   * @return {Node}
   * @public
   */
  m_asElement__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    let clearFiltersIcon = /**@type {MdiIcon} */ ($Casts.$to(/**@type {MdiIcon} */ ($Casts.$to(/**@type {MdiIcon} */ ($Casts.$to(Icons.f_MDI_ICONS__org_dominokit_domino_ui_icons_Icons.m_filter_remove_mdi__().m_setTooltip__java_lang_String("Clear filters"), MdiIcon)).m_size18__().m_clickable__(), MdiIcon)).m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$25(((/** Event */ evt) =>{
      dataTable.m_getSearchContext__().m_clear__().m_fireSearchEvent__();
    }))), MdiIcon));
    return /**@type {HtmlContentBuilder<HTMLAnchorElement>} */ ($Casts.$to(Elements.m_a__().m_add__org_jboss_gwt_elemento_core_IsElement(clearFiltersIcon), HtmlContentBuilder)).m_asElement__();
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {TableEvent} arg0
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(arg0) {
    HeaderActionElement.m_handleEvent__$default__org_dominokit_domino_ui_datatable_plugins_HeaderActionElement__org_dominokit_domino_ui_datatable_events_TableEvent(this, arg0);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ClearSearch.$clinit = (() =>{
    });
    ClearSearch.$loadModules();
    j_l_Object.$clinit();
    HeaderActionElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ClearSearch;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ClearSearch);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor$25 = goog.module.get('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin.ClearSearch.$LambdaAdaptor$25$impl');
    Icons = goog.module.get('org.dominokit.domino.ui.icons.Icons$impl');
    MdiIcon = goog.module.get('org.dominokit.domino.ui.icons.MdiIcon$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ClearSearch, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.HeaderBarPlugin$ClearSearch'));


HeaderActionElement.$markImplementor(ClearSearch);


exports = ClearSearch; 
//# sourceMappingURL=HeaderBarPlugin$ClearSearch.js.map