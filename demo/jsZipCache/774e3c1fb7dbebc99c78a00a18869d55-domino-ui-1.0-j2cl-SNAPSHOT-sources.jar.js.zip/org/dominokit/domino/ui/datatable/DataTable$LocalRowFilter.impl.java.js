/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.DataTable$LocalRowFilter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter.$LambdaAdaptor$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');


/**
 * @interface
 * @template C_LocalRowFilter_T
 */
class LocalRowFilter {
  /**
   * @abstract
   * @param {TableRow<C_LocalRowFilter_T>} tableRow
   * @return {boolean}
   * @public
   */
  m_filter__org_dominokit_domino_ui_datatable_TableRow(tableRow) {
  }
  
  /**
   * @template C_LocalRowFilter_T
   * @param {?function(TableRow<C_LocalRowFilter_T>):boolean} fn
   * @return {LocalRowFilter<C_LocalRowFilter_T>}
   * @public
   */
  static $adapt(fn) {
    LocalRowFilter.$clinit();
    return /**@type {!$LambdaAdaptor<*>} */ (new $LambdaAdaptor(fn));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    LocalRowFilter.$clinit = (() =>{
    });
    LocalRowFilter.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_DataTable_LocalRowFilter;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.DataTable.LocalRowFilter.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(LocalRowFilter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.DataTable$LocalRowFilter'));


LocalRowFilter.$markImplementor(/** @type {Function} */ (LocalRowFilter));


exports = LocalRowFilter; 
//# sourceMappingURL=DataTable$LocalRowFilter.js.map