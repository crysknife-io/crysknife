/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');
const DataTablePlugin = goog.require('org.dominokit.domino.ui.datatable.plugins.DataTablePlugin$impl');

let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let HashMap = goog.forwardDeclare('java.util.HashMap$impl');
let Map = goog.forwardDeclare('java.util.Map$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Consumer = goog.forwardDeclare('java.util.function.Consumer$impl');
let ColumnConfig = goog.forwardDeclare('org.dominokit.domino.ui.datatable.ColumnConfig$impl');
let DataTable = goog.forwardDeclare('org.dominokit.domino.ui.datatable.DataTable$impl');
let TableRow = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow$impl');
let SearchClearedEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');
let TableEvent = goog.forwardDeclare('org.dominokit.domino.ui.datatable.events.TableEvent$impl');
let HeaderFilter = goog.forwardDeclare('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @template C_T
 * @implements {DataTablePlugin<C_T>}
  */
class ColumnHeaderFilterPlugin extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {Map<?string, HeaderFilter>} */
    this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_;
  }
  
  /**
   * @template C_T
   * @return {!ColumnHeaderFilterPlugin<C_T>}
   * @public
   */
  static $create__() {
    ColumnHeaderFilterPlugin.$clinit();
    let $instance = new ColumnHeaderFilterPlugin();
    $instance.$ctor__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin__() {
    this.$ctor__java_lang_Object__();
    this.$init__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin();
  }
  
  /**
   * @template M_T
   * @return {ColumnHeaderFilterPlugin<M_T>}
   * @public
   */
  static m_create__() {
    ColumnHeaderFilterPlugin.$clinit();
    return /**@type {!ColumnHeaderFilterPlugin<*>} */ (ColumnHeaderFilterPlugin.$create__());
  }
  
  /**
   * @override
   * @param {DataTable<C_T>} dataTable
   * @return {void}
   * @public
   */
  m_onAfterAddHeaders__org_dominokit_domino_ui_datatable_DataTable(dataTable) {
    let tr = Elements.m_tr__();
    let tableConfig = dataTable.m_getTableConfig__();
    let columns = tableConfig.m_getColumns__();
    let thead = dataTable.m_headerElement__();
    thead.m_appendChild__elemental2_dom_Node(tr.m_asElement__());
    columns.m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** ColumnConfig<*> */ columnConfig) =>{
      let th = /**@type {HtmlContentBuilder<HTMLTableCellElement>} */ ($Casts.$to(Elements.m_th__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["table-cm-filter"], j_l_String))), HtmlContentBuilder));
      columnConfig.m_getHeaderStyler__().m_styleCell__elemental2_dom_HTMLTableCellElement(/**@type {HTMLTableCellElement} */ ($Casts.$to(th.m_asElement__(), $Overlay)));
      tr.m_add__org_jboss_gwt_elemento_core_IsElement(th);
      if (dataTable.m_getTableConfig__().m_isFixed__() || columnConfig.m_isFixed__()) {
        this.m_fixElementWidth__org_dominokit_domino_ui_datatable_ColumnConfig__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin(columnConfig, th.m_asElement__());
      }
      if (this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_.containsKey(columnConfig.m_getName__())) {
        /**@type {HeaderFilter} */ ($Casts.$to(this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_.get(columnConfig.m_getName__()), HeaderFilter)).m_init__org_dominokit_domino_ui_datatable_model_SearchContext__org_dominokit_domino_ui_datatable_ColumnConfig(dataTable.m_getSearchContext__(), columnConfig);
        th.m_add__org_jboss_gwt_elemento_core_IsElement(/**@type {IsElement} */ ($Casts.$to(this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_.get(columnConfig.m_getName__()), IsElement)));
      }
    })));
    dataTable.m_tableElement__().m_appendChild__org_jboss_gwt_elemento_core_IsElement(thead);
  }
  
  /**
   * @param {ColumnConfig<C_T>} column
   * @param {HTMLElement} element
   * @return {void}
   * @public
   */
  m_fixElementWidth__org_dominokit_domino_ui_datatable_ColumnConfig__elemental2_dom_HTMLElement_$p_org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin(column, element) {
    let fixedWidth = this.m_bestFitWidth__org_dominokit_domino_ui_datatable_ColumnConfig_$pp_org_dominokit_domino_ui_datatable_plugins(column);
    /**@type {Style<HTMLElement, IsElement<HTMLElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(element)).m_setWidth__java_lang_String(fixedWidth).m_setMinWidth__java_lang_String(fixedWidth).m_setMaxWidth__java_lang_String(fixedWidth).m_setProperty__java_lang_String__java_lang_String("overflow", "hidden").m_setProperty__java_lang_String__java_lang_String("text-overflow", "ellipsis").m_setProperty__java_lang_String__java_lang_String("white-space", "nowrap");
  }
  
  /**
   * @param {ColumnConfig<C_T>} columnConfig
   * @return {?string}
   * @public
   */
  m_bestFitWidth__org_dominokit_domino_ui_datatable_ColumnConfig_$pp_org_dominokit_domino_ui_datatable_plugins(columnConfig) {
    if (Objects.m_nonNull__java_lang_Object(columnConfig.m_getWidth__()) && !j_l_String.m_isEmpty__java_lang_String(columnConfig.m_getWidth__())) {
      return columnConfig.m_getWidth__();
    } else if (Objects.m_nonNull__java_lang_Object(columnConfig.m_getMinWidth__()) && !j_l_String.m_isEmpty__java_lang_String(columnConfig.m_getMinWidth__())) {
      return columnConfig.m_getMinWidth__();
    } else if (Objects.m_nonNull__java_lang_Object(columnConfig.m_getMaxWidth__()) && !j_l_String.m_isEmpty__java_lang_String(columnConfig.m_getMaxWidth__())) {
      return columnConfig.m_getMaxWidth__();
    } else {
      return "100px";
    }
  }
  
  /**
   * @param {?string} columnName
   * @param {HeaderFilter} headerFilter
   * @return {ColumnHeaderFilterPlugin<C_T>}
   * @public
   */
  m_addHeaderFilter__java_lang_String__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_HeaderFilter(columnName, headerFilter) {
    this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_.put(columnName, headerFilter);
    return this;
  }
  
  /**
   * @override
   * @param {TableEvent} event
   * @return {void}
   * @public
   */
  m_handleEvent__org_dominokit_domino_ui_datatable_events_TableEvent(event) {
    if (j_l_String.m_equals__java_lang_String__java_lang_Object(SearchClearedEvent.f_SEARCH_EVENT_CLEARED__org_dominokit_domino_ui_datatable_events_SearchClearedEvent, event.m_getType__())) {
      this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_.values().m_forEach__java_util_function_Consumer(Consumer.$adapt(((/** HeaderFilter */ arg0) =>{
        arg0.m_clear__();
      })));
    }
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_init__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_init__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onAfterAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onAfterAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onAllRowsAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onAllRowsAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddHeaders__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddHeaders__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddRow__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddRow__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBeforeAddTable__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBeforeAddTable__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @return {void}
   * @public
   */
  m_onBodyAdded__org_dominokit_domino_ui_datatable_DataTable(arg0) {
    DataTablePlugin.m_onBodyAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable(this, arg0);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {ColumnConfig<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onHeaderAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(arg0, arg1) {
    DataTablePlugin.m_onHeaderAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_ColumnConfig(this, arg0, arg1);
  }
  
  /**
   * Default method forwarding stub.
   * @override
   * @param {DataTable<C_T>} arg0
   * @param {TableRow<C_T>} arg1
   * @return {void}
   * @public
   */
  m_onRowAdded__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(arg0, arg1) {
    DataTablePlugin.m_onRowAdded__$default__org_dominokit_domino_ui_datatable_plugins_DataTablePlugin__org_dominokit_domino_ui_datatable_DataTable__org_dominokit_domino_ui_datatable_TableRow(this, arg0, arg1);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin() {
    this.f_headerFilters__org_dominokit_domino_ui_datatable_plugins_ColumnHeaderFilterPlugin_ = /**@type {!HashMap<?string, HeaderFilter>} */ (HashMap.$create__());
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ColumnHeaderFilterPlugin.$clinit = (() =>{
    });
    ColumnHeaderFilterPlugin.$loadModules();
    j_l_Object.$clinit();
    DataTablePlugin.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ColumnHeaderFilterPlugin;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ColumnHeaderFilterPlugin);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Overlay = goog.module.get('elemental2.dom.HTMLTableCellElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    HashMap = goog.module.get('java.util.HashMap$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    Consumer = goog.module.get('java.util.function.Consumer$impl');
    SearchClearedEvent = goog.module.get('org.dominokit.domino.ui.datatable.events.SearchClearedEvent$impl');
    HeaderFilter = goog.module.get('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin.HeaderFilter$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    IsElement = goog.module.get('org.jboss.gwt.elemento.core.IsElement$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ColumnHeaderFilterPlugin, $Util.$makeClassName('org.dominokit.domino.ui.datatable.plugins.ColumnHeaderFilterPlugin'));


DataTablePlugin.$markImplementor(ColumnHeaderFilterPlugin);


exports = ColumnHeaderFilterPlugin; 
//# sourceMappingURL=ColumnHeaderFilterPlugin.js.map