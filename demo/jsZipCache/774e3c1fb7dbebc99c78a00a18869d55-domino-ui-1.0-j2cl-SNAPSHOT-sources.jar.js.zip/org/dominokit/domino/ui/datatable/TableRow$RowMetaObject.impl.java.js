/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.TableRow$RowMetaObject.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject$impl');


const $Util = goog.require('nativebootstrap.Util$impl');

let $LambdaAdaptor = goog.forwardDeclare('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject.$LambdaAdaptor$impl');


/**
 * @interface
 */
class RowMetaObject {
  /**
   * @abstract
   * @return {?string}
   * @public
   */
  m_getKey__() {
  }
  
  /**
   * @param {?function():?string} fn
   * @return {RowMetaObject}
   * @public
   */
  static $adapt(fn) {
    RowMetaObject.$clinit();
    return new $LambdaAdaptor(fn);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    RowMetaObject.$clinit = (() =>{
    });
    RowMetaObject.$loadModules();
  }
  
  /**
   * @param {Function} classConstructor
   * @public
   */
  static $markImplementor(classConstructor) {
    /**
     * @public {boolean}
     */
    classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_TableRow_RowMetaObject = true;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance != null && !!instance.$implements__org_dominokit_domino_ui_datatable_TableRow_RowMetaObject;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return classConstructor != null && !!classConstructor.prototype.$implements__org_dominokit_domino_ui_datatable_TableRow_RowMetaObject;
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $LambdaAdaptor = goog.module.get('org.dominokit.domino.ui.datatable.TableRow.RowMetaObject.$LambdaAdaptor$impl');
  }
  
  
};

$Util.$setClassMetadataForInterface(RowMetaObject, $Util.$makeClassName('org.dominokit.domino.ui.datatable.TableRow$RowMetaObject'));


RowMetaObject.$markImplementor(/** @type {Function} */ (RowMetaObject));


exports = RowMetaObject; 
//# sourceMappingURL=TableRow$RowMetaObject.js.map