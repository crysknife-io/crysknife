/**
 * @fileoverview transpiled from org.dominokit.domino.ui.datatable.model.Filter.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.datatable.model.Filter$impl');


const j_l_Object = goog.require('java.lang.Object$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let ArrayList = goog.forwardDeclare('java.util.ArrayList$impl');
let List = goog.forwardDeclare('java.util.List$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let Category = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Category$impl');
let FilterTypes = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
let Operator = goog.forwardDeclare('org.dominokit.domino.ui.datatable.model.Operator$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


class Filter extends j_l_Object {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_fieldName__org_dominokit_domino_ui_datatable_model_Filter_;
    /** @public {FilterTypes} */
    this.f_type__org_dominokit_domino_ui_datatable_model_Filter_;
    /** @public {Operator} */
    this.f_operator__org_dominokit_domino_ui_datatable_model_Filter_;
    /** @public {List<?string>} */
    this.f_values__org_dominokit_domino_ui_datatable_model_Filter_;
    /** @public {Category} */
    this.f_category__org_dominokit_domino_ui_datatable_model_Filter_;
  }
  
  /**
   * @param {?string} field
   * @param {?string} value
   * @param {Category} category
   * @return {Filter}
   * @public
   */
  static m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category(field, value, category) {
    Filter.$clinit();
    let values = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
    values.add(value);
    return Filter.$create__java_lang_String__org_dominokit_domino_ui_datatable_model_FilterTypes__org_dominokit_domino_ui_datatable_model_Operator__java_util_List__org_dominokit_domino_ui_datatable_model_Category(field, FilterTypes.f_STRING__org_dominokit_domino_ui_datatable_model_FilterTypes, Operator.f_like__org_dominokit_domino_ui_datatable_model_Operator, values, category);
  }
  
  /**
   * @param {?string} field
   * @param {?string} value
   * @param {Category} category
   * @param {FilterTypes} type
   * @return {Filter}
   * @public
   */
  static m_create__java_lang_String__java_lang_String__org_dominokit_domino_ui_datatable_model_Category__org_dominokit_domino_ui_datatable_model_FilterTypes(field, value, category, type) {
    Filter.$clinit();
    let values = /**@type {!ArrayList<?string>} */ (ArrayList.$create__());
    values.add(value);
    return Filter.$create__java_lang_String__org_dominokit_domino_ui_datatable_model_FilterTypes__org_dominokit_domino_ui_datatable_model_Operator__java_util_List__org_dominokit_domino_ui_datatable_model_Category(field, type, Operator.f_like__org_dominokit_domino_ui_datatable_model_Operator, values, category);
  }
  
  /**
   * @param {Filter} filter
   * @return {List<Filter>}
   * @public
   */
  static m_initListWith__org_dominokit_domino_ui_datatable_model_Filter(filter) {
    Filter.$clinit();
    let filters = /**@type {!ArrayList<Filter>} */ (ArrayList.$create__());
    filters.add(filter);
    return filters;
  }
  
  /**
   * @param {?string} fieldName
   * @param {FilterTypes} type
   * @param {Operator} operator
   * @param {List<?string>} values
   * @param {Category} category
   * @return {!Filter}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_datatable_model_FilterTypes__org_dominokit_domino_ui_datatable_model_Operator__java_util_List__org_dominokit_domino_ui_datatable_model_Category(fieldName, type, operator, values, category) {
    Filter.$clinit();
    let $instance = new Filter();
    $instance.$ctor__org_dominokit_domino_ui_datatable_model_Filter__java_lang_String__org_dominokit_domino_ui_datatable_model_FilterTypes__org_dominokit_domino_ui_datatable_model_Operator__java_util_List__org_dominokit_domino_ui_datatable_model_Category(fieldName, type, operator, values, category);
    return $instance;
  }
  
  /**
   * @param {?string} fieldName
   * @param {FilterTypes} type
   * @param {Operator} operator
   * @param {List<?string>} values
   * @param {Category} category
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_datatable_model_Filter__java_lang_String__org_dominokit_domino_ui_datatable_model_FilterTypes__org_dominokit_domino_ui_datatable_model_Operator__java_util_List__org_dominokit_domino_ui_datatable_model_Category(fieldName, type, operator, values, category) {
    this.$ctor__java_lang_Object__();
    this.f_fieldName__org_dominokit_domino_ui_datatable_model_Filter_ = fieldName;
    this.f_type__org_dominokit_domino_ui_datatable_model_Filter_ = type;
    this.f_operator__org_dominokit_domino_ui_datatable_model_Filter_ = operator;
    this.f_values__org_dominokit_domino_ui_datatable_model_Filter_ = values;
    this.f_category__org_dominokit_domino_ui_datatable_model_Filter_ = category;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getFieldName__() {
    return this.f_fieldName__org_dominokit_domino_ui_datatable_model_Filter_;
  }
  
  /**
   * @return {FilterTypes}
   * @public
   */
  m_getType__() {
    return this.f_type__org_dominokit_domino_ui_datatable_model_Filter_;
  }
  
  /**
   * @return {Operator}
   * @public
   */
  m_getOperator__() {
    return this.f_operator__org_dominokit_domino_ui_datatable_model_Filter_;
  }
  
  /**
   * @return {List<?string>}
   * @public
   */
  m_getValues__() {
    return this.f_values__org_dominokit_domino_ui_datatable_model_Filter_;
  }
  
  /**
   * @return {Category}
   * @public
   */
  m_getCategory__() {
    return this.f_category__org_dominokit_domino_ui_datatable_model_Filter_;
  }
  
  /**
   * @override
   * @param {*} o
   * @return {boolean}
   * @public
   */
  equals(o) {
    if ($Equality.$same(this, o)) {
      return true;
    }
    if (!Filter.$isInstance(o)) {
      return false;
    }
    let filter = /**@type {Filter} */ ($Casts.$to(o, Filter));
    return Objects.m_equals__java_lang_String__java_lang_String(this.m_getFieldName__(), filter.m_getFieldName__()) && $Equality.$same(this.m_getCategory__(), filter.m_getCategory__());
  }
  
  /**
   * @override
   * @return {number}
   * @public
   */
  hashCode() {
    return Objects.m_hash__arrayOf_java_lang_Object([this.m_getFieldName__(), this.m_getCategory__()]);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Filter.$clinit = (() =>{
    });
    Filter.$loadModules();
    j_l_Object.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Filter;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Filter);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    ArrayList = goog.module.get('java.util.ArrayList$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    FilterTypes = goog.module.get('org.dominokit.domino.ui.datatable.model.FilterTypes$impl');
    Operator = goog.module.get('org.dominokit.domino.ui.datatable.model.Operator$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Filter, $Util.$makeClassName('org.dominokit.domino.ui.datatable.model.Filter'));




exports = Filter; 
//# sourceMappingURL=Filter.js.map