/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.ButtonSize.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.ButtonSize$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<ButtonSize>}
  */
class ButtonSize extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {?string} */
    this.f_style__org_dominokit_domino_ui_button_ButtonSize_;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {!ButtonSize}
   * @public
   */
  static $create__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    let $instance = new ButtonSize();
    $instance.$ctor__org_dominokit_domino_ui_button_ButtonSize__java_lang_String__int__java_lang_String($name, $ordinal, style);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @param {?string} style
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_ButtonSize__java_lang_String__int__java_lang_String($name, $ordinal, style) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
    this.f_style__org_dominokit_domino_ui_button_ButtonSize_ = style;
  }
  
  /**
   * @return {?string}
   * @public
   */
  m_getStyle__() {
    return this.f_style__org_dominokit_domino_ui_button_ButtonSize_;
  }
  
  /**
   * @param {string} name
   * @return {!ButtonSize}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    ButtonSize.$clinit();
    if ($Equality.$same(ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_, null)) {
      ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_ = $Enums.createMapFromValues(ButtonSize.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_);
  }
  
  /**
   * @return {!Array<!ButtonSize>}
   * @public
   */
  static m_values__() {
    ButtonSize.$clinit();
    return /**@type {!Array<ButtonSize>} */ ($Arrays.$init([ButtonSize.$f_LARGE__org_dominokit_domino_ui_button_ButtonSize, ButtonSize.$f_SMALL__org_dominokit_domino_ui_button_ButtonSize, ButtonSize.$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize], ButtonSize));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {ButtonSize} */ ($Casts.$to(arg0, ButtonSize)));
  }
  
  /**
   * @return {!ButtonSize}
   * @public
   */
  static get f_LARGE__org_dominokit_domino_ui_button_ButtonSize() {
    return (ButtonSize.$clinit(), ButtonSize.$f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
  }
  
  /**
   * @param {!ButtonSize} value
   * @return {void}
   * @public
   */
  static set f_LARGE__org_dominokit_domino_ui_button_ButtonSize(value) {
    (ButtonSize.$clinit(), ButtonSize.$f_LARGE__org_dominokit_domino_ui_button_ButtonSize = value);
  }
  
  /**
   * @return {!ButtonSize}
   * @public
   */
  static get f_SMALL__org_dominokit_domino_ui_button_ButtonSize() {
    return (ButtonSize.$clinit(), ButtonSize.$f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
  }
  
  /**
   * @param {!ButtonSize} value
   * @return {void}
   * @public
   */
  static set f_SMALL__org_dominokit_domino_ui_button_ButtonSize(value) {
    (ButtonSize.$clinit(), ButtonSize.$f_SMALL__org_dominokit_domino_ui_button_ButtonSize = value);
  }
  
  /**
   * @return {!ButtonSize}
   * @public
   */
  static get f_XSMALL__org_dominokit_domino_ui_button_ButtonSize() {
    return (ButtonSize.$clinit(), ButtonSize.$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
  }
  
  /**
   * @param {!ButtonSize} value
   * @return {void}
   * @public
   */
  static set f_XSMALL__org_dominokit_domino_ui_button_ButtonSize(value) {
    (ButtonSize.$clinit(), ButtonSize.$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize = value);
  }
  
  /**
   * @return {Map<?string, !ButtonSize>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_() {
    return (ButtonSize.$clinit(), ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_);
  }
  
  /**
   * @param {Map<?string, !ButtonSize>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_(value) {
    (ButtonSize.$clinit(), ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ButtonSize.$clinit = (() =>{
    });
    ButtonSize.$loadModules();
    Enum.$clinit();
    ButtonSize.$f_LARGE__org_dominokit_domino_ui_button_ButtonSize = ButtonSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("LARGE"), ButtonSize.$ordinal$f_LARGE__org_dominokit_domino_ui_button_ButtonSize, "lg");
    ButtonSize.$f_SMALL__org_dominokit_domino_ui_button_ButtonSize = ButtonSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("SMALL"), ButtonSize.$ordinal$f_SMALL__org_dominokit_domino_ui_button_ButtonSize, "sm");
    ButtonSize.$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize = ButtonSize.$create__java_lang_String__int__java_lang_String($Util.$makeEnumName("XSMALL"), ButtonSize.$ordinal$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize, "xs");
    ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonSize;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonSize);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(ButtonSize, $Util.$makeClassName('org.dominokit.domino.ui.button.ButtonSize'));


/** @private {!ButtonSize} */
ButtonSize.$f_LARGE__org_dominokit_domino_ui_button_ButtonSize;


/** @private {!ButtonSize} */
ButtonSize.$f_SMALL__org_dominokit_domino_ui_button_ButtonSize;


/** @private {!ButtonSize} */
ButtonSize.$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize;


/** @private {Map<?string, !ButtonSize>} */
ButtonSize.$f_namesToValuesMap__org_dominokit_domino_ui_button_ButtonSize_;


/** @public {number} @const */
ButtonSize.$ordinal$f_LARGE__org_dominokit_domino_ui_button_ButtonSize = 0;


/** @public {number} @const */
ButtonSize.$ordinal$f_SMALL__org_dominokit_domino_ui_button_ButtonSize = 1;


/** @public {number} @const */
ButtonSize.$ordinal$f_XSMALL__org_dominokit_domino_ui_button_ButtonSize = 2;




exports = ButtonSize; 
//# sourceMappingURL=ButtonSize.js.map