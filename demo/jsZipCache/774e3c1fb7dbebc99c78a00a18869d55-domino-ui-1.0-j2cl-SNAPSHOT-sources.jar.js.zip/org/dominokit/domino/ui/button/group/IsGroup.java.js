/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.IsGroup.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.group.IsGroup');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _Button = goog.require('org.dominokit.domino.ui.button.Button');
const _DropdownButton = goog.require('org.dominokit.domino.ui.button.DropdownButton');


// Re-exports the implementation.
var IsGroup = goog.require('org.dominokit.domino.ui.button.group.IsGroup$impl');
exports = IsGroup;
 