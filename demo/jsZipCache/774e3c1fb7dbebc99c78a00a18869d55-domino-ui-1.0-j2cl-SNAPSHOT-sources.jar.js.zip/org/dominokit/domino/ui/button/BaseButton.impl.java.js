/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.BaseButton.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.BaseButton$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const WavesElement = goog.require('org.dominokit.domino.ui.style.WavesElement$impl');
const HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground$impl');
const HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement$impl');
const HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent$impl');
const Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable$impl');
const Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLButtonElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let Node_$Overlay = goog.forwardDeclare('elemental2.dom.Node.$Overlay$impl');
let Text_$Overlay = goog.forwardDeclare('elemental2.dom.Text.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let ButtonSize = goog.forwardDeclare('org.dominokit.domino.ui.button.ButtonSize$impl');
let CircleSize = goog.forwardDeclare('org.dominokit.domino.ui.button.CircleSize$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let WaveStyle = goog.forwardDeclare('org.dominokit.domino.ui.style.WaveStyle$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let TextNode = goog.forwardDeclare('org.dominokit.domino.ui.utils.TextNode$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @abstract
 * @template C_B
 * @extends {WavesElement<HTMLElement, C_B>}
 * @implements {HasClickableElement}
 * @implements {Sizable<C_B>}
 * @implements {HasBackground<C_B>}
 * @implements {HasContent<C_B>}
 * @implements {Switchable<C_B>}
  */
class BaseButton extends WavesElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLButtonElement>} */
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton;
    /** @public {StyleType} */
    this.f_type__org_dominokit_domino_ui_button_BaseButton_;
    /** @public {Color} */
    this.f_background__org_dominokit_domino_ui_button_BaseButton_;
    /** @public {Color} */
    this.f_color__org_dominokit_domino_ui_button_BaseButton_;
    /** @public {ButtonSize} */
    this.f_size__org_dominokit_domino_ui_button_BaseButton_;
    /** @public {?string} */
    this.f_content__org_dominokit_domino_ui_button_BaseButton;
    /** @public {BaseIcon<?>} */
    this.f_icon__org_dominokit_domino_ui_button_BaseButton_;
    /** @public {HTMLElement} */
    this.f_textSpan__org_dominokit_domino_ui_button_BaseButton_;
    /** @public {Text} */
    this.f_textElement__org_dominokit_domino_ui_button_BaseButton_;
  }
  
  /**
   * Initialization from constructor 'BaseButton()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_BaseButton__() {
    this.$ctor__org_dominokit_domino_ui_style_WavesElement__();
    this.$init__org_dominokit_domino_ui_button_BaseButton();
  }
  
  /**
   * Initialization from constructor 'BaseButton(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String(content) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__();
    this.m_setContent__java_lang_String(content);
  }
  
  /**
   * Initialization from constructor 'BaseButton(BaseIcon)'.
   * @param {BaseIcon} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_BaseButton__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__();
    this.m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(icon);
  }
  
  /**
   * Initialization from constructor 'BaseButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String(content);
    this.m_setButtonType__org_dominokit_domino_ui_style_StyleType(type);
  }
  
  /**
   * Initialization from constructor 'BaseButton(BaseIcon, StyleType)'.
   * @param {BaseIcon} icon
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_BaseButton__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__org_dominokit_domino_ui_icons_BaseIcon(icon);
    this.m_setButtonType__org_dominokit_domino_ui_style_StyleType(type);
  }
  
  /**
   * Initialization from constructor 'BaseButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String(content);
    this.m_setBackground__org_dominokit_domino_ui_style_Color(background);
  }
  
  /**
   * @override
   * @param {?string} content
   * @return {C_B}
   * @public
   */
  m_setContent__java_lang_String(content) {
    this.f_content__org_dominokit_domino_ui_button_BaseButton = content;
    this.f_textElement__org_dominokit_domino_ui_button_BaseButton_.textContent = content;
    if (Objects.m_isNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_button_BaseButton_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_appendChild__elemental2_dom_Node(this.f_textElement__org_dominokit_domino_ui_button_BaseButton_);
    } else {
      this.f_textSpan__org_dominokit_domino_ui_button_BaseButton_.appendChild(this.f_textElement__org_dominokit_domino_ui_button_BaseButton_);
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_appendChild__elemental2_dom_Node(this.f_textSpan__org_dominokit_domino_ui_button_BaseButton_);
    }
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @param {?string} text
   * @return {C_B}
   * @public
   */
  m_setTextContent__java_lang_String(text) {
    this.m_setContent__java_lang_String(text);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @param {ButtonSize} size
   * @return {C_B}
   * @public
   */
  m_setSize__org_dominokit_domino_ui_button_ButtonSize(size) {
    if (Objects.m_nonNull__java_lang_Object(this.f_size__org_dominokit_domino_ui_button_BaseButton_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_remove__java_lang_String("btn-" + j_l_String.m_valueOf__java_lang_Object(this.f_size__org_dominokit_domino_ui_button_BaseButton_.m_getStyle__()));
    }
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String("btn-" + j_l_String.m_valueOf__java_lang_Object(size.m_getStyle__()));
    this.f_size__org_dominokit_domino_ui_button_BaseButton_ = size;
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @param {boolean} block
   * @return {C_B}
   * @public
   */
  m_setBlock__boolean(block) {
    if (block) {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String("btn-block");
    } else {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_remove__java_lang_String("btn-block");
    }
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @param {Color} background
   * @return {C_B}
   * @public
   */
  m_setBackground__org_dominokit_domino_ui_style_Color(background) {
    if (Objects.m_nonNull__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_BaseButton_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_remove__java_lang_String("btn-" + j_l_String.m_valueOf__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_BaseButton_.m_getStyle__()));
    }
    if (Objects.m_nonNull__java_lang_Object(this.f_background__org_dominokit_domino_ui_button_BaseButton_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_remove__java_lang_String(this.f_background__org_dominokit_domino_ui_button_BaseButton_.m_getBackground__());
    }
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String(background.m_getBackground__());
    this.f_background__org_dominokit_domino_ui_button_BaseButton_ = background;
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @param {Color} color
   * @return {C_B}
   * @public
   */
  m_setColor__org_dominokit_domino_ui_style_Color(color) {
    if (Objects.m_nonNull__java_lang_Object(this.f_color__org_dominokit_domino_ui_button_BaseButton_)) {
      this.m_style__().m_remove__java_lang_String(this.f_color__org_dominokit_domino_ui_button_BaseButton_.m_getStyle__());
    }
    this.f_color__org_dominokit_domino_ui_button_BaseButton_ = color;
    this.m_style__().m_add__java_lang_String(this.f_color__org_dominokit_domino_ui_button_BaseButton_.m_getStyle__());
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @param {StyleType} type
   * @return {C_B}
   * @public
   */
  m_setButtonType__org_dominokit_domino_ui_style_StyleType(type) {
    if (Objects.m_nonNull__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_BaseButton_)) {
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_remove__java_lang_String("btn-" + j_l_String.m_valueOf__java_lang_Object(this.f_type__org_dominokit_domino_ui_button_BaseButton_.m_getStyle__()));
    }
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String("btn-" + j_l_String.m_valueOf__java_lang_Object(type.m_getStyle__()));
    this.f_type__org_dominokit_domino_ui_button_BaseButton_ = type;
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @return {C_B}
   * @public
   */
  m_disable__() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_setAttribute__java_lang_String__java_lang_String(BaseButton.f_DISABLED__org_dominokit_domino_ui_button_BaseButton_, BaseButton.f_DISABLED__org_dominokit_domino_ui_button_BaseButton_);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @return {C_B}
   * @public
   */
  m_enable__() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_removeAttribute__java_lang_String(BaseButton.f_DISABLED__org_dominokit_domino_ui_button_BaseButton_);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @return {boolean}
   * @public
   */
  m_isEnabled__() {
    return !this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_hasAttribute__java_lang_String(BaseButton.f_DISABLED__org_dominokit_domino_ui_button_BaseButton_);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_getClickableElement__() {
    return this.m_asElement__();
  }
  
  /**
   * @param {Node} node
   * @return {C_B}
   * @public
   * @deprecated
   */
  m_appendContent__elemental2_dom_Node(node) {
    return /**@type {C_B} */ ($Casts.$to(this.m_appendChild__elemental2_dom_Node(node), BaseButton));
  }
  
  /**
   * @override
   * @return {C_B}
   * @public
   */
  m_large__() {
    this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @return {C_B}
   * @public
   */
  m_small__() {
    this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @override
   * @return {C_B}
   * @public
   */
  m_xSmall__() {
    this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @return {C_B}
   * @public
   */
  m_block__() {
    this.m_setBlock__boolean(true);
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @return {C_B}
   * @public
   */
  m_linkify__() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String("btn-link");
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @return {C_B}
   * @public
   */
  m_deLinkify__() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_remove__java_lang_String("btn-link");
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @param {CircleSize} size
   * @return {C_B}
   * @public
   */
  m_circle__org_dominokit_domino_ui_button_CircleSize(size) {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String(size.m_getStyle__());
    this.m_applyCircleWaves___$p_org_dominokit_domino_ui_button_BaseButton();
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {C_B}
   * @public
   */
  m_setIcon__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    if (Objects.m_nonNull__java_lang_Object(this.f_icon__org_dominokit_domino_ui_button_BaseButton_)) {
      this.f_icon__org_dominokit_domino_ui_button_BaseButton_.m_setTextContent__java_lang_String(icon.m_getName__());
    } else {
      if (Objects.m_nonNull__java_lang_Object(this.f_content__org_dominokit_domino_ui_button_BaseButton) && !j_l_String.m_isEmpty__java_lang_String(this.f_content__org_dominokit_domino_ui_button_BaseButton)) {
        this.f_textSpan__org_dominokit_domino_ui_button_BaseButton_.appendChild(this.f_textElement__org_dominokit_domino_ui_button_BaseButton_);
        this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_appendChild__elemental2_dom_Node(this.f_textSpan__org_dominokit_domino_ui_button_BaseButton_.appendChild(this.f_textElement__org_dominokit_domino_ui_button_BaseButton_));
      }
      this.f_icon__org_dominokit_domino_ui_button_BaseButton_ = icon;
      this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_appendChild__org_jboss_gwt_elemento_core_IsElement(this.f_icon__org_dominokit_domino_ui_button_BaseButton_);
    }
    return /**@type {C_B} */ ($Casts.$to(this, BaseButton));
  }
  
  /**
   * @return {void}
   * @public
   */
  m_applyCircleWaves___$p_org_dominokit_domino_ui_button_BaseButton() {
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_CIRCLE__org_dominokit_domino_ui_style_WaveStyle);
    this.m_applyWaveStyle__org_dominokit_domino_ui_style_WaveStyle(WaveStyle.f_FLOAT__org_dominokit_domino_ui_style_WaveStyle);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_BaseButton() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton = /**@type {DominoElement<HTMLButtonElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(Elements.m_button__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["btn"], j_l_String)))));
    this.f_textSpan__org_dominokit_domino_ui_button_BaseButton_ = Elements.m_span__().m_asElement__();
    this.f_textElement__org_dominokit_domino_ui_button_BaseButton_ = TextNode.m_empty__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    BaseButton.$clinit = (() =>{
    });
    BaseButton.$loadModules();
    WavesElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof BaseButton;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, BaseButton);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    ButtonSize = goog.module.get('org.dominokit.domino.ui.button.ButtonSize$impl');
    WaveStyle = goog.module.get('org.dominokit.domino.ui.style.WaveStyle$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    TextNode = goog.module.get('org.dominokit.domino.ui.utils.TextNode$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(BaseButton, $Util.$makeClassName('org.dominokit.domino.ui.button.BaseButton'));


/** @public {?string} @const */
BaseButton.f_DISABLED__org_dominokit_domino_ui_button_BaseButton_ = "disabled";


HasClickableElement.$markImplementor(BaseButton);
Sizable.$markImplementor(BaseButton);
HasBackground.$markImplementor(BaseButton);
HasContent.$markImplementor(BaseButton);
Switchable.$markImplementor(BaseButton);


exports = BaseButton; 
//# sourceMappingURL=BaseButton.js.map