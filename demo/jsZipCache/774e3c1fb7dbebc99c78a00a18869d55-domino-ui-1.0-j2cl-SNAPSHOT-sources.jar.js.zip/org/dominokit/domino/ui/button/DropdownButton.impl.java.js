/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.DropdownButton.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.DropdownButton$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseButton = goog.require('org.dominokit.domino.ui.button.BaseButton$impl');

let Event_$Overlay = goog.forwardDeclare('elemental2.dom.Event.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let $LambdaAdaptor$4 = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$4$impl');
let ButtonsGroup = goog.forwardDeclare('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
let DropDownMenu = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropDownMenu$impl');
let DropDownPosition = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropDownPosition$impl');
let DropdownAction = goog.forwardDeclare('org.dominokit.domino.ui.dropdown.DropdownAction$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let Color = goog.forwardDeclare('org.dominokit.domino.ui.style.Color$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseButton<DropdownButton>}
  */
class DropdownButton extends BaseButton {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLElement} */
    this.f_caret__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {ButtonsGroup} */
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_;
    /** @public {DropDownMenu} */
    this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {!DropdownButton}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    this.$init__org_dominokit_domino_ui_button_DropdownButton();
    this.m_initDropDown___$p_org_dominokit_domino_ui_button_DropdownButton();
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {!DropdownButton}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(String, Color)'.
   * @param {?string} content
   * @param {Color} background
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
    this.$init__org_dominokit_domino_ui_button_DropdownButton();
    this.m_initDropDown___$p_org_dominokit_domino_ui_button_DropdownButton();
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(String)'.
   * @param {?string} content
   * @return {!DropdownButton}
   * @public
   */
  static $create__java_lang_String(content) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__java_lang_String(content) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__java_lang_String(content);
    this.$init__org_dominokit_domino_ui_button_DropdownButton();
    this.m_initDropDown___$p_org_dominokit_domino_ui_button_DropdownButton();
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(BaseIcon, StyleType)'.
   * @param {BaseIcon<?>} icon
   * @param {StyleType} type
   * @return {!DropdownButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(BaseIcon, StyleType)'.
   * @param {BaseIcon<?>} icon
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type);
    this.$init__org_dominokit_domino_ui_button_DropdownButton();
    this.m_initDropDown___$p_org_dominokit_domino_ui_button_DropdownButton();
  }
  
  /**
   * Factory method corresponding to constructor 'DropdownButton(BaseIcon)'.
   * @param {BaseIcon<?>} icon
   * @return {!DropdownButton}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    let $instance = new DropdownButton();
    $instance.$ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_BaseIcon(icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'DropdownButton(BaseIcon)'.
   * @param {BaseIcon<?>} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_DropdownButton__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__org_dominokit_domino_ui_icons_BaseIcon(icon);
    this.$init__org_dominokit_domino_ui_button_DropdownButton();
    this.m_initDropDown___$p_org_dominokit_domino_ui_button_DropdownButton();
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_create__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.$create__java_lang_String(content);
  }
  
  /**
   * @param {?string} content
   * @param {Color} background
   * @return {DropdownButton}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background) {
    DropdownButton.$clinit();
    return DropdownButton.$create__java_lang_String__org_dominokit_domino_ui_style_Color(content, background);
  }
  
  /**
   * @param {?string} content
   * @param {StyleType} type
   * @return {DropdownButton}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    DropdownButton.$clinit();
    return DropdownButton.$create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createDefault__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createPrimary__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createSuccess__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createInfo__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createWarning__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {DropdownButton}
   * @public
   */
  static m_createDanger__java_lang_String(content) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {StyleType} type
   * @return {DropdownButton}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    DropdownButton.$clinit();
    return DropdownButton.$create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.$create__org_dominokit_domino_ui_icons_BaseIcon(icon);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createDefault__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createPrimary__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createSuccess__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createInfo__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createWarning__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {DropdownButton}
   * @public
   */
  static m_createDanger__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    DropdownButton.$clinit();
    return DropdownButton.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @return {void}
   * @public
   */
  m_initDropDown___$p_org_dominokit_domino_ui_button_DropdownButton() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String("btn-dropdown");
    this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_ = DropDownMenu.m_create__org_jboss_gwt_elemento_core_IsElement(this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_);
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.m_appendChild__elemental2_dom_Node(this.m_asDropDown___$p_org_dominokit_domino_ui_button_DropdownButton());
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_appendChild__elemental2_dom_Node(this.f_caret__org_dominokit_domino_ui_button_DropdownButton_);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_asDropDown___$p_org_dominokit_domino_ui_button_DropdownButton() {
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_style__().m_add__java_lang_String("dropdown-toggle");
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_setAttribute__java_lang_String__java_lang_String("data-toggle", "dropdown");
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_setAttribute__java_lang_String__boolean("aria-haspopup", true);
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_setAttribute__java_lang_String__boolean("aria-expanded", true);
    this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_setAttribute__java_lang_String__java_lang_String("type", "button");
    this.m_addClickListener__elemental2_dom_EventListener(new $LambdaAdaptor$4(((/** Event */ evt) =>{
      this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_.m_closeAllMenus__();
      this.m_open___$p_org_dominokit_domino_ui_button_DropdownButton();
      evt.stopPropagation();
    })));
    return this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  m_open___$p_org_dominokit_domino_ui_button_DropdownButton() {
    this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_.m_open__();
  }
  
  /**
   * @param {DropdownAction} action
   * @return {DropdownButton}
   * @public
   * @deprecated
   */
  m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(action) {
    return this.m_appendChild__org_dominokit_domino_ui_dropdown_DropdownAction(action);
  }
  
  /**
   * @param {DropdownAction} action
   * @return {DropdownButton}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_dropdown_DropdownAction(action) {
    this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_.m_addAction__org_dominokit_domino_ui_dropdown_DropdownAction(action);
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.m_asElement__();
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_separator__() {
    this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_.m_separator__();
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_hideCaret__() {
    if (this.m_isCaretAdded___$p_org_dominokit_domino_ui_button_DropdownButton()) {
      this.f_caret__org_dominokit_domino_ui_button_DropdownButton_.remove();
    }
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_showCaret__() {
    if (!this.m_isCaretAdded___$p_org_dominokit_domino_ui_button_DropdownButton()) {
      this.m_asElement__().appendChild(this.f_caret__org_dominokit_domino_ui_button_DropdownButton_);
    }
    return this;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isCaretAdded___$p_org_dominokit_domino_ui_button_DropdownButton() {
    return this.m_asElement__().contains(this.f_caret__org_dominokit_domino_ui_button_DropdownButton_);
  }
  
  /**
   * @override
   * @return {DropdownButton}
   * @public
   */
  m_linkify__() {
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.m_style__().m_add__java_lang_String("link");
    super.m_linkify__();
    return this;
  }
  
  /**
   * @return {DropdownButton}
   * @public
   */
  m_delinkify__() {
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_.m_style__().m_remove__java_lang_String("link");
    super.m_deLinkify__();
    return this;
  }
  
  /**
   * @param {DropDownPosition} position
   * @return {DropdownButton}
   * @public
   */
  m_setPosition__org_dominokit_domino_ui_dropdown_DropDownPosition(position) {
    this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_.m_setPosition__org_dominokit_domino_ui_dropdown_DropDownPosition(position);
    return this;
  }
  
  /**
   * @return {HTMLElement}
   * @public
   */
  m_getCaret__() {
    return this.f_caret__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * @return {DropDownMenu}
   * @public
   */
  m_getDropDownMenu__() {
    return this.f_dropDownMenu__org_dominokit_domino_ui_button_DropdownButton_;
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_DropdownButton() {
    this.f_caret__org_dominokit_domino_ui_button_DropdownButton_ = /**@type {HtmlContentBuilder<HTMLElement>} */ ($Casts.$to(Elements.m_span__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["caret"], j_l_String))), HtmlContentBuilder)).m_asElement__();
    this.f_groupElement__org_dominokit_domino_ui_button_DropdownButton_ = ButtonsGroup.m_create__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    DropdownButton.$clinit = (() =>{
    });
    DropdownButton.$loadModules();
    BaseButton.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof DropdownButton;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, DropdownButton);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    $LambdaAdaptor$4 = goog.module.get('org.dominokit.domino.ui.button.DropdownButton.$LambdaAdaptor$4$impl');
    ButtonsGroup = goog.module.get('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');
    DropDownMenu = goog.module.get('org.dominokit.domino.ui.dropdown.DropDownMenu$impl');
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(DropdownButton, $Util.$makeClassName('org.dominokit.domino.ui.button.DropdownButton'));




exports = DropdownButton; 
//# sourceMappingURL=DropdownButton.js.map