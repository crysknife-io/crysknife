/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.Button.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.Button$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseButton = goog.require('org.dominokit.domino.ui.button.BaseButton$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let BaseIcon = goog.forwardDeclare('org.dominokit.domino.ui.icons.BaseIcon$impl');
let StyleType = goog.forwardDeclare('org.dominokit.domino.ui.style.StyleType$impl');


/**
 * @extends {BaseButton<Button>}
  */
class Button extends BaseButton {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * Factory method corresponding to constructor 'Button()'.
   * @return {!Button}
   * @public
   */
  static $create__() {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__();
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button()'.
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__() {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * Factory method corresponding to constructor 'Button(String)'.
   * @param {?string} content
   * @return {!Button}
   * @public
   */
  static $create__java_lang_String(content) {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__java_lang_String(content);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button(String)'.
   * @param {?string} content
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__java_lang_String(content) {
    this.$ctor__org_dominokit_domino_ui_button_Button__();
    this.m_setContent__java_lang_String(content);
  }
  
  /**
   * Factory method corresponding to constructor 'Button(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {!Button}
   * @public
   */
  static $create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button(String, StyleType)'.
   * @param {?string} content
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type) {
    this.$ctor__org_dominokit_domino_ui_button_Button__java_lang_String(content);
    this.m_setButtonType__org_dominokit_domino_ui_style_StyleType(type);
  }
  
  /**
   * Factory method corresponding to constructor 'Button(BaseIcon)'.
   * @param {BaseIcon<?>} icon
   * @return {!Button}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__org_dominokit_domino_ui_icons_BaseIcon(icon);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button(BaseIcon)'.
   * @param {BaseIcon<?>} icon
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    this.$ctor__org_dominokit_domino_ui_button_BaseButton__org_dominokit_domino_ui_icons_BaseIcon(icon);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * Factory method corresponding to constructor 'Button(BaseIcon, StyleType)'.
   * @param {BaseIcon<?>} icon
   * @param {StyleType} type
   * @return {!Button}
   * @public
   */
  static $create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    Button.$clinit();
    let $instance = new Button();
    $instance.$ctor__org_dominokit_domino_ui_button_Button__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Button(BaseIcon, StyleType)'.
   * @param {BaseIcon<?>} icon
   * @param {StyleType} type
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_Button__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type) {
    this.$ctor__org_dominokit_domino_ui_button_Button__org_dominokit_domino_ui_icons_BaseIcon(icon);
    this.m_setButtonType__org_dominokit_domino_ui_style_StyleType(type);
  }
  
  /**
   * @param {?string} content
   * @param {StyleType} type
   * @return {Button}
   * @public
   */
  static m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, type) {
    Button.$clinit();
    return Button.$create__java_lang_String__org_dominokit_domino_ui_style_StyleType(content, type);
  }
  
  /**
   * @return {Button}
   * @public
   */
  static m_create__() {
    Button.$clinit();
    return Button.$create__();
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_create__java_lang_String(content) {
    Button.$clinit();
    return Button.$create__java_lang_String(content);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createDefault__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createPrimary__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createSuccess__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createInfo__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createWarning__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {?string} content
   * @return {Button}
   * @public
   */
  static m_createDanger__java_lang_String(content) {
    Button.$clinit();
    return Button.m_create__java_lang_String__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(content, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.$create__org_dominokit_domino_ui_icons_BaseIcon(icon);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @param {StyleType} type
   * @return {Button}
   * @public
   */
  static m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, type) {
    Button.$clinit();
    return Button.$create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType(icon, type);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_createDefault__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, StyleType.f_DEFAULT__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_createPrimary__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, StyleType.f_PRIMARY__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_createSuccess__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, StyleType.f_SUCCESS__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_createInfo__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, StyleType.f_INFO__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_createWarning__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, StyleType.f_WARNING__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @param {BaseIcon<?>} icon
   * @return {Button}
   * @public
   */
  static m_createDanger__org_dominokit_domino_ui_icons_BaseIcon(icon) {
    Button.$clinit();
    return Button.m_create__org_dominokit_domino_ui_icons_BaseIcon__org_dominokit_domino_ui_style_StyleType_$p_org_dominokit_domino_ui_button_Button(icon, StyleType.f_DANGER__org_dominokit_domino_ui_style_StyleType);
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_buttonElement__org_dominokit_domino_ui_button_BaseButton.m_asElement__();
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Button.$clinit = (() =>{
    });
    Button.$loadModules();
    BaseButton.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Button;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Button);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    StyleType = goog.module.get('org.dominokit.domino.ui.style.StyleType$impl');
  }
  
  
};

$Util.$setClassMetadata(Button, $Util.$makeClassName('org.dominokit.domino.ui.button.Button'));




exports = Button; 
//# sourceMappingURL=Button.js.map