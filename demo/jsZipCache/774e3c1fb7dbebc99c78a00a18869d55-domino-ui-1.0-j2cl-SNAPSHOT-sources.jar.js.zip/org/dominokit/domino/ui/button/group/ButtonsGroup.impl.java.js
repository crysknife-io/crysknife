/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.group.ButtonsGroup.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.button.group.ButtonsGroup$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const IsGroup = goog.require('org.dominokit.domino.ui.button.group.IsGroup$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');
const Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable$impl');

let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Objects = goog.forwardDeclare('java.util.Objects$impl');
let Button = goog.forwardDeclare('org.dominokit.domino.ui.button.Button$impl');
let ButtonSize = goog.forwardDeclare('org.dominokit.domino.ui.button.ButtonSize$impl');
let DropdownButton = goog.forwardDeclare('org.dominokit.domino.ui.button.DropdownButton$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLElement, ButtonsGroup>}
 * @implements {IsGroup<ButtonsGroup>}
 * @implements {Sizable<ButtonsGroup>}
  */
class ButtonsGroup extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {DominoElement<HTMLDivElement>} */
    this.f_groupElement__org_dominokit_domino_ui_button_group_ButtonsGroup_;
    /** @public {ButtonSize} */
    this.f_size__org_dominokit_domino_ui_button_group_ButtonsGroup_;
  }
  
  /**
   * @return {!ButtonsGroup}
   * @public
   */
  static $create__() {
    ButtonsGroup.$clinit();
    let $instance = new ButtonsGroup();
    $instance.$ctor__org_dominokit_domino_ui_button_group_ButtonsGroup__();
    return $instance;
  }
  
  /**
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_button_group_ButtonsGroup__() {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_button_group_ButtonsGroup();
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @return {ButtonsGroup}
   * @public
   */
  static m_create__() {
    ButtonsGroup.$clinit();
    return ButtonsGroup.$create__();
  }
  
  /**
   * @override
   * @param {Button} button
   * @return {ButtonsGroup}
   * @public
   * @deprecated
   */
  m_addButton__org_dominokit_domino_ui_button_Button(button) {
    return this.m_appendChild__org_dominokit_domino_ui_button_Button(button);
  }
  
  /**
   * @override
   * @param {DropdownButton} nestedDropDown
   * @return {ButtonsGroup}
   * @public
   * @deprecated
   */
  m_addDropDown__org_dominokit_domino_ui_button_DropdownButton(nestedDropDown) {
    return this.m_appendChild__org_dominokit_domino_ui_button_DropdownButton(nestedDropDown);
  }
  
  /**
   * @override
   * @param {Button} button
   * @return {ButtonsGroup}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_button_Button(button) {
    this.m_appendChild__elemental2_dom_Node(button.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @param {DropdownButton} dropDown
   * @return {ButtonsGroup}
   * @public
   */
  m_appendChild__org_dominokit_domino_ui_button_DropdownButton(dropDown) {
    this.m_appendChild__elemental2_dom_Node(dropDown.m_asElement__());
    return this;
  }
  
  /**
   * @override
   * @return {HTMLElement}
   * @public
   */
  m_asElement__() {
    return this.f_groupElement__org_dominokit_domino_ui_button_group_ButtonsGroup_.m_asElement__();
  }
  
  /**
   * @param {ButtonSize} size
   * @return {ButtonsGroup}
   * @public
   */
  m_setSize__org_dominokit_domino_ui_button_ButtonSize(size) {
    if (Objects.m_nonNull__java_lang_Object(this.f_size__org_dominokit_domino_ui_button_group_ButtonsGroup_)) {
      this.f_groupElement__org_dominokit_domino_ui_button_group_ButtonsGroup_.m_style__().m_remove__java_lang_String("btn-group-" + j_l_String.m_valueOf__java_lang_Object(this.f_size__org_dominokit_domino_ui_button_group_ButtonsGroup_.m_getStyle__()));
    }
    this.f_groupElement__org_dominokit_domino_ui_button_group_ButtonsGroup_.m_style__().m_add__java_lang_String("btn-group-" + j_l_String.m_valueOf__java_lang_Object(size.m_getStyle__()));
    this.f_size__org_dominokit_domino_ui_button_group_ButtonsGroup_ = size;
    return this;
  }
  
  /**
   * @override
   * @return {ButtonsGroup}
   * @public
   */
  m_verticalAlign__() {
    return this.m_switchClasses__java_lang_String__java_lang_String_$p_org_dominokit_domino_ui_button_group_ButtonsGroup(ButtonsGroup.f_BTN_GROUP__org_dominokit_domino_ui_button_group_ButtonsGroup, ButtonsGroup.f_BTN_GROUP_VERTICAL__org_dominokit_domino_ui_button_group_ButtonsGroup_);
  }
  
  /**
   * @override
   * @return {ButtonsGroup}
   * @public
   */
  m_horizontalAlign__() {
    return this.m_switchClasses__java_lang_String__java_lang_String_$p_org_dominokit_domino_ui_button_group_ButtonsGroup(ButtonsGroup.f_BTN_GROUP_VERTICAL__org_dominokit_domino_ui_button_group_ButtonsGroup_, ButtonsGroup.f_BTN_GROUP__org_dominokit_domino_ui_button_group_ButtonsGroup);
  }
  
  /**
   * @param {?string} toRemove
   * @param {?string} toAdd
   * @return {ButtonsGroup}
   * @public
   */
  m_switchClasses__java_lang_String__java_lang_String_$p_org_dominokit_domino_ui_button_group_ButtonsGroup(toRemove, toAdd) {
    this.f_groupElement__org_dominokit_domino_ui_button_group_ButtonsGroup_.m_style__().m_remove__java_lang_String(toRemove).m_add__java_lang_String(toAdd);
    return this;
  }
  
  /**
   * @override
   * @return {ButtonsGroup}
   * @public
   */
  m_large__() {
    return this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_LARGE__org_dominokit_domino_ui_button_ButtonSize);
  }
  
  /**
   * @override
   * @return {ButtonsGroup}
   * @public
   */
  m_small__() {
    return this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_SMALL__org_dominokit_domino_ui_button_ButtonSize);
  }
  
  /**
   * @override
   * @return {ButtonsGroup}
   * @public
   */
  m_xSmall__() {
    return this.m_setSize__org_dominokit_domino_ui_button_ButtonSize(ButtonSize.f_XSMALL__org_dominokit_domino_ui_button_ButtonSize);
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_button_group_ButtonsGroup() {
    this.f_groupElement__org_dominokit_domino_ui_button_group_ButtonsGroup_ = /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__org_jboss_gwt_elemento_core_IsElement(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init([ButtonsGroup.f_BTN_GROUP__org_dominokit_domino_ui_button_group_ButtonsGroup], j_l_String))), HtmlContentBuilder)).m_attr__java_lang_String__java_lang_String("role", "group")));
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    ButtonsGroup.$clinit = (() =>{
    });
    ButtonsGroup.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof ButtonsGroup;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, ButtonsGroup);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    j_l_String = goog.module.get('java.lang.String$impl');
    Objects = goog.module.get('java.util.Objects$impl');
    ButtonSize = goog.module.get('org.dominokit.domino.ui.button.ButtonSize$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(ButtonsGroup, $Util.$makeClassName('org.dominokit.domino.ui.button.group.ButtonsGroup'));


/** @public {?string} @const */
ButtonsGroup.f_BTN_GROUP__org_dominokit_domino_ui_button_group_ButtonsGroup = "btn-group";


/** @public {?string} @const */
ButtonsGroup.f_BTN_GROUP_VERTICAL__org_dominokit_domino_ui_button_group_ButtonsGroup_ = "btn-group-vertical";


IsGroup.$markImplementor(ButtonsGroup);
Sizable.$markImplementor(ButtonsGroup);


exports = ButtonsGroup; 
//# sourceMappingURL=ButtonsGroup.js.map