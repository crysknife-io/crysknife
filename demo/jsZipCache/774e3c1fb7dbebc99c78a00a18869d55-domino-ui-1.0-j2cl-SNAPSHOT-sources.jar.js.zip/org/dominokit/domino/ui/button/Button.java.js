/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.Button.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.Button');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _BaseButton = goog.require('org.dominokit.domino.ui.button.BaseButton');
const _$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');


// Re-exports the implementation.
var Button = goog.require('org.dominokit.domino.ui.button.Button$impl');
exports = Button;
 