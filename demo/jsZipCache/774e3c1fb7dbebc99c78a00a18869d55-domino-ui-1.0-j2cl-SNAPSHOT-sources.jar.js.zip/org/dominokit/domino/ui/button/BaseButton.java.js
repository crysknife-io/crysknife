/**
 * @fileoverview transpiled from org.dominokit.domino.ui.button.BaseButton.
 *
 * @suppress {extraRequire, lateProvide, unusedLocalVariables}
 */
goog.module('org.dominokit.domino.ui.button.BaseButton');


// Imports headers for both eager and lazy dependencies to ensure that
// all files are included in the dependency tree.
const _$Util = goog.require('nativebootstrap.Util');
const _WavesElement = goog.require('org.dominokit.domino.ui.style.WavesElement');
const _HasBackground = goog.require('org.dominokit.domino.ui.utils.HasBackground');
const _HasClickableElement = goog.require('org.dominokit.domino.ui.utils.HasClickableElement');
const _HasContent = goog.require('org.dominokit.domino.ui.utils.HasContent');
const _Sizable = goog.require('org.dominokit.domino.ui.utils.Sizable');
const _Switchable = goog.require('org.dominokit.domino.ui.utils.Switchable');
const _$Overlay = goog.require('elemental2.dom.HTMLButtonElement.$Overlay');
const _HTMLElement_$Overlay = goog.require('elemental2.dom.HTMLElement.$Overlay');
const _Node_$Overlay = goog.require('elemental2.dom.Node.$Overlay');
const _Text_$Overlay = goog.require('elemental2.dom.Text.$Overlay');
const _j_l_String = goog.require('java.lang.String');
const _Objects = goog.require('java.util.Objects');
const _ButtonSize = goog.require('org.dominokit.domino.ui.button.ButtonSize');
const _CircleSize = goog.require('org.dominokit.domino.ui.button.CircleSize');
const _BaseIcon = goog.require('org.dominokit.domino.ui.icons.BaseIcon');
const _Color = goog.require('org.dominokit.domino.ui.style.Color');
const _StyleType = goog.require('org.dominokit.domino.ui.style.StyleType');
const _WaveStyle = goog.require('org.dominokit.domino.ui.style.WaveStyle');
const _DominoElement = goog.require('org.dominokit.domino.ui.utils.DominoElement');
const _TextNode = goog.require('org.dominokit.domino.ui.utils.TextNode');
const _Elements = goog.require('org.jboss.gwt.elemento.core.Elements');
const _$Arrays = goog.require('vmbootstrap.Arrays');
const _$Casts = goog.require('vmbootstrap.Casts');


// Re-exports the implementation.
var BaseButton = goog.require('org.dominokit.domino.ui.button.BaseButton$impl');
exports = BaseButton;
 