/**
 * @fileoverview transpiled from org.dominokit.domino.ui.carousel.Slide.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.domino.ui.carousel.Slide$impl');


const $Util = goog.require('nativebootstrap.Util$impl');
const BaseDominoElement = goog.require('org.dominokit.domino.ui.utils.BaseDominoElement$impl');

let HTMLDivElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLDivElement.$Overlay$impl');
let HTMLHeadingElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
let $Overlay = goog.forwardDeclare('elemental2.dom.HTMLImageElement.$Overlay$impl');
let HTMLLIElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLLIElement.$Overlay$impl');
let HTMLParagraphElement_$Overlay = goog.forwardDeclare('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
let j_l_String = goog.forwardDeclare('java.lang.String$impl');
let Style = goog.forwardDeclare('org.dominokit.domino.ui.style.Style$impl');
let DominoElement = goog.forwardDeclare('org.dominokit.domino.ui.utils.DominoElement$impl');
let Elements = goog.forwardDeclare('org.jboss.gwt.elemento.core.Elements$impl');
let IsElement = goog.forwardDeclare('org.jboss.gwt.elemento.core.IsElement$impl');
let HtmlContentBuilder = goog.forwardDeclare('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');


/**
 * @extends {BaseDominoElement<HTMLDivElement, Slide>}
  */
class Slide extends BaseDominoElement {
  /**
   * @protected
   */
  constructor() {
    super();
    /** @public {HTMLLIElement} */
    this.f_indicatorElement__org_dominokit_domino_ui_carousel_Slide_;
    /** @public {HTMLHeadingElement} */
    this.f_slideLabelElement__org_dominokit_domino_ui_carousel_Slide_;
    /** @public {HTMLParagraphElement} */
    this.f_slideDescriptionElement__org_dominokit_domino_ui_carousel_Slide_;
    /** @public {HTMLDivElement} */
    this.f_captionElement__org_dominokit_domino_ui_carousel_Slide_;
    /** @public {HTMLDivElement} */
    this.f_slideElement__org_dominokit_domino_ui_carousel_Slide_;
    /** @public {HTMLImageElement} */
    this.f_imageElement__org_dominokit_domino_ui_carousel_Slide;
    /** @public {boolean} */
    this.f_active__org_dominokit_domino_ui_carousel_Slide_ = false;
  }
  
  /**
   * Factory method corresponding to constructor 'Slide(String)'.
   * @param {?string} imageSrc
   * @return {!Slide}
   * @public
   */
  static $create__java_lang_String(imageSrc) {
    Slide.$clinit();
    let $instance = new Slide();
    $instance.$ctor__org_dominokit_domino_ui_carousel_Slide__java_lang_String(imageSrc);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Slide(String)'.
   * @param {?string} imageSrc
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_carousel_Slide__java_lang_String(imageSrc) {
    this.$ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement(/**@type {HTMLImageElement} */ ($Casts.$to(Elements.m_img__java_lang_String(imageSrc).m_asElement__(), $Overlay)));
  }
  
  /**
   * Factory method corresponding to constructor 'Slide(HTMLImageElement)'.
   * @param {HTMLImageElement} image
   * @return {!Slide}
   * @public
   */
  static $create__elemental2_dom_HTMLImageElement(image) {
    Slide.$clinit();
    let $instance = new Slide();
    $instance.$ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement(image);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Slide(HTMLImageElement)'.
   * @param {HTMLImageElement} image
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement(image) {
    this.$ctor__org_dominokit_domino_ui_utils_BaseDominoElement__();
    this.$init__org_dominokit_domino_ui_carousel_Slide();
    this.f_imageElement__org_dominokit_domino_ui_carousel_Slide = image;
    this.f_slideElement__org_dominokit_domino_ui_carousel_Slide_.appendChild(image);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * Factory method corresponding to constructor 'Slide(String, String, String)'.
   * @param {?string} imageSrc
   * @param {?string} label
   * @param {?string} description
   * @return {!Slide}
   * @public
   */
  static $create__java_lang_String__java_lang_String__java_lang_String(imageSrc, label, description) {
    Slide.$clinit();
    let $instance = new Slide();
    $instance.$ctor__org_dominokit_domino_ui_carousel_Slide__java_lang_String__java_lang_String__java_lang_String(imageSrc, label, description);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Slide(String, String, String)'.
   * @param {?string} imageSrc
   * @param {?string} label
   * @param {?string} description
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_carousel_Slide__java_lang_String__java_lang_String__java_lang_String(imageSrc, label, description) {
    this.$ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement__java_lang_String__java_lang_String(/**@type {HTMLImageElement} */ ($Casts.$to(Elements.m_img__java_lang_String(imageSrc).m_asElement__(), $Overlay)), label, description);
  }
  
  /**
   * Factory method corresponding to constructor 'Slide(HTMLImageElement, String, String)'.
   * @param {HTMLImageElement} image
   * @param {?string} label
   * @param {?string} description
   * @return {!Slide}
   * @public
   */
  static $create__elemental2_dom_HTMLImageElement__java_lang_String__java_lang_String(image, label, description) {
    Slide.$clinit();
    let $instance = new Slide();
    $instance.$ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement__java_lang_String__java_lang_String(image, label, description);
    return $instance;
  }
  
  /**
   * Initialization from constructor 'Slide(HTMLImageElement, String, String)'.
   * @param {HTMLImageElement} image
   * @param {?string} label
   * @param {?string} description
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement__java_lang_String__java_lang_String(image, label, description) {
    this.$ctor__org_dominokit_domino_ui_carousel_Slide__elemental2_dom_HTMLImageElement(image);
    this.f_slideLabelElement__org_dominokit_domino_ui_carousel_Slide_.textContent = label;
    this.f_slideDescriptionElement__org_dominokit_domino_ui_carousel_Slide_.textContent = description;
    this.f_slideElement__org_dominokit_domino_ui_carousel_Slide_.appendChild(this.f_captionElement__org_dominokit_domino_ui_carousel_Slide_);
    this.m_init__org_jboss_gwt_elemento_core_IsElement(this);
  }
  
  /**
   * @param {?string} imageSrc
   * @return {Slide}
   * @public
   */
  static m_create__java_lang_String(imageSrc) {
    Slide.$clinit();
    return Slide.$create__java_lang_String(imageSrc);
  }
  
  /**
   * @param {?string} imageSrc
   * @param {?string} label
   * @param {?string} description
   * @return {Slide}
   * @public
   */
  static m_create__java_lang_String__java_lang_String__java_lang_String(imageSrc, label, description) {
    Slide.$clinit();
    return Slide.$create__java_lang_String__java_lang_String__java_lang_String(imageSrc, label, description);
  }
  
  /**
   * @param {HTMLImageElement} image
   * @return {Slide}
   * @public
   */
  static m_create__elemental2_dom_HTMLImageElement(image) {
    Slide.$clinit();
    return Slide.$create__elemental2_dom_HTMLImageElement(image);
  }
  
  /**
   * @param {HTMLImageElement} image
   * @param {?string} label
   * @param {?string} description
   * @return {Slide}
   * @public
   */
  static m_create__elemental2_dom_HTMLImageElement__java_lang_String__java_lang_String(image, label, description) {
    Slide.$clinit();
    return Slide.$create__elemental2_dom_HTMLImageElement__java_lang_String__java_lang_String(image, label, description);
  }
  
  /**
   * @return {DominoElement<HTMLLIElement>}
   * @public
   */
  m_getIndicatorElement__() {
    return /**@type {DominoElement<HTMLLIElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_indicatorElement__org_dominokit_domino_ui_carousel_Slide_));
  }
  
  /**
   * @override
   * @return {HTMLDivElement}
   * @public
   */
  m_asElement__() {
    return this.f_slideElement__org_dominokit_domino_ui_carousel_Slide_;
  }
  
  /**
   * @return {Slide}
   * @public
   */
  m_activate__() {
    this.f_active__org_dominokit_domino_ui_carousel_Slide_ = true;
    if (!/**@type {Style<HTMLLIElement, IsElement<HTMLLIElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_indicatorElement__org_dominokit_domino_ui_carousel_Slide_)).m_contains__java_lang_String("active")) {
      /**@type {Style<HTMLLIElement, IsElement<HTMLLIElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_indicatorElement__org_dominokit_domino_ui_carousel_Slide_)).m_add__java_lang_String("active");
    }
    if (!/**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this)).m_contains__java_lang_String("active")) {
      /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this)).m_add__java_lang_String("active");
    }
    return this;
  }
  
  /**
   * @return {Slide}
   * @public
   */
  m_deActivate__() {
    this.f_active__org_dominokit_domino_ui_carousel_Slide_ = false;
    /**@type {Style<HTMLLIElement, IsElement<HTMLLIElement>>} */ (Style.m_of__elemental2_dom_HTMLElement(this.f_indicatorElement__org_dominokit_domino_ui_carousel_Slide_)).m_remove__java_lang_String("active");
    /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this)).m_remove__java_lang_String("active");
    return this;
  }
  
  /**
   * @param {boolean} active
   * @return {void}
   * @public
   */
  m_setActiveFlag__boolean(active) {
    this.f_active__org_dominokit_domino_ui_carousel_Slide_ = active;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_isActive__() {
    return this.f_active__org_dominokit_domino_ui_carousel_Slide_;
  }
  
  /**
   * @return {boolean}
   * @public
   */
  m_hasActiveStyle__() {
    return /**@type {Style<HTMLDivElement, Slide>} */ (Style.m_of__org_jboss_gwt_elemento_core_IsElement(this)).m_contains__java_lang_String("active");
  }
  
  /**
   * @return {DominoElement<HTMLHeadingElement>}
   * @public
   */
  m_getSlideLabelElement__() {
    return /**@type {DominoElement<HTMLHeadingElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_slideLabelElement__org_dominokit_domino_ui_carousel_Slide_));
  }
  
  /**
   * @return {DominoElement<HTMLParagraphElement>}
   * @public
   */
  m_getSlideDescriptionElement__() {
    return /**@type {DominoElement<HTMLParagraphElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_slideDescriptionElement__org_dominokit_domino_ui_carousel_Slide_));
  }
  
  /**
   * @return {DominoElement<HTMLDivElement>}
   * @public
   */
  m_getCaptionElement__() {
    return /**@type {DominoElement<HTMLDivElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_captionElement__org_dominokit_domino_ui_carousel_Slide_));
  }
  
  /**
   * @return {DominoElement<HTMLImageElement>}
   * @public
   */
  m_getImageElement__() {
    return /**@type {DominoElement<HTMLImageElement>} */ (DominoElement.m_of__elemental2_dom_HTMLElement(this.f_imageElement__org_dominokit_domino_ui_carousel_Slide));
  }
  
  /**
   * @return {void}
   * @private
   */
  $init__org_dominokit_domino_ui_carousel_Slide() {
    this.f_indicatorElement__org_dominokit_domino_ui_carousel_Slide_ = /**@type {HTMLLIElement} */ ($Casts.$to(Elements.m_li__().m_asElement__(), HTMLLIElement_$Overlay));
    this.f_slideLabelElement__org_dominokit_domino_ui_carousel_Slide_ = /**@type {HTMLHeadingElement} */ ($Casts.$to(Elements.m_h__int(3).m_asElement__(), HTMLHeadingElement_$Overlay));
    this.f_slideDescriptionElement__org_dominokit_domino_ui_carousel_Slide_ = /**@type {HTMLParagraphElement} */ ($Casts.$to(Elements.m_p__().m_asElement__(), HTMLParagraphElement_$Overlay));
    this.f_captionElement__org_dominokit_domino_ui_carousel_Slide_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_add__elemental2_dom_Node(this.f_slideLabelElement__org_dominokit_domino_ui_carousel_Slide_), HtmlContentBuilder)).m_add__elemental2_dom_Node(this.f_slideDescriptionElement__org_dominokit_domino_ui_carousel_Slide_), HtmlContentBuilder)).m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["carousel-caption"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_slideElement__org_dominokit_domino_ui_carousel_Slide_ = /**@type {HTMLDivElement} */ ($Casts.$to(/**@type {HtmlContentBuilder<HTMLDivElement>} */ ($Casts.$to(Elements.m_div__().m_css__arrayOf_java_lang_String(/**@type {!Array<?string>} */ ($Arrays.$init(["item"], j_l_String))), HtmlContentBuilder)).m_asElement__(), HTMLDivElement_$Overlay));
    this.f_active__org_dominokit_domino_ui_carousel_Slide_ = false;
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Slide.$clinit = (() =>{
    });
    Slide.$loadModules();
    BaseDominoElement.$clinit();
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Slide;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Slide);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    HTMLDivElement_$Overlay = goog.module.get('elemental2.dom.HTMLDivElement.$Overlay$impl');
    HTMLHeadingElement_$Overlay = goog.module.get('elemental2.dom.HTMLHeadingElement.$Overlay$impl');
    $Overlay = goog.module.get('elemental2.dom.HTMLImageElement.$Overlay$impl');
    HTMLLIElement_$Overlay = goog.module.get('elemental2.dom.HTMLLIElement.$Overlay$impl');
    HTMLParagraphElement_$Overlay = goog.module.get('elemental2.dom.HTMLParagraphElement.$Overlay$impl');
    j_l_String = goog.module.get('java.lang.String$impl');
    Style = goog.module.get('org.dominokit.domino.ui.style.Style$impl');
    DominoElement = goog.module.get('org.dominokit.domino.ui.utils.DominoElement$impl');
    Elements = goog.module.get('org.jboss.gwt.elemento.core.Elements$impl');
    HtmlContentBuilder = goog.module.get('org.jboss.gwt.elemento.core.builder.HtmlContentBuilder$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
  }
  
  
};

$Util.$setClassMetadata(Slide, $Util.$makeClassName('org.dominokit.domino.ui.carousel.Slide'));




exports = Slide; 
//# sourceMappingURL=Slide.js.map