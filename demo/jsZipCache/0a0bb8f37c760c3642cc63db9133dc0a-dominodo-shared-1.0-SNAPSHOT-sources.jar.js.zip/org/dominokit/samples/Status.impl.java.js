/**
 * @fileoverview transpiled from org.dominokit.samples.Status.
 *
 * @suppress {const, extraRequire, missingOverride, missingRequire, suspiciousCode, transitionalSuspiciousCodeWarnings, unusedLocalVariables, uselessCode}
 */
goog.module('org.dominokit.samples.Status$impl');


const Enum = goog.require('java.lang.Enum$impl');
const $Util = goog.require('nativebootstrap.Util$impl');

let $Equality = goog.forwardDeclare('nativebootstrap.Equality$impl');
let $Arrays = goog.forwardDeclare('vmbootstrap.Arrays$impl');
let $Casts = goog.forwardDeclare('vmbootstrap.Casts$impl');
let $Enums = goog.forwardDeclare('vmbootstrap.Enums$impl');


/**
 * @extends {Enum<Status>}
  */
class Status extends Enum {
  /**
   * @protected
   */
  constructor() {
    super();
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {!Status}
   * @public
   */
  static $create__java_lang_String__int($name, $ordinal) {
    let $instance = new Status();
    $instance.$ctor__org_dominokit_samples_Status__java_lang_String__int($name, $ordinal);
    return $instance;
  }
  
  /**
   * @param {?string} $name
   * @param {number} $ordinal
   * @return {void}
   * @public
   */
  $ctor__org_dominokit_samples_Status__java_lang_String__int($name, $ordinal) {
    this.f_name__java_lang_Enum_ = $name;
    this.f_ordinal__java_lang_Enum_ = $ordinal;
    this.$ctor__java_lang_Enum__java_lang_String__int($name, $ordinal);
  }
  
  /**
   * @param {string} name
   * @return {!Status}
   * @public
   */
  static m_valueOf__java_lang_String(name) {
    Status.$clinit();
    if ($Equality.$same(Status.$f_namesToValuesMap__org_dominokit_samples_Status_, null)) {
      Status.$f_namesToValuesMap__org_dominokit_samples_Status_ = $Enums.createMapFromValues(Status.m_values__());
    }
    return $Enums.getValueFromNameAndMap(name, Status.$f_namesToValuesMap__org_dominokit_samples_Status_);
  }
  
  /**
   * @return {!Array<!Status>}
   * @public
   */
  static m_values__() {
    Status.$clinit();
    return /**@type {!Array<Status>} */ ($Arrays.$init([Status.$f_ACTIVE__org_dominokit_samples_Status, Status.$f_COMPLETED__org_dominokit_samples_Status], Status));
  }
  
  /**
   * Bridge method.
   * @override
   * @param {*} arg0
   * @return {number}
   * @public
   */
  m_compareTo__java_lang_Object(arg0) {
    return super.compareTo(/**@type {Status} */ ($Casts.$to(arg0, Status)));
  }
  
  /**
   * @return {!Status}
   * @public
   */
  static get f_ACTIVE__org_dominokit_samples_Status() {
    return (Status.$clinit(), Status.$f_ACTIVE__org_dominokit_samples_Status);
  }
  
  /**
   * @param {!Status} value
   * @return {void}
   * @public
   */
  static set f_ACTIVE__org_dominokit_samples_Status(value) {
    (Status.$clinit(), Status.$f_ACTIVE__org_dominokit_samples_Status = value);
  }
  
  /**
   * @return {!Status}
   * @public
   */
  static get f_COMPLETED__org_dominokit_samples_Status() {
    return (Status.$clinit(), Status.$f_COMPLETED__org_dominokit_samples_Status);
  }
  
  /**
   * @param {!Status} value
   * @return {void}
   * @public
   */
  static set f_COMPLETED__org_dominokit_samples_Status(value) {
    (Status.$clinit(), Status.$f_COMPLETED__org_dominokit_samples_Status = value);
  }
  
  /**
   * @return {Map<?string, !Status>}
   * @public
   */
  static get f_namesToValuesMap__org_dominokit_samples_Status_() {
    return (Status.$clinit(), Status.$f_namesToValuesMap__org_dominokit_samples_Status_);
  }
  
  /**
   * @param {Map<?string, !Status>} value
   * @return {void}
   * @public
   */
  static set f_namesToValuesMap__org_dominokit_samples_Status_(value) {
    (Status.$clinit(), Status.$f_namesToValuesMap__org_dominokit_samples_Status_ = value);
  }
  
  /**
   * @return {void}
   * @public
   */
  static $clinit() {
    Status.$clinit = (() =>{
    });
    Status.$loadModules();
    Enum.$clinit();
    Status.$f_ACTIVE__org_dominokit_samples_Status = Status.$create__java_lang_String__int($Util.$makeEnumName("ACTIVE"), Status.$ordinal$f_ACTIVE__org_dominokit_samples_Status);
    Status.$f_COMPLETED__org_dominokit_samples_Status = Status.$create__java_lang_String__int($Util.$makeEnumName("COMPLETED"), Status.$ordinal$f_COMPLETED__org_dominokit_samples_Status);
    Status.$f_namesToValuesMap__org_dominokit_samples_Status_ = null;
  }
  
  /**
   * @param {?} instance
   * @return {boolean}
   * @public
   */
  static $isInstance(instance) {
    return instance instanceof Status;
  }
  
  /**
   * @param {Function} classConstructor
   * @return {boolean}
   * @public
   */
  static $isAssignableFrom(classConstructor) {
    return $Util.$canCastClass(classConstructor, Status);
  }
  
  /**
   * @public
   */
  static $loadModules() {
    $Equality = goog.module.get('nativebootstrap.Equality$impl');
    $Arrays = goog.module.get('vmbootstrap.Arrays$impl');
    $Casts = goog.module.get('vmbootstrap.Casts$impl');
    $Enums = goog.module.get('vmbootstrap.Enums$impl');
  }
  
  
};

$Util.$setClassMetadataForEnum(Status, $Util.$makeClassName('org.dominokit.samples.Status'));


/** @private {!Status} */
Status.$f_ACTIVE__org_dominokit_samples_Status;


/** @private {!Status} */
Status.$f_COMPLETED__org_dominokit_samples_Status;


/** @private {Map<?string, !Status>} */
Status.$f_namesToValuesMap__org_dominokit_samples_Status_;


/** @public {number} @const */
Status.$ordinal$f_ACTIVE__org_dominokit_samples_Status = 0;


/** @public {number} @const */
Status.$ordinal$f_COMPLETED__org_dominokit_samples_Status = 1;




exports = Status; 
//# sourceMappingURL=Status.js.map